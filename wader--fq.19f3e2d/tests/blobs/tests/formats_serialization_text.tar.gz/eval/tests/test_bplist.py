"""Apple binary property list decoding, torepr and NSKeyedArchiver.

Covers ``-d bplist`` and bplist auto-probing for every object type
(singletons, ints of all widths incl. a 16-byte bigint, reals, dates,
data, ascii/unicode strings, uids, arrays, sets, dicts), the trailer and
offset table fields, large sizes via the 0xf marker, the ``lost_and_found``
section for unreferenced objects, error behaviour (bad magic/version,
offset/reference size range asserts, out-of-bounds and beyond-table
object references, non-string keys, invalid int sizes, unknown markers,
loop detection), the quirk that real/date large sizes are shifted twice,
and ``from_ns_keyed_archiver`` reconstruction of archive objects.
"""

from __future__ import annotations

import base64

import pytest

from conftest import run_fq, write_b64

# All expectations below were recorded by running ./executable.

# top dict {a: 300 (2-byte int), b: true, c: null, d: 2.5 (real)}
PL_BASIC = base64.b64decode(
    "YnBsaXN0MDDUAQIDBAUGBwhRYVFiUWNRZBEBLAkAI0AEAAAAAAAACBETFRcZHB0eAAAAAAA"
    "AAQEAAAAAAAAACQAAAAAAAAAAAAAAAAAAACc="
)

# top array [1, "hi", [data 0102]]
PL_ARR = base64.b64decode(
    "YnBsaXN0MDCjAQIDEAFSaGmhBEIBAggMDhETAAAAAAAAAQEAAAAAAAAABQAAAAAAAAAAAAA"
    "AAAAAABY="
)

# top dict {k: "héllo wörld"} (unicode string)
PL_UNI = base64.b64decode(
    "YnBsaXN0MDDRAQJRa2sAaADpAGwAbABvACAAdwD2AHIAbABkCAsNAAAAAAAAAQEAAAAAAAAA"
    "AwAAAAAAAAAAAAAAAAAAACQ="
)

# top unicode string "a😀b" (non-BMP, UTF-16BE with surrogate pair)
PL_EMOJI = base64.b64decode(
    "YnBsaXN0MDBkAGHYPd4AAGIIAAAAAAAAAQEAAAAAAAAAAQAAAAAAAAAAAAAAAAAAABE="
)

# dict {d8: date 3600.5, d4: date 100000.0 (4 byte), epoch: date 0, neg: date -100}
PL_DATES = base64.b64decode(
    "YnBsaXN0MDDUAQIDBAUGBwhSZDhSZDRVZXBvY2hTbmVnM0CsIQAAAAAAMkfDUAAzAAAAAAAAAAAz"
    "wFkAAAAAAAAIERQXHSEqLzgAAAAAAAABAQAAAAAAAAAJAAAAAAAAAAAAAAAAAAAAQQ=="
)

# dict {i1..i16: ints of 1/2/4/8/16 bytes}
PL_INTS = base64.b64decode(
    "YnBsaXN0MDDVAQIDBAUGBwgJClJpMVJpMlJpNFJpOFNpMTYQ/xH//xJ/////E4AAAAAAAAAA"
    "FAAAAAAAAABAAAAAAAAAAAAIExYZHB8jJSgtNgAAAAAAAAEBAAAAAAAAAAsAAAAAAAAAAAAA"
    "AAAAAABH"
)

# dict {u1: uid(2 bytes), u2: uid(4 bytes), u4: uid(8 bytes)}
PL_UIDS = base64.b64decode(
    "YnBsaXN0MDDTAQIDBAUGUnUxUnUyUnU0gQECggECAwSDAAABAAAAAAAIDxIVGBsgAAAAAAAAAQEA"
    "AAAAAAAABwAAAAAAAAAAAAAAAAAAACk="
)

# dict {u: set([uid(7), 42])}
PL_UIDSET = base64.b64decode(
    "YnBsaXN0MDDRAQJRdcIDBIAHECoICw0QEgAAAAAAAAEBAAAAAAAAAAUAAAAAAAAAAAAAAAAA"
    "AAAU"
)

# top object is int 5; "lost1" and 42 are unreferenced
PL_LOST = base64.b64decode(
    "YnBsaXN0MDAQBVVsb3N0MRAqCAoQAAAAAAAAAQEAAAAAAAAAAwAAAAAAAAAAAAAAAAAAABI="
)

# trailer says top object offset 2 but objects are 5/6/7
PL_TOP2 = base64.b64decode(
    "YnBsaXN0MDAQBRAGEAcICgwAAAAAAAABAQAAAAAAAAADAAAAAAAAAAIAAAAAAAAADg=="
)

# dict whose value references the dict itself -> loop detector
PL_LOOP = base64.b64decode(
    "YnBsaXN0MDDRAQBRawgLAAAAAAAAAQEAAAAAAAAAAgAAAAAAAAAAAAAAAAAAAA0="
)

# array referencing object index 99 with only 3 objects
PL_OOB = base64.b64decode(
    "YnBsaXN0MDChYxABEAIICgwAAAAAAAABAQAAAAAAAAADAAAAAAAAAAAAAAAAAAAADg=="
)

# magic "xplist00"
PL_BADMAGIC = base64.b64decode(
    "eHBsaXN0MDAQAQgAAAAAAAABAQAAAAAAAAABAAAAAAAAAAAAAAAAAAAACg=="
)

# version "01"
PL_BADVER = base64.b64decode(
    "YnBsaXN0MDEQAQgAAAAAAAABAQAAAAAAAAABAAAAAAAAAAAAAAAAAAAACg=="
)

# trailer offset_table_offset_size = 0
PL_OFFZERO = base64.b64decode(
    "YnBsaXN0MDAQBwgAAAAAAAAAAQAAAAAAAAABAAAAAAAAAAAAAAAAAAAACg=="
)

# trailer object_reference_size = 0
PL_REFZERO = base64.b64decode(
    "YnBsaXN0MDAQBwgAAAAAAAABAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAACg=="
)

# object 0 offset points inside the offset table
PL_BEYOND = base64.b64decode(
    "YnBsaXN0MDAQBwsAAAAAAAABAQAAAAAAAAABAAAAAAAAAAAAAAAAAAAACg=="
)

# dict with an integer key
PL_INTKEY = base64.b64decode(
    "YnBsaXN0MDDRAQIQBRAGCAsNAAAAAAAAAQEAAAAAAAAAAwAAAAAAAAAAAAAAAAAAAA8="
)

# int object with marker 0x15 (32 bytes)
PL_BADINT = base64.b64decode(
    "YnBsaXN0MDAVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAQEAAAAA"
    "AAAAAQAAAAAAAAAAAAAAAAAAACk="
)

# unknown object type marker 0x70
PL_UNK = base64.b64decode(
    "YnBsaXN0MDBwCAAAAAAAAAEBAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAJ"
)

# date with size nibble 1 (reads a 2-byte float, no assert fires)
PL_BADDATE = base64.b64decode(
    "YnBsaXN0MDAxAAAIAAAAAAAAAQEAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAs="
)

# date with 0xf size marker and size_bigint 8 -> size becomes 1<<8 = 256
PL_DATELARGE = base64.b64decode(
    "YnBsaXN0MDA/EQAIQKwhAAAAAAAIAAAAAAAAAQEAAAAAAAAAAQAAAAAAAAAAAAAAAAAAABQ="
)

# date with 0xf size marker and size_bigint 16 -> UintAssert(4,8) fails
PL_DATELARGEBAD = base64.b64decode(
    "YnBsaXN0MDA/EQAQAAAAAAAAAAAAAAAAAAAAAAgAAAAAAAABAQAAAAAAAAABAAAAAAAAAAAAAAAA"
    "AAAAHA=="
)

# date with 0xf size marker and a wrong large_size_marker (0x2 not 0x1)
PL_BADMARKER = base64.b64decode(
    "YnBsaXN0MDA/IQAIP/AAAAAAAAAIAAAAAAAAAQEAAAAAAAAAAQAAAAAAAAAAAAAAAAAAABQ="
)

# ascii string with 0xf size marker and size_bigint 0
PL_SIZEZERO = base64.b64decode(
    "YnBsaXN0MDBfEAAIAAAAAAAAAQEAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAs="
)

# real with 0xf size marker and size_bigint 1 -> 1<<1 = 2 byte half float 0.5
PL_REALSMALL = base64.b64decode(
    "YnBsaXN0MDAvEAE4AAgAAAAAAAABAQAAAAAAAAABAAAAAAAAAAAAAAAAAAAADQ=="
)

# real with 0xf size marker and size_bigint 8 -> size becomes 1<<8 = 256
PL_REALLARGE = base64.b64decode(
    "YnBsaXN0MDAvEQAIP/gAAAAAAAAIAAAAAAAAAQEAAAAAAAAAAQAAAAAAAAAAAAAAAAAAABQ="
)

# ascii string of 300 chars (0xf size marker, 2-byte size)
PL_BIGSTR = base64.b64decode(
    "YnBsaXN0MDBfEQEseHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4"
    "eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4"
    "eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4"
    "eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4"
    "eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4"
    "eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4CAAAAAAAAAEBAAAAAAAAAAEAAAAAAAAAAAAAAAAA"
    "AAE4"
)

# data of 300 bytes (0xf size marker)
PL_BIGDATA = base64.b64decode(
    "YnBsaXN0MDBPEQEsqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq"
    "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq"
    "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq"
    "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq"
    "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq"
    "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqCAAAAAAAAAEBAAAAAAAAAAEAAAAAAAAAAAAAAAAA"
    "AAE4"
)

# array of 20 ints (0xf size marker)
PL_BIGARR = base64.b64decode(
    "YnBsaXN0MDCvEBQBAgMEBQYHCAkKCwwNDg8QERITFBAAEAEQAhADEAQQBRAGEAcQCBAJEAoQ"
    "CxAMEA0QDhAPEBAQERASEBMIHyEjJScpKy0vMTM1Nzk7PT9BQ0UAAAAAAAABAQAAAAAAAAAV"
    "AAAAAAAAAAAAAAAAAAAARw=="
)

# dict with 16 entries (0xf size marker)
PL_BIGDICT = base64.b64decode(
    "YnBsaXN0MDDfEBABAgMEBQYHCAkKCwwNDg8QEREREREREREREREREREREVNrMDBTazAxU2swMlNr"
    "MDNTazA0U2swNVNrMDZTazA3U2swOFNrMDlTazEwU2sxMVNrMTJTazEzU2sxNFNrMTUQYwgrLzM3"
    "Oz9DR0tPU1dbX2NnawAAAAAAAAEBAAAAAAAAABIAAAAAAAAAAAAAAAAAAABt"
)

# NSKeyedArchiver archive with dict/array/date/uuid/person/null/
# attributed-string/data/self-cycle objects
PL_NKA = base64.b64decode(
    "YnBsaXN0MDDUWFlaW1VWVFdVJG51bGzTMDEyLC4vVnRoZWtledIxMjo70j4yPD3SQTI/QNNF"
    "RjJCQ0RVQWxpY2UQHlxOU0RpY3Rpb25hcnmgWiRjbGFzc25hbWVYJGNsYXNzZXPSDA0KC1dO"
    "U0FycmF5oNIMDQ8QVk5TRGF0ZaDSDA0SE1ZOU1VVSUSg0gwNFRZWUGVyc29uoNIMDRgZVk5T"
    "TnVsbKDSDA0bHF8QEk5TQXR0cmlidXRlZFN0cmluZ6DSDA0eH1ZOU0RhdGGg0gwNISJWQ3lj"
    "bGVyoNIMDSQl0TJH0ksySUrSTjJMTdJRMk9QgAKhK4ADoS2ADVdOUy5rZXlzWk5TLm9iamVj"
    "dHNWJGNsYXNzgASABYAGgCaAJ4AogCmnMzQ1Njc4OYAQI0CsIQAAAAAAgBNXTlMudGltZU8Q"
    "EAABAgMEBQYHCAkKCwwNDg+AFlxOUy51dWlkYnl0ZXOAB4AIgBlUbmFtZVNhZ2WAHFZzdHls"
    "ZWSAR4AfWE5TU3RyaW5nRN6tvu+AIldOUy5EYXRhgCmAJVRzZWxmgAFUcm9vdNFTUhIAAYagX"
    "xAPTlNLZXllZEFyY2hpdmVyrxBWAQIDBAUGBwgJCgsMDQ4PEBESExQVFhcYGRobHB0eHyAhI"
    "iMkJSYnKCkqKywtLi8wMTIzNDU2Nzg5Ojs8PT4/QEFCQ0RFRkdISUpLTE1OT1BRUlNUVVZYJH"
    "ZlcnNpb25ZJGFyY2hpdmVyVCR0b3BYJG9iamVjdHMACAARABcAHgAlACoALwA0ADsAQQBDAF"
    "AAUQBcAGUAagByAHMAeAB/AIAAhQCMAI0AkgCZAJoAnwCmAKcArADBAMIAxwDOAM8A1ADbAN"
    "wA4QDkAOkA7gDzAPUA9wD5APsA/QEFARABFwEZARsBHQEfASEBIwElAS0BLwE4AToBQgFVAV"
    "cBZAFmAWgBagFvAXMBdQF8AX4BgAGJAY4BkAGYAZoBnAGhAaMBqAGrAbABwgIbAiQCLgIzAA"
    "AAAAAAAgEAAAAAAAAAXAAAAAAAAAAAAAAAAAAAAjw="
)

# same archive with the $top "root" key broken to "rxot"
PL_NOROOT = base64.b64decode(
    "YnBsaXN0MDDUWFlaW1VWVFdVJG51bGzTMDEyLC4vVnRoZWtledIxMjo70j4yPD3SQTI/QNNF"
    "RjJCQ0RVQWxpY2UQHlxOU0RpY3Rpb25hcnmgWiRjbGFzc25hbWVYJGNsYXNzZXPSDA0KC1dO"
    "U0FycmF5oNIMDQ8QVk5TRGF0ZaDSDA0SE1ZOU1VVSUSg0gwNFRZWUGVyc29uoNIMDRgZVk5T"
    "TnVsbKDSDA0bHF8QEk5TQXR0cmlidXRlZFN0cmluZ6DSDA0eH1ZOU0RhdGGg0gwNISJWQ3lj"
    "bGVyoNIMDSQl0TJH0ksySUrSTjJMTdJRMk9QgAKhK4ADoS2ADVdOUy5rZXlzWk5TLm9iamVj"
    "dHNWJGNsYXNzgASABYAGgCaAJ4AogCmnMzQ1Njc4OYAQI0CsIQAAAAAAgBNXTlMudGltZU8Q"
    "EAABAgMEBQYHCAkKCwwNDg+AFlxOUy51dWlkYnl0ZXOAB4AIgBlUbmFtZVNhZ2WAHFZzdHls"
    "ZWSAR4AfWE5TU3RyaW5nRN6tvu+AIldOUy5EYXRhgCmAJVRzZWxmgAFUcnhvdNFTUhIAAYagX"
    "xAPTlNLZXllZEFyY2hpdmVyrxBWAQIDBAUGBwgJCgsMDQ4PEBESExQVFhcYGRobHB0eHyAhI"
    "iMkJSYnKCkqKywtLi8wMTIzNDU2Nzg5Ojs8PT4/QEFCQ0RFRkdISUpLTE1OT1BRUlNUVVZYJH"
    "ZlcnNpb25ZJGFyY2hpdmVyVCR0b3BYJG9iamVjdHMACAARABcAHgAlACoALwA0ADsAQQBDAF"
    "AAUQBcAGUAagByAHMAeAB/AIAAhQCMAI0AkgCZAJoAnwCmAKcArADBAMIAxwDOAM8A1ADbAN"
    "wA4QDkAOkA7gDzAPUA9wD5APsA/QEFARABFwEZARsBHQEfASEBIwElAS0BLwE4AToBQgFVAV"
    "cBZAFmAWgBagFvAXMBdQF8AX4BgAGJAY4BkAGYAZoBnAGhAaMBqAGrAbABwgIbAiQCLgIzAA"
    "AAAAAAAgEAAAAAAAAAXAAAAAAAAAAAAAAAAAAAAjw="
)


def test_bplist_basic_dict_types(tmp_path):
    """A dict of int/bool/null/real decodes with per-entry key and value."""
    path = write_b64(tmp_path, "basic.bplist", PL_BASIC)
    res = run_fq(["-d", "bplist", "-c", "torepr"], path)
    # CATCHES: the null singleton decodes as the number 0 (not null) and
    # true keeps its boolean; ints and reals come through unchanged.
    assert res.returncode == 0
    assert res.stdout == b'{"a":300,"b":true,"c":0,"d":2.5}\n'
    assert res.stderr == b""


def test_bplist_basic_dict_tree(tmp_path):
    """Dict entries carry key_index/value_index plus decoded key/value."""
    path = write_b64(tmp_path, "basic.bplist", PL_BASIC)
    res = run_fq(["-d", "bplist", "-V", "-c", ".objects"], path)
    # CATCHES: each entry holds the raw key_index/value_index object
    # references next to the already dereferenced key/value structs; the
    # singleton type shows value true/0 and the int shows size 2.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"entries":['
        b'{"key":{"size":1,"size_bits":1,"type":"ascii_string","value":"a"},'
        b'"key_index":1,"value":{"size":2,"type":"int","value":300},'
        b'"value_index":5},'
        b'{"key":{"size":1,"size_bits":1,"type":"ascii_string","value":"b"},'
        b'"key_index":2,"value":{"type":"singleton","value":true},'
        b'"value_index":6},'
        b'{"key":{"size":1,"size_bits":1,"type":"ascii_string","value":"c"},'
        b'"key_index":3,"value":{"type":"singleton","value":0},'
        b'"value_index":7},'
        b'{"key":{"size":1,"size_bits":1,"type":"ascii_string","value":"d"},'
        b'"key_index":4,'
        b'"value":{"size":8,"size_bits":3,"type":"real","value":2.5},'
        b'"value_index":8}],'
        b'"size":4,"size_bits":4,"type":"dict"}\n'
    )
    assert res.stderr == b""


def test_bplist_array_and_data(tmp_path):
    """Arrays dereference entries inline and nest other containers."""
    path = write_b64(tmp_path, "arr.bplist", PL_ARR)
    res = run_fq(["-d", "bplist", "-c", "torepr"], path)
    # CATCHES: nested arrays are dereferenced through the object table so
    # the inner [data] becomes a one-element list of a byte string.
    assert res.returncode == 0
    assert res.stdout == b'[1,"hi",["\\u0001\\u0002"]]\n'
    assert res.stderr == b""

    res_tree = run_fq(["-d", "bplist", "-V", "-c", ".objects"], path)
    # CATCHES: array entries record the object_index next to the decoded
    # item, and the data object carries its size and raw value.
    assert res_tree.returncode == 0
    assert res_tree.stdout == (
        b'{"entries":[{"object_index":1,"size":1,"type":"int","value":1},'
        b'{"object_index":2,"size":2,"size_bits":2,"type":"ascii_string",'
        b'"value":"hi"},{"entries":[{"object_index":4,"size":2,"size_bits":2,'
        b'"type":"data","value":"\\u0001\\u0002"}],"object_index":3,"size":1,'
        b'"size_bits":1,"type":"array"}],"size":3,"size_bits":3,"type":"array"}\n'
    )


def test_bplist_unicode_strings(tmp_path):
    """Unicode strings decode as UTF-16BE including non-BMP characters."""
    path = write_b64(tmp_path, "uni.bplist", PL_UNI)
    res = run_fq(["-d", "bplist", "-c", "torepr"], path)
    # CATCHES: the unicode string size counts UTF-16 code units and the
    # bytes are decoded big-endian, so "héllo wörld" round-trips.
    assert res.returncode == 0
    assert res.stdout == '{"k":"héllo wörld"}\n'.encode()
    assert res.stderr == b""

    path_e = write_b64(tmp_path, "emoji.bplist", PL_EMOJI)
    res_e = run_fq(["-d", "bplist", "-V", "-c", ".objects"], path_e)
    # CATCHES: a surrogate pair (4 bytes, size 2... reported as size 4 for
    # the three-character string) decodes to the emoji itself.
    assert res_e.returncode == 0
    assert res_e.stdout == (
        '{"size":4,"size_bits":4,"type":"unicode_string","value":"a😀b"}\n'.encode()
    )


def test_bplist_dates(tmp_path):
    """Dates decode to raw seconds since the 2001-01-01 Cocoa epoch."""
    path = write_b64(tmp_path, "dates.bplist", PL_DATES)
    res = run_fq(["-d", "bplist", "-c", "torepr"], path)
    # CATCHES: torepr keeps the raw float (3600.5, -100) rather than a
    # formatted date; 4-byte and 8-byte dates both work.
    assert res.returncode == 0
    assert res.stdout == b'{"d4":100000,"d8":3600.5,"epoch":0,"neg":-100}\n'
    assert res.stderr == b""

    res_d = run_fq(["-d", "bplist", "-c", "d"], path)
    # CATCHES: the display annotates date values with the RFC3339 time in
    # the Cocoa epoch (3600.5 -> 2001-01-01T01:00:00Z, -100 -> 2000-12-31).
    assert res_d.returncode == 0
    assert b"value: 3600.5 (2001-01-01T01:00:00Z)" in res_d.stdout
    assert b"value: 100000 (2001-01-02T03:46:40Z)" in res_d.stdout
    assert b"value: 0 (2001-01-01T00:00:00Z)" in res_d.stdout
    assert b"value: -100 (2000-12-31T23:58:20Z)" in res_d.stdout


def test_bplist_integer_widths(tmp_path):
    """Integers decode at 1/2/4/8/16 byte widths, 16 as a big integer."""
    path = write_b64(tmp_path, "ints.bplist", PL_INTS)
    res = run_fq(["-d", "bplist", "-c", "torepr"], path)
    # CATCHES: the 16-byte int (2**70) decodes exactly as a jq big number
    # while the 8-byte one is a signed int64 minimum.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"i1":255,"i16":1180591620717411303424,"i2":65535,"i4":2147483647,'
        b'"i8":-9223372036854775808}\n'
    )
    assert res.stderr == b""


def test_bplist_uids(tmp_path):
    """UID objects decode to {"cfuid": n} wrappers at every width."""
    path = write_b64(tmp_path, "uids.bplist", PL_UIDS)
    res = run_fq(["-d", "bplist", "-c", "torepr"], path)
    # CATCHES: uids become {"cfuid": n} objects (not plain numbers) so
    # NSKeyedArchiver references stay distinguishable from integers.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"u1":{"cfuid":258},"u2":{"cfuid":16909060},"u4":{"cfuid":1099511627776}}\n'
    )
    assert res.stderr == b""

    res_tree = run_fq(
        ["-d", "bplist", "-V", "-c", ".objects.entries[] | {k:.key.value, v:.value}"],
        path,
    )
    # CATCHES: the uid tree keeps its own "size" (the byte width) and a
    # plain unsigned value.
    assert res_tree.returncode == 0
    assert res_tree.stdout == (
        b'{"k":"u1","v":{"size":2,"type":"uid","value":258}}\n'
        b'{"k":"u2","v":{"size":4,"type":"uid","value":16909060}}\n'
        b'{"k":"u4","v":{"size":8,"type":"uid","value":1099511627776}}\n'
    )


def test_bplist_set_type(tmp_path):
    """Set objects decode like arrays with entries dereferenced."""
    path = write_b64(tmp_path, "uidset.bplist", PL_UIDSET)
    res = run_fq(["-d", "bplist", "-c", "torepr"], path)
    # CATCHES: the 0xc marker decodes as "set" with entries, and torepr
    # maps it to a plain array in entry order (uid first, then the int).
    assert res.returncode == 0
    assert res.stdout == b'{"u":[{"cfuid":7},42]}\n'
    assert res.stderr == b""


@pytest.mark.parametrize(
    "fixture,data,size,vlen,elen",
    [
        ("bigstr.bplist", PL_BIGSTR, 300, 300, 0),
        ("bigdata.bplist", PL_BIGDATA, 300, 300, 0),
        ("bigarr.bplist", PL_BIGARR, 20, 0, 20),
    ],
)
def test_bplist_large_sizes(tmp_path, fixture, data, size, vlen, elen):
    """Sizes >= 15 use the 0xf marker plus a 2-byte size_bigint field."""
    path = write_b64(tmp_path, fixture, data)
    res = run_fq(
        [
            "-d",
            "bplist",
            "-V",
            "-c",
            "[.objects.size, .objects.size_bits, "
            "(.objects.value // \"\" | length), (.objects.entries // [] | length)]",
        ],
        path,
    )
    # CATCHES: the marker low nibble is 15 and the real size comes from
    # size_bigint; strings/data measure bytes in value and arrays count
    # entries.
    assert res.returncode == 0
    assert res.stdout == f"[{size},15,{vlen},{elen}]\n".encode()
    assert res.stderr == b""


def test_bplist_large_dict(tmp_path):
    """A 16-entry dictionary uses the extended size encoding."""
    path = write_b64(tmp_path, "bigdict.bplist", PL_BIGDICT)
    res = run_fq(
        [
            "-d",
            "bplist",
            "-V",
            "-c",
            "[.objects.size, .objects.size_bits, (torepr|length), "
            "torepr.k00, torepr.k15]",
        ],
        path,
    )
    # CATCHES: size_bits is 15 with the real count 16 in the extended size
    # fields, and all 16 key/value pairs survive torepr.
    assert res.returncode == 0
    assert res.stdout == b"[16,15,16,99,99]\n"
    assert res.stderr == b""


def test_bplist_large_size_zero_is_allowed(tmp_path):
    """A 0xf size marker with size_bigint 0 decodes an empty string."""
    path = write_b64(tmp_path, "sizezero.bplist", PL_SIZEZERO)
    res = run_fq(["-d", "bplist", "-V", "-c", ".objects"], path)
    # CATCHES: size_bigint 0 is not rejected (the BigInt range assert is
    # inert), so the string decodes as empty with size 0.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"exponent":0,"large_size_marker":1,"size":0,"size_bigint":0,'
        b'"size_bits":15,"type":"ascii_string","value":""}\n'
    )
    assert res.stderr == b""


def test_bplist_real_large_size_quirk(tmp_path):
    """A real with the 0xf marker shifts the size a second time."""
    path = write_b64(tmp_path, "realsmall.bplist", PL_REALSMALL)
    res = run_fq(["-d", "bplist", "-V", "-c", ".objects"], path)
    # CATCHES: real objects compute size as 1<<decodeSize(), so a marker
    # size of 1 becomes a 2-byte (16-bit) float — 0x3800 decodes as 0.5.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"exponent":0,"large_size_marker":1,"size":2,"size_bigint":1,'
        b'"size_bits":15,"type":"real","value":0.5}\n'
    )
    assert res.stderr == b""

    res_t = run_fq(["-d", "bplist", "-c", "torepr"], path)
    assert res_t.returncode == 0
    assert res_t.stdout == b"0.5\n"


@pytest.mark.parametrize(
    "fixture,data",
    [
        ("datelarge.bplist", PL_DATELARGE),
        ("reallarge.bplist", PL_REALLARGE),
    ],
)
def test_bplist_large_size_double_shift_fails(tmp_path, fixture, data):
    """A 0xf marker size of 8 becomes 1<<8=256 and the value read hits EOF."""
    path = write_b64(tmp_path, fixture, data)
    res = run_fq(["-d", "bplist", "-V", "-c", ".objects"], path)
    # CATCHES: dates and reals with the extended size marker re-shift the
    # already-final size, so a size of 8 becomes 256 and only the size
    # fields decode (no value) — an error line appears in the display.
    assert res.returncode == 0
    typ = "date" if "datelarge" in fixture else "real"
    assert res.stdout == (
        b'{"exponent":1,"large_size_marker":1,"size":256,"size_bigint":8,'
        b'"size_bits":15,"type":"' + typ.encode() + b'"}\n'
    )
    assert res.stderr == b""

    res_d = run_fq(["-d", "bplist", "-c", "."], path)
    assert res_d.returncode == 0
    assert (
        b"error: bplist: F(value): failed at position 53 "
        b"(read size 0 seek pos 0): EOF\n" in res_d.stdout
    )


def test_bplist_date_size_assertion(tmp_path):
    """A 0xf date size outside 4..8 fails the size_bigint assert."""
    path = write_b64(tmp_path, "datelargebad.bplist", PL_DATELARGEBAD)
    res = run_fq(["-d", "bplist", "-V", "-c", ".objects"], path)
    # CATCHES: only the date type asserts size_bigint in 4..8; the tree
    # stops after size_bits and the display shows the failed Uint assert.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"exponent":1,"large_size_marker":1,"size_bits":15,"type":"date"}\n'
    )
    assert res.stderr == b""

    res_d = run_fq(["-d", "bplist", "-c", "."], path)
    assert res_d.returncode == 0
    assert (
        b"error: bplist: FieldUint(size_bigint): failed at position 12 "
        b"(read size 0 seek pos 0): failed to assert Uint\n" in res_d.stdout
    )


def test_bplist_large_size_marker_assert(tmp_path):
    """The byte after a 0xf size must have high nibble 0b0001."""
    path = write_b64(tmp_path, "badmarker.bplist", PL_BADMARKER)
    res = run_fq(["-d", "bplist", "-V", "-c", ".objects"], path)
    # CATCHES: a marker byte of 0x21 (high nibble 2) fails the
    # UintAssert(0b0001) on large_size_marker at the nibble position 9.4.
    assert res.returncode == 0
    assert res.stdout == b'{"size_bits":15,"type":"date"}\n'
    assert res.stderr == b""

    res_d = run_fq(["-d", "bplist", "-c", "."], path)
    assert res_d.returncode == 0
    assert (
        b"error: bplist: U4(large_size_marker): failed at position 9.4 "
        b"(read size 0 seek pos 0): failed to assert Uint\n" in res_d.stdout
    )


def test_bplist_small_date_size_is_not_asserted(tmp_path):
    """A date with size nibble 1 decodes a 2-byte float without error."""
    path = write_b64(tmp_path, "baddate.bplist", PL_BADDATE)
    res = run_fq(["-d", "bplist", "-V", "-c", ".objects"], path)
    # CATCHES: the 4-or-8 assert only applies to the extended size path,
    # so a plain size nibble of 1 yields a 16-bit float date of value 0.
    assert res.returncode == 0
    assert res.stdout == b'{"size":2,"size_bits":1,"type":"date","value":0}\n'
    assert res.stderr == b""


def test_bplist_lost_and_found(tmp_path):
    """Objects not referenced from the top land in lost_and_found."""
    path = write_b64(tmp_path, "lost.bplist", PL_LOST)
    res = run_fq(["-d", "bplist", "-V", "-c", "{objects, lost_and_found}"], path)
    # CATCHES: unreferenced objects 1 and 2 are decoded a second time in a
    # lost_and_found array after the top object; torepr only converts
    # .objects (the number 5).
    assert res.returncode == 0
    assert res.stdout == (
        b'{"lost_and_found":[{"size":5,"size_bits":5,"type":"ascii_string",'
        b'"value":"lost1"},{"size":1,"type":"int","value":42}],'
        b'"objects":{"size":1,"type":"int","value":5}}\n'
    )
    assert res.stderr == b""

    res_t = run_fq(["-d", "bplist", "-c", "torepr"], path)
    assert res_t.returncode == 0
    assert res_t.stdout == b"5\n"


def test_bplist_trailer_top_object_offset_is_ignored(tmp_path):
    """The trailer top_object_offset field is not used; object 0 wins."""
    path = write_b64(tmp_path, "top2.bplist", PL_TOP2)
    res = run_fq(["-d", "bplist", "-c", "torepr"], path)
    # CATCHES: even with top_object_offset 2 in the trailer, the decoder
    # always starts at object index 0, so the value is 5 (not 7).
    assert res.returncode == 0
    assert res.stdout == b"5\n"
    assert res.stderr == b""


def test_bplist_loop_detection(tmp_path):
    """A self-referencing dict triggers the loop detector."""
    path = write_b64(tmp_path, "loop.bplist", PL_LOOP)
    res = run_fq(["-d", "bplist", "-V", "-c", "."], path)
    # CATCHES: the dict entry that references its own object decodes to an
    # empty value {} while the rest of the tree stays intact.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"header":{"magic":"bplist","version":"00"},'
        b'"objects":{"entries":[{"key":{"size":1,"size_bits":1,'
        b'"type":"ascii_string","value":"k"},"key_index":1,"value":{},'
        b'"value_index":0}],"size":1,"size_bits":1,"type":"dict"},'
        b'"offset_table":[8,11],'
        b'"trailer":{"object_count":2,"object_reference_size":1,'
        b'"offset_table_offset_size":1,"offset_table_start":13,'
        b'"sort_version":0,"top_object_offset":0,"unused":0}}\n'
    )
    assert res.stderr == b""

    res_d = run_fq(["-d", "bplist", "-c", "."], path)
    assert res_d.returncode == 0
    assert (
        b"error: bplist: error at position 0xa: infinite recursion detected\n"
        in res_d.stdout
    )

    res_t = run_fq(["-d", "bplist", "-c", "torepr"], path)
    # CATCHES: torepr then fails at the jq level on the empty value, with
    # the input filename (as passed on the command line) in the error.
    assert res_t.returncode == 5
    assert res_t.stdout == b""
    assert res_t.stderr == f"error: {path}: unknown type: null\n".encode()


@pytest.mark.parametrize(
    "fixture,data,errline",
    [
        (
            "badmagic.bplist",
            PL_BADMAGIC,
            b"error: bplist: UTF8(magic): failed at position 6 "
            b"(read size 0 seek pos 0): failed to assert Str",
        ),
        (
            "badver.bplist",
            PL_BADVER,
            b"error: bplist: UTF8(version): failed at position 8 "
            b"(read size 0 seek pos 0): failed to assert Str",
        ),
        (
            "offzero.bplist",
            PL_OFFZERO,
            b"error: bplist: U8(offset_table_offset_size): failed at "
            b"position 18 (read size 0 seek pos 0): failed to assert Uint "
            b"range 1-8",
        ),
        (
            "refzero.bplist",
            PL_REFZERO,
            b"error: bplist: U8(object_reference_size): failed at "
            b"position 19 (read size 0 seek pos 0): failed to assert Uint "
            b"range 1-8",
        ),
        (
            "oob.bplist",
            PL_OOB,
            b"error: bplist: error at position 0xa: index 99 out of bounds "
            b"for object table size 3",
        ),
        (
            "beyond.bplist",
            PL_BEYOND,
            b"error: bplist: error at position 0x8: attempting to decode "
            b"object 0 at offset 0xb beyond offset table start 0xa",
        ),
        (
            "intkey.bplist",
            PL_INTKEY,
            b"error: bplist: error at position 0xa: non-string key in "
            b"dictionary",
        ),
        (
            "badint.bplist",
            PL_BADINT,
            b"error: bplist: error at position 0x9: invalid integer size 32",
        ),
        (
            "unk.bplist",
            PL_UNK,
            b"error: bplist: error at position 0x8.4: unknown type marker: 7",
        ),
    ],
)
def test_bplist_decode_errors(tmp_path, fixture, data, errline):
    """Malformed plists report error lines but still exit 0."""
    path = write_b64(tmp_path, fixture, data)
    res = run_fq(["-d", "bplist", "-c", "."], path)
    # CATCHES: each structural error (bad magic/version, offset/reference
    # size outside 1-8, out-of-bounds object refs, offsets past the offset
    # table, non-string keys, bad int sizes, unknown markers) surfaces as
    # an "error: bplist:" line in the display while the process exits 0.
    assert res.returncode == 0
    assert errline in res.stdout
    assert res.stderr == b""


def test_bplist_header_and_trailer_tree(tmp_path):
    """The tree exposes header, offset_table and trailer structures."""
    path = write_b64(tmp_path, "basic.bplist", PL_BASIC)
    res = run_fq(
        ["-d", "bplist", "-V", "-c", "[.header, .offset_table, .trailer]"], path
    )
    # CATCHES: the header asserts "bplist"/"00", the offset table lists
    # every object offset and the trailer exposes the size fields.
    assert res.returncode == 0
    assert res.stdout == (
        b'[{"magic":"bplist","version":"00"},[8,17,19,21,23,25,28,29,30],'
        b'{"object_count":9,"object_reference_size":1,'
        b'"offset_table_offset_size":1,"offset_table_start":39,'
        b'"sort_version":0,"top_object_offset":0,"unused":0}]\n'
    )
    assert res.stderr == b""


def test_bplist_is_probed(tmp_path):
    """Files starting with the bplist magic are auto-detected."""
    path = write_b64(tmp_path, "basic.bplist", PL_BASIC)
    res = run_fq(["-c", "[format, torepr]"], path)
    # CATCHES: probing picks bplist from the magic alone and torepr works
    # without forcing the decoder with -d.
    assert res.returncode == 0
    assert res.stdout == b'["bplist",{"a":300,"b":true,"c":0,"d":2.5}]\n'
    assert res.stderr == b""

    path_bad = write_b64(tmp_path, "badmagic.bplist", PL_BADMAGIC)
    res_bad = run_fq(["-c", "format"], path_bad)
    # CATCHES: without the magic the file is not detected as bplist.
    assert res_bad.returncode == 4
    assert b"probe: failed to decode" in res_bad.stderr


def test_bplist_from_ns_keyed_archiver(tmp_path):
    """from_ns_keyed_archiver reconstructs typed objects from the archive."""
    path = write_b64(tmp_path, "nka.bplist", PL_NKA)
    res = run_fq(["-d", "bplist", "-c", "from_ns_keyed_archiver"], path)
    # CATCHES: NSDictionary/NSArray entries are turned into objects and
    # arrays, NSNull into null, NSAttributedString into its NSString,
    # NSUUID into the raw uuidbytes, unknown classes keep $class replaced
    # by the class name with cfuids dereferenced, self-references become
    # "cycle-N" strings — and NSDate (quirk) yields the literal string
    # "NS.time" rather than the timestamp.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"thekey":["NS.time",'
        b'"\\u0000\\u0001\\u0002\\u0003\\u0004\\u0005\\u0006\\u0007\\b\\t\\n'
        b'\\u000b\\f\\r\\u000e\\u000f",'
        b'{"$class":"Person","age":30,"name":"Alice"},null,"styled",'
        b'"\xde\xad\\ufffd\\ufffd",'
        b'{"$class":"Cycler","self":"cycle-41"}]}\n'
    )
    assert res.stderr == b""


def test_bplist_from_ns_keyed_archiver_root_argument(tmp_path):
    """The 1-arity form decodes an arbitrary $objects index as root."""
    path = write_b64(tmp_path, "nka.bplist", PL_NKA)
    res = run_fq(["-d", "bplist", "-c", "from_ns_keyed_archiver(4)"], path)
    # CATCHES: from_ns_keyed_archiver(N) starts at $objects[N] instead of
    # $top.root, here reaching the NSDate object (again "NS.time").
    assert res.returncode == 0
    assert res.stdout == b'"NS.time"\n'
    assert res.stderr == b""

    res_p = run_fq(["-d", "bplist", "-c", "from_ns_keyed_archiver(6)"], path)
    # CATCHES: index 6 is the custom Person object with dereferenced
    # name/age values.
    assert res_p.returncode == 0
    assert res_p.stdout == b'{"$class":"Person","age":30,"name":"Alice"}\n'


def test_bplist_from_ns_keyed_archiver_missing_root(tmp_path):
    """An archive without $top.root fails with a descriptive jq error."""
    path = write_b64(tmp_path, "noroot.bplist", PL_NOROOT)
    res = run_fq(["-d", "bplist", "-c", "from_ns_keyed_archiver"], path)
    # CATCHES: the 0-arity form requires $top.root.cfuid; without it the
    # jq error names the root argument as the fix (with the input filename
    # as passed on the command line).
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == (
        f"error: {path}: root node not found, must specify root ID\n".encode()
    )
