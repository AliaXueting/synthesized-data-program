"""Markdown block and inline structure decoding.

Covers the document tree emitted by ``-d markdown`` (headings, paragraphs,
emphasis and links, lists, code blocks, tables, horizontal rules,
blockquotes), the math/image/hardbreak/del/html_span inline nodes, that
markdown is never probed, and the from_markdown string entry point.
"""

from __future__ import annotations

import pytest

from conftest import run_fq

# All expectations below were recorded by running ./executable.


def test_markdown_heading_and_paragraph():
    """Headings and paragraphs form the document children."""
    res = run_fq(["-d", "markdown", "-c", "."], stdin="# H1\n\n## H2\n\npara")
    # CATCHES: the root is {type: document, children: [...]}, headings
    # carry level/is_special/is_titleblock and plain text nodes are bare
    # strings mixed with inline objects.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"children":[{"children":["H1"],"is_special":false,'
        b'"is_titleblock":false,"level":1,"type":"heading"},'
        b'{"children":["H2"],"is_special":false,"is_titleblock":false,'
        b'"level":2,"type":"heading"},{"children":["para"],'
        b'"type":"paragraph"}],"type":"document"}\n'
    )
    assert res.stderr == b""


def test_markdown_inline_emphasis_link_code():
    """Inline spans become em/strong/link/code objects."""
    res = run_fq(
        ["-d", "markdown", "-c", "."],
        stdin=b"para with [link](http://x) and `code`",
    )
    # CATCHES: link nodes carry destination and a note_id of 0, code spans
    # carry literal, and plain text around them stays a bare string.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"children":[{"children":["para with ",'
        b'{"additional_attributes":[],"children":["link"],'
        b'"destination":"http://x","note_id":0,"type":"link"},'
        b'" and ",{"literal":"code","type":"code"}],'
        b'"type":"paragraph"}],"type":"document"}\n'
    )


def test_markdown_bold_and_italic():
    """**strong** and *em* map to strong and em nodes."""
    res = run_fq(["-d", "markdown", "-c", "."], stdin=b"**b** and *i*")
    # CATCHES: the two emphasis spellings map to distinct node types with
    # no extra fields.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"children":[{"children":[{"children":["b"],"type":"strong"},'
        b'" and ",{"children":["i"],"type":"em"}],'
        b'"type":"paragraph"}],"type":"document"}\n'
    )


def test_markdown_unordered_list():
    """A bullet list is a tight list of list_item children."""
    res = run_fq(["-d", "markdown", "-c", "."], stdin=b"- a\n- b")
    # CATCHES: the decoder forces bullet_char "-" and delimiter ".", items
    # wrap their content in a paragraph, and the list is tight (no blank
    # line between items).
    assert res.returncode == 0
    assert res.stdout == (
        b'{"children":[{"children":['
        b'{"bullet_char":"-","children":[{"children":["a"],"type":"paragraph"}],'
        b'"delimiter":".","is_footnotes_list":false,"list_flags":[],'
        b'"tight":false,"type":"list_item"},'
        b'{"bullet_char":"-","children":[{"children":["b"],"type":"paragraph"}],'
        b'"delimiter":".","is_footnotes_list":false,"list_flags":[],'
        b'"tight":false,"type":"list_item"}],'
        b'"delimiter":".","is_footnotes_list":false,"list_flags":[],'
        b'"start":0,"tight":true,"type":"list"}],"type":"document"}\n'
    )


def test_markdown_ordered_list_flags():
    """An ordered list adds the ordered flag and a start index."""
    res = run_fq(["-d", "markdown", "-c",
                  ".children[0] | {list_flags, start, tight, item_flags: .children[0].list_flags}"],
                 stdin=b"1. a\n2. b")
    # CATCHES: ordered lists carry ["ordered"] in list_flags on BOTH the list
    # node and every item plus a start index, and items lose the ordered
    # number itself (bullet_char falls back to "*").
    assert res.returncode == 0
    assert res.stdout == (
        b'{"item_flags":["ordered"],"list_flags":["ordered"],"start":0,"tight":true}\n'
    )


def test_markdown_code_blocks():
    """Fenced and indented code blocks both become code_block nodes."""
    res = run_fq(["-d", "markdown", "-c",
                  "[.children[] | {type, is_fenced, literal}]"],
                 stdin=b"```\ncode\n```\n\n    indented")
    # CATCHES: the fenced block keeps is_fenced true with the trailing
    # newline in literal, while the indented block is not fenced and also
    # ends with a newline.
    assert res.returncode == 0
    assert res.stdout == (
        b'[{"is_fenced":true,"literal":"code\\n","type":"code_block"},'
        b'{"is_fenced":false,"literal":"indented\\n","type":"code_block"}]\n'
    )


def test_markdown_table():
    """A GFM table decodes header and body rows of table_cell nodes."""
    res = run_fq(["-d", "markdown", "-c", "."],
                 stdin=b"| a | b |\n|---|---|\n| 1 | 2 |")
    # CATCHES: cells carry is_header and col_span 0, header cells sit in a
    # table_header child and data rows in a table_body.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"children":[{"children":[{"children":[{"children":['
        b'{"children":["a"],"col_span":0,"is_header":true,"type":"table_cell"},'
        b'{"children":["b"],"col_span":0,"is_header":true,"type":"table_cell"}],'
        b'"type":"table_row"}],"type":"table_header"},{"children":['
        b'{"children":[{"children":["1"],"col_span":0,"is_header":false,'
        b'"type":"table_cell"},{"children":["2"],"col_span":0,"is_header":false,'
        b'"type":"table_cell"}],"type":"table_row"}],"type":"table_body"}],'
        b'"type":"table"}],"type":"document"}\n'
    )


@pytest.mark.parametrize(
    "text,expected",
    [
        (b"> quote", b'{"children":[{"children":[{"children":["quote"],"type":"paragraph"}],"type":"blockquote"}],"type":"document"}\n'),
        (b"---", b'{"children":[{"literal":"---","type":"hr"}],"type":"document"}\n'),
        (b"", b'{"children":[],"type":"document"}\n'),
    ],
)
def test_markdown_blockquote_hr_empty(text, expected):
    """Blockquotes, horizontal rules and empty input."""
    res = run_fq(["-d", "markdown", "-c", "."], stdin=text)
    # CATCHES: a blockquote wraps a paragraph child, an hr keeps its source
    # literal, and empty input is still a valid empty document.
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_markdown_block_type_sequence():
    """Queries can walk the children array of the document."""
    res = run_fq(["-d", "markdown", "-c", "[.children[].type]"],
                 stdin=b"# T\n\npara\n\n> q")
    # CATCHES: children is a real array so jq iteration works on it.
    assert res.returncode == 0
    assert res.stdout == b'["heading","paragraph","blockquote"]\n'


@pytest.mark.parametrize(
    "text",
    [b"# Title", b"**b**", b"| a | b |\n|---|---|\n| 1 | 2 |", b"> quote", b"---"],
)
def test_markdown_is_not_probed(text):
    """Markdown is not part of the probe group."""
    res = run_fq(["-c", "format"], stdin=text)
    # CATCHES: markdown is never auto-detected, so unforced runs of plausible
    # markdown exit 4 with the probe error (a "- a" bullet list would probe
    # as yaml, so it is deliberately absent here).
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr.startswith(b"error: <stdin>: probe: failed to decode:")


def test_from_markdown_on_string():
    """from_markdown parses markdown from a string value."""
    res = run_fq(["-n", "-c", '"# T" | from_markdown'])
    # CATCHES: the generated from_<format> function decodes string input
    # into the same document tree as -d markdown.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"children":[{"children":["T"],"is_special":false,'
        b'"is_titleblock":false,"level":1,"type":"heading"}],'
        b'"type":"document"}\n'
    )


def test_markdown_math_nodes():
    """Inline math spans and display math blocks keep their literal source."""
    res = run_fq(
        ["-d", "markdown", "-V", "-c", "."], stdin=b"inline $a+b$ math and $x$ too"
    )
    # CATCHES: $...$ spans decode to leaf nodes of type "math" holding only
    # the literal formula, interleaved with the plain text around them.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"children":[{"children":["inline ",'
        b'{"literal":"a+b","type":"math"}," math and ",'
        b'{"literal":"x","type":"math"}," too"],"type":"paragraph"}],'
        b'"type":"document"}\n'
    )
    assert res.stderr == b""

    res_b = run_fq(
        ["-d", "markdown", "-V", "-c", "[.children[0], .children[1], .children[2]]"],
        stdin=b"para\n\n$$\nx = 1\n$$\n\ntail",
    )
    # CATCHES: a $$ fenced block becomes a container-less "math_block" node
    # with the raw literal (newlines included) and an empty children array.
    assert res_b.returncode == 0
    assert res_b.stdout == (
        b'[{"children":["para"],"type":"paragraph"},'
        b'{"children":[],"literal":"\\nx = 1\\n","type":"math_block"},'
        b'{"children":["tail"],"type":"paragraph"}]\n'
    )
    assert res_b.stderr == b""


def test_markdown_image_links_and_breaks():
    """Images carry destination/title, trailing backslashes are hardbreaks."""
    res = run_fq(
        ["-d", "markdown", "-V", "-c", "."],
        stdin=b'![alt text](i.png "the title")',
    )
    # CATCHES: an image decodes as a container node with destination and
    # title fields and the alt text as its children (unlike links it is not
    # addressable by #text; the alt survives only as the child list).
    assert res.returncode == 0
    assert res.stdout == (
        b'{"children":[{"children":[{"children":["alt text"],'
        b'"destination":"i.png","title":"the title","type":"image"}],'
        b'"type":"paragraph"}],"type":"document"}\n'
    )
    assert res.stderr == b""

    res_h = run_fq(
        ["-d", "markdown", "-V", "-c", "."], stdin=b"one  \ntwo\\\nthree"
    )
    # CATCHES: both markdown hardbreak spellings (two trailing spaces and a
    # backslash) produce {type: hardbreak} nodes splitting the paragraph,
    # while the soft line break inside "a\\nb" stays inside the text literal.
    assert res_h.returncode == 0
    assert res_h.stdout == (
        b'{"children":[{"children":["one",{"type":"hardbreak"},"two",'
        b'{"type":"hardbreak"},"three"],"type":"paragraph"}],'
        b'"type":"document"}\n'
    )
    assert res_h.stderr == b""

    res_s = run_fq(["-d", "markdown", "-V", "-c", "."], stdin=b"a\nb")
    assert res_s.returncode == 0
    assert res_s.stdout == (
        b'{"children":[{"children":["a\\nb"],"type":"paragraph"}],'
        b'"type":"document"}\n'
    )


def test_markdown_del_and_html_span():
    """Double-tilde strikethrough and inline HTML become their own nodes."""
    res = run_fq(["-d", "markdown", "-V", "-c", "."], stdin=b"x ~~y~~ z")
    # CATCHES: only the double-tilde spelling maps to the "del" node — a
    # single tilde around text parses as emphasis instead.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"children":[{"children":["x ",{"children":["y"],"type":"del"},'
        b'" z"],"type":"paragraph"}],"type":"document"}\n'
    )
    assert res.stderr == b""

    res_html = run_fq(
        ["-d", "markdown", "-V", "-c", "."], stdin=b"a <b>bold</b> c"
    )
    # CATCHES: each raw HTML tag decodes to an "html_span" leaf holding the
    # tag text verbatim, with the words between left as plain text children.
    assert res_html.returncode == 0
    assert res_html.stdout == (
        b'{"children":[{"children":["a ",'
        b'{"literal":"<b>","type":"html_span"},"bold",'
        b'{"literal":"</b>","type":"html_span"}," c"],"type":"paragraph"}],'
        b'"type":"document"}\n'
    )
    assert res_html.stderr == b""
