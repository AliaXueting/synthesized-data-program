"""JSON and JSONL decoding plus the jq flavoured to/from helpers.

Covers ``-d json``/``-d jsonl`` decoding of jq values, the ``tojson`` /
``fromjson`` overrides (fq redefines them on top of its own decoder), the
``to_jq``/``from_jq`` pair that reads and writes jq source syntax, and the
encoding corner cases (key sorting, number formatting, unicode passthrough).
"""

from __future__ import annotations

import pytest

from conftest import run_fq

# All expectations below were recorded by running ./executable.


# ---------------------------------------------------------------------------
# json decode
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "text,expected",
    [
        (b'{"a":1}', b'{"a":1}\n'),
        (b'[1,"two",null,true,3.5]', b'[1,"two",null,true,3.5]\n'),
        (b'  [1]  ', b"[1]\n"),
        (b'{"a":1,"a":2}', b'{"a":2}\n'),
        (b'{"k":"\\u00e9\\ud83d\\ude00"}', '{"k":"é😀"}\n'.encode()),
    ],
)
def test_json_decode_scalars(text, expected):
    """-d json decodes standard JSON into jq values verbatim."""
    res = run_fq(["-d", "json", "-c", "."], stdin=text)
    # CATCHES: every JSON type maps to the matching jq value, duplicate keys
    # keep the last value and \\uXXXX escapes are decoded to real UTF-8.
    assert res.returncode == 0
    assert res.stdout == expected
    assert res.stderr == b""


def test_json_trailing_data_is_rejected():
    """A second top-level value makes the json decoder fail."""
    res = run_fq(["-d", "json", "-c", "."], stdin=b"[1] [2]")
    # CATCHES: unlike a stream decoder, plain json demands exactly one
    # top-level value; the error names the position after the first value.
    assert res.returncode == 0
    assert b"trialing data after top-level value" in res.stdout
    assert res.stdout.startswith(
        b"   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
        b"|0123456789abcdef|.{}: <stdin> (json)"
    )
    assert res.stderr == b""


def test_json_scalar_root_is_fine_but_yaml_is_not():
    """json accepts any top-level value; the same input as yaml fails."""
    res_json = run_fq(["-d", "json", "-c", "."], stdin=b"1")
    res_yaml = run_fq(["-d", "yaml", "-c", "."], stdin=b"1")
    # CATCHES: json allows scalar roots while the yaml decoder insists on a
    # root object or array and shows the hexdump display with the error.
    assert res_json.returncode == 0
    assert res_json.stdout == b"1\n"
    assert res_yaml.returncode == 0
    assert b"root not object or array" in res_yaml.stdout


def test_fromjson_uses_the_format_decoder():
    """fq's fromjson override decodes via the json format, errors included."""
    res = run_fq(["-c", "try fromjson catch ."], stdin='"1 x"')
    # CATCHES: fromjson is not gojq's builtin; it round-trips through the
    # format decoder so its error text is the decoder's "trialing data"
    # message with the typo preserved.
    assert res.returncode == 0
    assert res.stdout == b'"error at position 0x3: trialing data after top-level value"\n'


# ---------------------------------------------------------------------------
# jsonl
# ---------------------------------------------------------------------------


def test_jsonl_decode_collects_lines():
    """jsonl decodes every line into one array of values."""
    res = run_fq(["-d", "jsonl", "-c", "."], stdin=b'{"a":1}\n{"a":2}\n')
    # CATCHES: jsonl returns a single array holding all values, not one
    # output per line.
    assert res.returncode == 0
    assert res.stdout == b'[{"a":1},{"a":2}]\n'


def test_jsonl_decode_blank_lines_and_scalars():
    """jsonl tolerates blank lines and decodes bare scalars."""
    res = run_fq(["-d", "jsonl", "-c", "."], stdin=b"\n\n1\n\n2\n")
    # CATCHES: empty lines are skipped, not decoded as null.
    assert res.returncode == 0
    assert res.stdout == b"[1,2]\n"


def test_jsonl_empty_input_error():
    """Empty input is an error for jsonl, shown as a decode failure."""
    res = run_fq(["-d", "jsonl", "-c", "."], stdin=b"")
    # CATCHES: jsonl on zero lines fails with "not lines found" and, because
    # the format was forced with -d, the failure is rendered as the hexdump
    # display on stdout with exit status 0.
    assert res.returncode == 0
    assert b"error: jsonl: error at position 0x0: not lines found" in res.stdout
    assert b"<stdin> (jsonl)" in res.stdout


def test_to_jsonl():
    """to_jsonl joins array elements with newlines, rejects objects."""
    res = run_fq(["-n", "-c", "[1,\"a\",null] | to_jsonl"])
    # CATCHES: to_jsonl maps over an array (not any iterable) and appends a
    # newline after every element.
    assert res.returncode == 0
    assert res.stdout == b'"1\\n\\"a\\"\\nnull\\n"\n'

    res_obj = run_fq(["-n", "-c", "{a:1} | to_jsonl"])
    # CATCHES: only arrays are accepted; an object is a type error.
    assert res_obj.returncode == 5
    assert res_obj.stderr == b'error: to_jsonl cannot be applied to: object ({"a":1})\n'

    res_null = run_fq(["-n", "-c", "null | to_jsonl"])
    # CATCHES: null behaves like an empty array and encodes to the empty
    # string.
    assert res_null.returncode == 0
    assert res_null.stdout == b'""\n'


# ---------------------------------------------------------------------------
# tojson
# ---------------------------------------------------------------------------


def test_tojson_compact_and_indent():
    """tojson defaults to compact output; indent adds newlines."""
    res = run_fq(["-n", "-c", "{b:2,a:1} | tojson"])
    # CATCHES: tojson sorts object keys and emits no spaces at all.
    assert res.returncode == 0
    assert res.stdout == b'"{\\"a\\":1,\\"b\\":2}"\n'

    res_i = run_fq(["-n", "-c", "{a:{b:[1,null]}} | tojson({indent:2})"])
    # CATCHES: indent:2 pretty prints with two spaces and one newline after
    # every comma, but empty containers stay inline.
    assert res_i.returncode == 0
    assert res_i.stdout == (
        b'"{\\n  \\"a\\": {\\n    \\"b\\": [\\n      1,\\n      null\\n    ]\\n  }\\n}"\n'
    )


def test_tojson_number_formatting():
    """tojson prints floats like jq and clamps out-of-range literals."""
    res = run_fq(
        ["-n", "-c", "[1.0, 0.1, 1e100, nan, infinite, -infinite, 3] | tojson"]
    )
    # CATCHES: whole floats lose their decimal point, 1e100 becomes
    # 1e+100, NaN becomes null and infinities clamp to the float64 maximum
    # with sign.
    assert res.returncode == 0
    assert res.stdout == (
        b'"[1,0.1,1e+100,null,1.7976931348623157e+308,'
        b'-1.7976931348623157e+308,3]"\n'
    )


def test_tojson_big_integers_and_unicode():
    """tojson keeps big integers exact and unicode unescaped."""
    res = run_fq(
        ["-n", "-c", '[18446744073709551615, "\\u00e9\\ud83d\\ude00"] | tojson']
    )
    # CATCHES: integers above 2^53 are printed digit for digit (no float
    # rounding) and non-ASCII characters are emitted as raw UTF-8, not
    # \\uXXXX escapes.
    assert res.returncode == 0
    assert res.stdout == '"[18446744073709551615,\\"é😀\\"]"\n'.encode()


# ---------------------------------------------------------------------------
# to_jq / from_jq
# ---------------------------------------------------------------------------


def test_to_jq_roundtrip():
    """to_jq renders jq source syntax and from_jq parses it back."""
    res = run_fq(["-n", "-c", '{a:1, b:"x y", c:[1,{d:2}]} | to_jq'])
    # CATCHES: to_jq quotes only keys that are not identifiers, drops the
    # quotes from string values and uses no spaces after : and ,.
    assert res.returncode == 0
    assert res.stdout == b'"{a:1,b:\\"x y\\",c:[1,{d:2}]}"\n'

    res_back = run_fq(["-n", "-c", '"{a: 1, b: [true, null]}" | from_jq | tojson'])
    # CATCHES: from_jq accepts spaces anywhere and reconstructs the exact
    # value including nested arrays and the null/true literals.
    assert res_back.returncode == 0
    assert res_back.stdout == b'"{\\"a\\":1,\\"b\\":[true,null]}"\n'


def test_to_jq_indent_option():
    """indent > 0 switches to_jq to multi-line output."""
    res = run_fq(["-n", "-c", "{a:1, b:[2]} | to_jq({indent: 2})"])
    # CATCHES: with indent the separators become ",\\n" and the key separator
    # gains a space, mirroring jq's own pretty printing.
    assert res.returncode == 0
    assert res.stdout == b'"{\\n  a: 1,\\n  b: [\\n    2\\n  ]\\n}"\n'


@pytest.mark.parametrize(
    "src,expected_out",
    [
        ("$x", b'"from_jq only supports constant literals: unsupported term TermTypeFunc"\n'),
        ("1+1", b'"from_jq only supports constant literals: unsupported term null"\n'),
    ],
)
def test_from_jq_rejects_non_literals(src, expected_out):
    """from_jq only understands constant literal expressions."""
    res = run_fq(["-c", "try from_jq catch ."], stdin='"' + src + '"')
    # CATCHES: variables and operators are rejected with the shared
    # "constant literals" message naming the offending term type.
    assert res.returncode == 0
    assert res.stdout == expected_out


def test_to_jq_quotes_non_identifier_keys():
    """to_jq decides quoting with a strict identifier regexp."""
    res = run_fq(["-n", "-c", '{"a b": 1, "": 2, if: 3} | to_jq'])
    # CATCHES: keys with spaces or the empty string are JSON quoted, but jq
    # keywords like if still match the identifier regexp and stay bare.
    assert res.returncode == 0
    assert res.stdout == b'"{\\"\\":2,\\"a b\\":1,if:3}"\n'
