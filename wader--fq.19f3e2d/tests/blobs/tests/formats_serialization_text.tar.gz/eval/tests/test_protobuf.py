"""Protobuf wire-format decoding and the Widevine schema decoder.

Covers ``-d protobuf`` generic decoding of all four wire types (varint,
64-bit, length-delimited, 32-bit) including multi-byte varints and high
field numbers, the quirk that fixed-width fields are read big-endian,
truncated varints and oversized lengths surfacing as ``gap0`` plus an
error line while the process still exits 0, unknown wire types decoding
to an empty ``wire_type`` symbol, sub-value re-decoding through the
``| protobuf`` pipe, that protobuf has no ``torepr`` and is never
auto-probed, and ``-d protobuf_widevine`` schema decoding (enum/bytes/
string/uint32 fields, enum symbol lookup, unknown enum values and
unknown field numbers falling back to the generic shape).
"""

from __future__ import annotations

import pytest

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.


def varint(n: int) -> bytes:
    """Encode n as an unsigned LEB128 varint."""
    out = b""
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out += bytes([b | 0x80])
        else:
            return out + bytes([b])


def field(num: int, wire: int, payload: bytes) -> bytes:
    """Encode one protobuf field: ULEB128 key plus the wire payload."""
    return varint((num << 3) | wire) + payload


def ld(data: bytes) -> bytes:
    """Length-delimited payload: varint length plus the bytes."""
    return varint(len(data)) + data


# all four wire types, a multi-byte varint and a high field number
PB_GENERIC = (
    field(1, 0, varint(150))
    + field(2, 0, varint(2**33))
    + field(3, 2, ld(b"testing"))
    + field(4, 1, (2**61).to_bytes(8, "little"))
    + field(5, 5, (1000).to_bytes(4, "little"))
    + field(600, 0, varint(1))
)

# a single length-delimited field
PB_LD = field(3, 2, ld(b"testing"))

# field 2 length-delimited holding an inner field 1 varint 42
PB_NESTED = field(2, 2, ld(field(1, 0, varint(42))))

# field 1 length-delimited claiming 63 bytes but only 2 present
PB_HUGELEN = field(1, 2, b"\x3f" + b"ab")

# a lone continuation byte: key varint never terminates
PB_TRUNC = b"\x80"

# widevine-style message with every schema field populated
PB_WIDEVINE = (
    field(1, 0, varint(1))  # algorithm: aesctr
    + field(2, 2, ld(b"key-id-bytes"))  # key_id bytes
    + field(3, 2, ld(b"provider"))  # provider string
    + field(4, 2, ld(bytes(range(8))))  # content_id bytes
    + field(6, 2, ld(b"policy:hd"))  # policy string
    + field(7, 0, varint(3))  # crypto_period_index uint32
    + field(8, 2, ld(b"grp"))  # grouped_license bytes
    + field(9, 0, varint(0x63656E63))  # protection_scheme "cenc"
)

# algorithm unencrypted + protection_scheme cbc1
PB_WIDEVINE2 = field(1, 0, varint(0)) + field(9, 0, varint(0x63626331))

# algorithm 5 (not in the enum) and unknown field number 5
PB_WIDEVINE3 = field(1, 0, varint(5)) + field(5, 0, varint(9))


def test_protobuf_wire_types(tmp_path):
    """All four wire types decode with key_n, field_number and wire_value."""
    path = write_file(tmp_path, "generic.pb", PB_GENERIC)
    res = run_fq(["-d", "protobuf", "-V", "-c", "."], path)
    # CATCHES: the ULEB128 key is split into key_n/field_number/wire_type,
    # multi-byte varints decode fully (2**33) and high field numbers
    # (600 -> key_n 4800) work; fixed-width values are read BIG-ENDIAN, so
    # the little-endian 2**61 becomes 32 and 1000 becomes 3892510720.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"fields":['
        b'{"field_number":1,"key_n":8,"wire_type":"varint","wire_value":150},'
        b'{"field_number":2,"key_n":16,"wire_type":"varint",'
        b'"wire_value":8589934592},'
        b'{"field_number":3,"key_n":26,"length":7,'
        b'"wire_type":"length_delimited","wire_value":"testing"},'
        b'{"field_number":4,"key_n":33,"wire_type":"64bit","wire_value":32},'
        b'{"field_number":5,"key_n":45,"wire_type":"32bit",'
        b'"wire_value":3892510720},'
        b'{"field_number":600,"key_n":4800,"wire_type":"varint",'
        b'"wire_value":1}]}\n'
    )
    assert res.stderr == b""


def test_protobuf_fixed_fields_big_endian(tmp_path):
    """64-bit and 32-bit wire values are decoded big-endian, not little."""
    data = field(4, 1, (2**61).to_bytes(8, "little")) + field(
        5, 5, (1000).to_bytes(4, "little")
    )
    path = write_file(tmp_path, "fixed.pb", data)
    res = run_fq(
        ["-d", "protobuf", "-V", "-c", "[.fields[0].wire_value, "
         ".fields[1].wire_value]"],
        path,
    )
    # CATCHES: contrary to the protobuf spec, fq reads fixed fields as
    # big-endian, so the little-endian encodings of 2**61 and 1000 come
    # back as byte-reversed values.
    assert res.returncode == 0
    assert res.stdout == b"[32,3892510720]\n"
    assert res.stderr == b""


def test_protobuf_length_delimited(tmp_path):
    """Length-delimited values keep length plus the raw bytes as value."""
    path = write_file(tmp_path, "ld.pb", PB_LD)
    res = run_fq(["-d", "protobuf", "-V", "-c", "."], path)
    # CATCHES: the length prefix becomes its own "length" field and the
    # bytes become wire_value; nothing else is inferred about the content.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"fields":[{"field_number":3,"key_n":26,"length":7,'
        b'"wire_type":"length_delimited","wire_value":"testing"}]}\n'
    )
    assert res.stderr == b""

    path_n = write_file(tmp_path, "nested.pb", PB_NESTED)
    res_n = run_fq(["-d", "protobuf", "-V", "-c", "."], path_n)
    # CATCHES: generic decoding does NOT recurse into sub-messages — the
    # inner field stays raw bytes in wire_value (0x08 0x2a -> "\b*").
    assert res_n.returncode == 0
    assert res_n.stdout == (
        b'{"fields":[{"field_number":2,"key_n":18,"length":2,'
        b'"wire_type":"length_delimited","wire_value":"\\b*"}]}\n'
    )


def test_protobuf_empty_input(tmp_path):
    """Zero bytes decode to an empty fields array."""
    path = write_file(tmp_path, "empty.pb", b"")
    res = run_fq(["-d", "protobuf", "-V", "-c", "."], path)
    # CATCHES: the field loop ends immediately on EOF with no error.
    assert res.returncode == 0
    assert res.stdout == b'{"fields":[]}\n'
    assert res.stderr == b""


def test_protobuf_truncated_varint(tmp_path):
    """A varint that never terminates leaves the byte as gap0."""
    path = write_file(tmp_path, "trunc.pb", PB_TRUNC)
    res = run_fq(["-d", "protobuf", "-V", "-c", "."], path)
    # CATCHES: the dangling continuation byte 0x80 stops the field decode
    # with an empty field struct and the byte surfaces as gap0 (JSON
    # escaped) while the process still exits 0.
    assert res.returncode == 0
    assert res.stdout == b'{"fields":[{}],"gap0":"\\ufffd"}\n'
    assert res.stderr == b""

    res_d = run_fq(["-d", "protobuf", "-c", "."], path)
    assert res_d.returncode == 0
    assert (
        b"error: protobuf: U8: failed at position 1 "
        b"(read size 0 seek pos 0): EOF\n" in res_d.stdout
    )
    assert b"|  gap0: raw bits" in res_d.stdout


def test_protobuf_huge_length(tmp_path):
    """A length larger than the remaining bytes stops the value read."""
    path = write_file(tmp_path, "hugelen.pb", PB_HUGELEN)
    res = run_fq(["-d", "protobuf", "-V", "-c", "."], path)
    # CATCHES: the 63-byte length claim cannot be satisfied by the 2
    # remaining bytes, so the field keeps key/length but no wire_value
    # and the unconsumed bytes become gap0.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"fields":[{"field_number":1,"key_n":10,"length":63,'
        b'"wire_type":"length_delimited"}],"gap0":"ab"}\n'
    )
    assert res.stderr == b""

    res_d = run_fq(["-d", "protobuf", "-c", "."], path)
    assert res_d.returncode == 0
    assert (
        b"error: protobuf: RawLen(wire_value): failed at position 2 "
        b"(read size 0 seek pos 0): outside buffer\n" in res_d.stdout
    )


@pytest.mark.parametrize(
    "key,field_number",
    [
        (b"\x0b", 1),  # wire type 3 (start group)
        (b"\x04", 0),  # wire type 4 (end group), field number 0
        (b"\x06", 0),  # wire type 6
        (b"\x0f", 1),  # wire type 7
    ],
)
def test_protobuf_unknown_wire_types(tmp_path, key, field_number):
    """Wire types 3/4/6/7 decode to an empty wire_type symbol."""
    path = write_file(tmp_path, "wt.pb", key)
    res = run_fq(["-d", "protobuf", "-V", "-c", "."], path)
    # CATCHES: only wire types 0-2 and 5 have symbols; the group types and
    # the reserved 6/7 decode the key but stop with wire_type "" and no
    # error — field number 0 (key < 8) is not rejected either.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"fields":[{"field_number":' + str(field_number).encode()
        + b',"key_n":' + str(key[0]).encode() + b',"wire_type":""}]}\n'
    )
    assert res.stderr == b""


def test_protobuf_subvalue_decode(tmp_path):
    """A decoded varint can be piped back into the protobuf decoder."""
    path = write_file(tmp_path, "generic.pb", PB_GENERIC)
    res = run_fq(
        ["-d", "protobuf", "-V", "-c", ".fields[0].wire_value | protobuf"], path
    )
    # CATCHES: the pipe form re-decodes the value bytes; wire_value 150
    # (0x96) is itself a key for field 18 with reserved wire type 6.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"fields":[{"field_number":18,"key_n":150,"wire_type":""}]}\n'
    )
    assert res.stderr == b""


def test_protobuf_no_torepr(tmp_path):
    """Protobuf values have no torepr conversion."""
    path = write_file(tmp_path, "ld.pb", PB_LD)
    res = run_fq(["-d", "protobuf", "-c", "torepr"], path)
    # CATCHES: torepr fails at the jq level with a per-format message and
    # exit code 5 — the tree is the only usable representation (the
    # filename appears as passed on the command line).
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == f"error: {path}: protobuf has no torepr\n".encode()


def test_protobuf_is_not_probed(tmp_path):
    """Protobuf has no probe group; auto-detection of a .pb file fails."""
    path = write_file(tmp_path, "generic.pb", PB_GENERIC)
    res = run_fq(["-c", "format"], path)
    # CATCHES: even a well-formed message is never auto-detected, so
    # probing fails with the generic error and exit code 4 (the filename
    # appears as passed on the command line).
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr == (
        f"error: {path}: probe: failed to decode: "
        f"try fq -d FORMAT to force format, see fq -h formats for list\n"
    ).encode()


def test_protobuf_display(tmp_path):
    """The display annotates wire_type with its numeric symbol value."""
    path = write_file(tmp_path, "generic.pb", PB_GENERIC)
    res = run_fq(["-d", "protobuf", "-c", "d"], path)
    # CATCHES: every field shows key_n, field_number and wire_type with
    # the numeric symbol annotation, and byte values show as raw bits.
    assert res.returncode == 0
    assert b'wire_type: "varint" (0)' in res.stdout
    assert b'wire_type: "length_delimited" (2)' in res.stdout
    assert b'wire_type: "64bit" (1)' in res.stdout
    assert b'wire_type: "32bit" (5)' in res.stdout
    assert b"|      key_n: 4800" in res.stdout
    assert b"field_number: 600" in res.stdout
    assert b"wire_value: raw bits" in res.stdout
    assert res.stderr == b""


def test_protobuf_widevine_tree(tmp_path):
    """protobuf_widevine decodes fields against the Widevine schema."""
    path = write_file(tmp_path, "widevine.pb", PB_WIDEVINE)
    res = run_fq(["-d", "protobuf_widevine", "-V", "-c", "."], path)
    # CATCHES: known field numbers gain name/type/value with the schema
    # types (enum, bytes, string, uint32), enum values are resolved to
    # their symbol names, and the raw key_n/length/wire_value fields stay.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"fields":['
        b'{"enum":"aesctr","field_number":1,"key_n":8,"name":"algorithm",'
        b'"type":"enum","wire_type":"varint","wire_value":1},'
        b'{"field_number":2,"key_n":18,"length":12,"name":"key_id",'
        b'"type":"bytes","value":"key-id-bytes","wire_type":'
        b'"length_delimited","wire_value":"key-id-bytes"},'
        b'{"field_number":3,"key_n":26,"length":8,"name":"provider",'
        b'"type":"string","value":"provider","wire_type":'
        b'"length_delimited","wire_value":"provider"},'
        b'{"field_number":4,"key_n":34,"length":8,"name":"content_id",'
        b'"type":"bytes","value":"\\u0000\\u0001\\u0002\\u0003\\u0004'
        b'\\u0005\\u0006\\u0007","wire_type":"length_delimited",'
        b'"wire_value":"\\u0000\\u0001\\u0002\\u0003\\u0004\\u0005\\u0006'
        b'\\u0007"},'
        b'{"field_number":6,"key_n":50,"length":9,"name":"policy",'
        b'"type":"string","value":"policy:hd","wire_type":'
        b'"length_delimited","wire_value":"policy:hd"},'
        b'{"field_number":7,"key_n":56,"name":"crypto_period_index",'
        b'"type":"uint32","value":3,"wire_type":"varint","wire_value":3},'
        b'{"field_number":8,"key_n":66,"length":3,"name":"grouped_license",'
        b'"type":"bytes","value":"grp","wire_type":"length_delimited",'
        b'"wire_value":"grp"},'
        b'{"enum":"cenc","field_number":9,"key_n":72,'
        b'"name":"protection_scheme","type":"uint32","value":1667591779,'
        b'"wire_type":"varint","wire_value":1667591779}]}\n'
    )
    assert res.stderr == b""


def test_protobuf_widevine_enum_names(tmp_path):
    """Enum symbols resolve for other algorithm/scheme values too."""
    path = write_file(tmp_path, "widevine2.pb", PB_WIDEVINE2)
    res = run_fq(["-d", "protobuf_widevine", "-V", "-c", "."], path)
    # CATCHES: algorithm 0 maps to "unencrypted" and the protection
    # scheme fourcc "cbc1" (0x63626331) maps to its symbol name.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"fields":[{"enum":"unencrypted","field_number":1,"key_n":8,'
        b'"name":"algorithm","type":"enum","wire_type":"varint",'
        b'"wire_value":0},{"enum":"cbc1","field_number":9,"key_n":72,'
        b'"name":"protection_scheme","type":"uint32","value":1667392305,'
        b'"wire_type":"varint","wire_value":1667392305}]}\n'
    )
    assert res.stderr == b""


def test_protobuf_widevine_unknown_enum_and_field(tmp_path):
    """Unknown enum values and field numbers fall back to generic fields."""
    path = write_file(tmp_path, "widevine3.pb", PB_WIDEVINE3)
    res = run_fq(["-d", "protobuf_widevine", "-V", "-c", "."], path)
    # CATCHES: an enum value with no symbol yields enum:"" while keeping
    # the numeric wire_value, and a field number outside the schema decodes
    # with no name/type/value at all (plain generic shape).
    assert res.returncode == 0
    assert res.stdout == (
        b'{"fields":[{"enum":"","field_number":1,"key_n":8,'
        b'"name":"algorithm","type":"enum","wire_type":"varint",'
        b'"wire_value":5},{"field_number":5,"key_n":40,"wire_type":'
        b'"varint","wire_value":9}]}\n'
    )
    assert res.stderr == b""


def test_protobuf_widevine_display(tmp_path):
    """The widevine display shows name/type/enum lines per field."""
    path = write_file(tmp_path, "widevine.pb", PB_WIDEVINE)
    res = run_fq(["-d", "protobuf_widevine", "-c", "d"], path)
    # CATCHES: schema-decoded fields render name:, type: and enum: lines
    # after the raw key/wire fields, with byte values shown as raw bits.
    assert res.returncode == 0
    assert b'name: "algorithm"' in res.stdout
    assert b'type: "enum"' in res.stdout
    assert b'enum: "aesctr"' in res.stdout
    assert b'name: "key_id"' in res.stdout
    assert b'type: "bytes"' in res.stdout
    assert b'name: "provider"' in res.stdout
    assert b'type: "string"' in res.stdout
    assert b'name: "crypto_period_index"' in res.stdout
    assert b'type: "uint32"' in res.stdout
    assert b"value: raw bits" in res.stdout
    assert res.stderr == b""


def test_protobuf_widevine_no_torepr(tmp_path):
    """protobuf_widevine values have no torepr conversion either."""
    path = write_file(tmp_path, "widevine.pb", PB_WIDEVINE)
    res = run_fq(["-d", "protobuf_widevine", "-c", "torepr"], path)
    # CATCHES: like the generic decoder, the schema decoder registers no
    # torepr and fails with exit code 5 naming the format (the filename
    # appears as passed on the command line).
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == f"error: {path}: protobuf_widevine has no torepr\n".encode()
