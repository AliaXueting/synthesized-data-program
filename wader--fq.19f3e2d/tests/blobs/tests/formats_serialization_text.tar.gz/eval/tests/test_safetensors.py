"""SafeTensors decoding.

Covers ``-d safetensors``: the little-endian u64 header size, the JSON
header value, per-dtype tensor data decoding (F64/F32/F16/BF16/I64/I32/
I16/I8/U8/BOOL), multi-dimensional shapes nesting the data arrays,
tensor-name sorting, ``__metadata__``, gap0 fields for bytes no tensor
claims, the unsupported-dtype / bad-data_offsets / non-tensor-header error
paths, the missing torepr function, and that safetensors is never
auto-probed.
"""

from __future__ import annotations

import base64

import pytest

from conftest import run_fq, write_file

# All expectations below were recorded by running ./executable.

# single F32 tensor "w" of shape [4] with values 1,2,3,4
S_F32 = base64.b64decode(
    "NwAAAAAAAAB7InciOnsiZHR5cGUiOiJGMzIiLCJzaGFwZSI6WzRdLCJkYXRhX29mZnNldHMi"
    "OlswLDE2XX19AACAPwAAAEAAAEBAAACAQA=="
)

# __metadata__ plus I64/I32/I16/I8/U8 tensors
S_INTS = base64.b64decode(
    "SgEAAAAAAAB7Il9fbWV0YWRhdGFfXyI6eyJmb3JtYXQiOiJwdCIsIndobyI6InRlc3QifSwi"
    "aTY0dCI6eyJkdHlwZSI6Ikk2NCIsInNoYXBlIjpbMl0sImRhdGFfb2Zmc2V0cyI6WzAsMTZd"
    "fSwiaTMydCI6eyJkdHlwZSI6IkkzMiIsInNoYXBlIjpbMl0sImRhdGFfb2Zmc2V0cyI6WzE2"
    "LDI0XX0sImkxNnQiOnsiZHR5cGUiOiJJMTYiLCJzaGFwZSI6WzJdLCJkYXRhX29mZnNldHMi"
    "OlsyNCwyOF19LCJpOHQiOnsiZHR5cGUiOiJJOCIsInNoYXBlIjpbMl0sImRhdGFfb2Zmc2V0"
    "cyI6WzI4LDMwXX0sInU4dCI6eyJkdHlwZSI6IlU4Iiwic2hhcGUiOlsyXSwiZGF0YV9vZmZz"
    "ZXRzIjpbMzAsMzJdfX3//////////wIAAAAAAAAA/f///wQAAAD7/wYA+QjIyQ=="
)

# BF16 [1.5,-0.5] and F16 [1.5,-2.5,0.5] tensors
S_BF16 = base64.b64decode(
    "dAAAAAAAAAB7ImJmMTZ0Ijp7ImR0eXBlIjoiQkYxNiIsInNoYXBlIjpbMl0sImRhdGFfb2Zm"
    "c2V0cyI6WzAsNF19LCJmMTZ0Ijp7ImR0eXBlIjoiRjE2Iiwic2hhcGUiOlszXSwiZGF0YV9v"
    "ZmZzZXRzIjpbNCwxMF19fcA/AL8APgDBADg="
)

# BOOL tensor of shape [3] whose single data byte is 0xE0
S_BOOL = base64.b64decode(
    "NwAAAAAAAAB7ImIiOnsiZHR5cGUiOiJCT09MIiwic2hhcGUiOlszXSwiZGF0YV9vZmZzZXRz"
    "IjpbMCwzXX194AAB"
)

# BOOL tensor of shape [3] whose single data byte is 0x01
S_BOOL_LO = base64.b64decode(
    "NwAAAAAAAAB7ImIiOnsiZHR5cGUiOiJCT09MIiwic2hhcGUiOlszXSwiZGF0YV9vZmZzZXRz"
    "IjpbMCwzXX19AQAB"
)

# tensors named z/a/m whose data_offsets are in that same order
S_SORTED = base64.b64decode(
    "oQAAAAAAAAB7InoiOnsiZHR5cGUiOiJJMzIiLCJzaGFwZSI6WzFdLCJkYXRhX29mZnNldHMi"
    "OlswLDRdfSwiYSI6eyJkdHlwZSI6IkkzMiIsInNoYXBlIjpbMV0sImRhdGFfb2Zmc2V0cyI6"
    "WzQsOF19LCJtIjp7ImR0eXBlIjoiSTMyIiwic2hhcGUiOlsxXSwiZGF0YV9vZmZzZXRzIjpb"
    "OCwxMl19fRoAAAABAAAADQAAAA=="
)

# F16 [2,2], F32 [2,3] and F64 [1] tensors
S_MULTIDIM = base64.b64decode(
    "sAAAAAAAAAB7ImYxNnQiOnsiZHR5cGUiOiJGMTYiLCJzaGFwZSI6WzIsMl0sImRhdGFfb2Zm"
    "c2V0cyI6WzAsOF19LCJmMzJ0Ijp7ImR0eXBlIjoiRjMyIiwic2hhcGUiOlsyLDNdLCJkYXRh"
    "X29mZnNldHMiOls4LDMyXX0sImY2NHQiOnsiZHR5cGUiOiJGNjQiLCJzaGFwZSI6WzFdLCJk"
    "YXRhX29mZnNldHMiOlszMiw0MF19fQA+AMEAQgA4AAAAAAAAgD8AAABAAABAQAAAgEAAAKBA"
    "boYb8PkhCUA="
)

# F32 tensor with an empty shape []
S_EMPTYSCALE = base64.b64decode(
    "NQAAAAAAAAB7InMiOnsiZHR5cGUiOiJGMzIiLCJzaGFwZSI6W10sImRhdGFfb2Zmc2V0cyI6"
    "WzAsNF19fQAAgD8="
)

# I32 tensor with shape [-1]
S_NEGDIM = base64.b64decode(
    "NwAAAAAAAAB7Im4iOnsiZHR5cGUiOiJJMzIiLCJzaGFwZSI6Wy0xXSwiZGF0YV9vZmZzZXRz"
    "IjpbMCw0XX19BQAAAA=="
)

# tensor with unsupported dtype "F8"
S_BADDTYPE = base64.b64decode(
    "NwAAAAAAAAB7ImJhZCI6eyJkdHlwZSI6IkY4Iiwic2hhcGUiOlsxXSwiZGF0YV9vZmZzZXRz"
    "IjpbMCwxXX19AQ=="
)

# tensor whose data_offsets has only one element
S_BADOFFSETS = base64.b64decode(
    "NgAAAAAAAAB7ImJhZCI6eyJkdHlwZSI6IkYzMiIsInNoYXBlIjpbMV0sImRhdGFfb2Zmc2V0"
    "cyI6WzBdfX0AAIA/"
)

# header with an extra top-level string value "note"
S_EXTRANOTE = base64.b64decode(
    "RQAAAAAAAAB7InQiOnsiZHR5cGUiOiJJMzIiLCJzaGFwZSI6WzFdLCJkYXRhX29mZnNldHMi"
    "OlswLDRdfSwibm90ZSI6ImhlbGxvIn0FAAAA"
)

# I32 tensor whose data starts at byte offset 4, leaving the first 4 as gap
S_GAP = base64.b64decode(
    "NgAAAAAAAAB7ImciOnsiZHR5cGUiOiJJMzIiLCJzaGFwZSI6WzFdLCJkYXRhX29mZnNldHMi"
    "Ols0LDhdfX1jAAAABwAAAA=="
)

# __metadata__ {format: pt} plus an F32 tensor
S_MD_F32 = base64.b64decode(
    "VQAAAAAAAAB7Il9fbWV0YWRhdGFfXyI6eyJmb3JtYXQiOiJwdCJ9LCJ3Ijp7ImR0eXBlIjoi"
    "RjMyIiwic2hhcGUiOlsyXSwiZGF0YV9vZmZzZXRzIjpbMCw4XX19AAAAPwAAwL8="
)


def test_safetensors_basic_f32(tmp_path):
    """A minimal safetensors file decodes header, size and tensor data."""
    path = write_file(tmp_path, "basic.safetensors", S_F32)
    res = run_fq(["-d", "safetensors", "-V", "-c", ".", path])
    # CATCHES: the 8-byte little-endian header size is exposed as
    # header_size, the JSON header becomes a plain jq object under
    # "header" (unchanged), and the tensor gains a "data" array of decoded
    # F32 values plus its "shape".
    assert res.returncode == 0
    assert res.stdout == (
        b'{"header":{"w":{"data_offsets":[0,16],"dtype":"F32","shape":[4]}},'
        b'"header_size":55,"tensors":{"w":{"data":[1,2,3,4],"shape":[4]}}}\n'
    )
    assert res.stderr == b""


def test_safetensors_header_is_queryable():
    """The JSON header value can be queried directly."""
    res = run_fq(["-d", "safetensors", "-c", ".header.w"], stdin=S_F32)
    # CATCHES: the header field holds the raw decoded JSON (dtype, shape
    # and data_offsets), queryable with plain jq paths.
    assert res.returncode == 0
    assert res.stdout == b'{"data_offsets":[0,16],"dtype":"F32","shape":[4]}\n'

    res_h = run_fq(["-d", "safetensors", "-V", "-c", ".header_size"], stdin=S_F32)
    # CATCHES: header_size is the byte length of the JSON header (55).
    assert res_h.returncode == 0
    assert res_h.stdout == b"55\n"


def test_safetensors_integer_dtypes(tmp_path):
    """All signed and unsigned integer dtypes decode little-endian."""
    path = write_file(tmp_path, "ints.safetensors", S_INTS)
    res = run_fq(["-d", "safetensors", "-V", "-c", ".", path])
    # CATCHES: I64/I32/I16/I8 decode as signed little-endian (so -1, -3,
    # -5, -7) while U8 is unsigned (200, 201 > 127), and the __metadata__
    # object stays inside the header without becoming a tensor.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"header":{"__metadata__":{"format":"pt","who":"test"},'
        b'"i16t":{"data_offsets":[24,28],"dtype":"I16","shape":[2]},'
        b'"i32t":{"data_offsets":[16,24],"dtype":"I32","shape":[2]},'
        b'"i64t":{"data_offsets":[0,16],"dtype":"I64","shape":[2]},'
        b'"i8t":{"data_offsets":[28,30],"dtype":"I8","shape":[2]},'
        b'"u8t":{"data_offsets":[30,32],"dtype":"U8","shape":[2]}},'
        b'"header_size":330,"tensors":{"i16t":{"data":[-5,6],"shape":[2]},'
        b'"i32t":{"data":[-3,4],"shape":[2]},"i64t":{"data":[-1,2],"shape":[2]},'
        b'"i8t":{"data":[-7,8],"shape":[2]},"u8t":{"data":[200,201],'
        b'"shape":[2]}}}\n'
    )
    assert res.stderr == b""


def test_safetensors_float_dtypes():
    """F16, BF16, F64 and multi-dimensional F32 tensors decode."""
    res = run_fq(["-d", "safetensors", "-V", "-c", "."], stdin=S_MULTIDIM)
    # CATCHES: shapes with more than one dimension nest the data arrays
    # one level per dimension ([2,2] -> [[..],[..]]) and F64 keeps full
    # precision (3.14159).
    assert res.returncode == 0
    assert res.stdout == (
        b'{"header":{"f16t":{"data_offsets":[0,8],"dtype":"F16","shape":[2,2]},'
        b'"f32t":{"data_offsets":[8,32],"dtype":"F32","shape":[2,3]},'
        b'"f64t":{"data_offsets":[32,40],"dtype":"F64","shape":[1]}},'
        b'"header_size":176,"tensors":{"f16t":{"data":[[1.5,-2.5],[3,0.5]],'
        b'"shape":[2,2]},"f32t":{"data":[[0,1,2],[3,4,5]],"shape":[2,3]},'
        b'"f64t":{"data":[3.14159],"shape":[1]}}}\n'
    )

    res_bf = run_fq(["-d", "safetensors", "-V", "-c", ".tensors"], stdin=S_BF16)
    # CATCHES: BF16 values are the top 16 bits of an IEEE float32
    # reinterpreted (1.5 -> 0x3FC0 bytes c0 3f, -0.5 -> 00 bf).
    assert res_bf.returncode == 0
    assert res_bf.stdout == (
        b'{"bf16t":{"data":[1.5,-0.5],"shape":[2]},"f16t":{"data":[1.5,-2.5,'
        b'0.5],"shape":[3]}}\n'
    )


def test_safetensors_bool_reads_single_bits():
    """BOOL elements each consume one BIT, not one byte."""
    res_hi = run_fq(["-d", "safetensors", "-V", "-c", ".tensors"], stdin=S_BOOL)
    # CATCHES: a BOOL of shape [3] reads only the 3 most significant bits
    # of the first data byte, so byte 0xE0 yields [true,true,true].
    assert res_hi.returncode == 0
    assert res_hi.stdout == b'{"b":{"data":[true,true,true],"shape":[3]}}\n'

    res_lo = run_fq(["-d", "safetensors", "-V", "-c", ".tensors"], stdin=S_BOOL_LO)
    # CATCHES: byte 0x01 has its high bits clear, so the same shape decodes
    # to [false,false,false] — the low bit is never reached.
    assert res_lo.returncode == 0
    assert res_lo.stdout == b'{"b":{"data":[false,false,false],"shape":[3]}}\n'


def test_safetensors_tensor_names_are_sorted():
    """Tensors decode in sorted name order regardless of offsets order."""
    res = run_fq(["-d", "safetensors", "-V", "-c", ".tensors"], stdin=S_SORTED)
    # CATCHES: output order is alphabetical by tensor name (a, m, z) even
    # though the header lists z first and the data offsets run z->a->m.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"a":{"data":[1],"shape":[1]},"m":{"data":[13],"shape":[1]},'
        b'"z":{"data":[26],"shape":[1]}}\n'
    )
    assert res.stderr == b""


def test_safetensors_metadata_is_not_a_tensor():
    """__metadata__ is kept in the header and never becomes a tensor."""
    res = run_fq(["-d", "safetensors", "-V", "-c", "."], stdin=S_MD_F32)
    # CATCHES: the reserved __metadata__ key appears verbatim inside
    # "header" while "tensors" only contains the real tensor w.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"header":{"__metadata__":{"format":"pt"},"w":{"data_offsets":[0,8],'
        b'"dtype":"F32","shape":[2]}},"header_size":85,'
        b'"tensors":{"w":{"data":[0.5,-1.5],"shape":[2]}}}\n'
    )


def test_safetensors_empty_shape_has_no_data():
    """A tensor with shape [] decodes without a data field."""
    res = run_fq(["-d", "safetensors", "-V", "-c", "."], stdin=S_EMPTYSCALE)
    # CATCHES: zero-dimension tensors early-return after "shape", leaving
    # no "data" key, and the unclaimed 4 payload bytes surface as "gap0".
    assert res.returncode == 0
    assert res.stdout == (
        b'{"gap0":"\\u0000\\u0000\\ufffd?","header":{"s":{"data_offsets":[0,4],'
        b'"dtype":"F32","shape":[]}},"header_size":53,'
        b'"tensors":{"s":{"shape":[]}}}\n'
    )


def test_safetensors_negative_dimension_gives_empty_data():
    """A negative shape dimension decodes to an empty data array."""
    res = run_fq(["-d", "safetensors", "-V", "-c", "."], stdin=S_NEGDIM)
    # CATCHES: shape [-1] is not validated; the range loop runs zero times
    # so "data" is [] and the payload bytes again land in gap0.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"gap0":"\\u0005\\u0000\\u0000\\u0000","header":{"n":'
        b'{"data_offsets":[0,4],"dtype":"I32","shape":[-1]}},'
        b'"header_size":55,"tensors":{"n":{"data":[],"shape":[-1]}}}\n'
    )


def test_safetensors_data_offsets_gap():
    """Bytes before a tensor's data_offsets stay as a gap field."""
    res = run_fq(["-d", "safetensors", "-V", "-c", "."], stdin=S_GAP)
    # CATCHES: the tensor seeks to its begin offset (4) for the data, and
    # the skipped leading bytes (little-endian 99) appear as "gap0".
    assert res.returncode == 0
    assert res.stdout == (
        b'{"gap0":"c\\u0000\\u0000\\u0000","header":{"g":{"data_offsets":[4,8],'
        b'"dtype":"I32","shape":[1]}},"header_size":54,'
        b'"tensors":{"g":{"data":[7],"shape":[1]}}}\n'
    )


def test_safetensors_unsupported_dtype_error():
    """An unknown dtype reports an error and decodes no tensors."""
    res = run_fq(["-d", "safetensors", "-V", "-c", "."], stdin=S_BADDTYPE)
    # CATCHES: dtype F8 leaves "tensors" empty and the payload byte in
    # gap0 while the value tree is still produced.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"gap0":"\\u0001","header":{"bad":{"data_offsets":[0,1],"dtype":"F8",'
        b'"shape":[1]}},"header_size":55,"tensors":{}}\n'
    )

    res_d = run_fq(["-d", "safetensors", "-c", "."], stdin=S_BADDTYPE)
    # CATCHES: the display output carries the exact error with the dtype
    # name and position while the process still exits 0 with empty stderr.
    assert res_d.returncode == 0
    assert b"error: safetensors: error at position 0x3f: unsupported dtype: F8\n" in (
        res_d.stdout
    )
    assert res_d.stderr == b""


def test_safetensors_invalid_data_offsets_error():
    """data_offsets with fewer than two entries is rejected."""
    res = run_fq(["-d", "safetensors", "-V", "-c", "."], stdin=S_BADOFFSETS)
    # CATCHES: a single-element data_offsets leaves tensors empty with the
    # raw payload in gap0.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"gap0":"\\u0000\\u0000\\ufffd?","header":{"bad":{"data_offsets":[0],'
        b'"dtype":"F32","shape":[1]}},"header_size":54,"tensors":{}}\n'
    )

    res_d = run_fq(["-d", "safetensors", "-c", "."], stdin=S_BADOFFSETS)
    # CATCHES: the error names the tensor and echoes the offending offsets
    # list verbatim ([0]).
    assert res_d.returncode == 0
    assert (
        b"error: safetensors: error at position 0x3e: "
        b"invalid data_offsets for tensor bad: [0]\n"
    ) in res_d.stdout
    assert res_d.stderr == b""


def test_safetensors_non_tensor_header_value_error():
    """A non-object top-level header entry fails header parsing."""
    res = run_fq(["-d", "safetensors", "-V", "-c", "."], stdin=S_EXTRANOTE)
    # CATCHES: the string "note":"hello" cannot map to tensor info, so the
    # whole tensor set is dropped (tensors {}) and the payload becomes
    # gap0 — even the valid "t" tensor disappears.
    assert res.returncode == 0
    assert res.stdout == (
        b'{"gap0":"\\u0005\\u0000\\u0000\\u0000","header":{"note":"hello",'
        b'"t":{"data_offsets":[0,4],"dtype":"I32","shape":[1]}},'
        b'"header_size":69,"tensors":{}}\n'
    )

    res_d = run_fq(["-d", "safetensors", "-c", "."], stdin=S_EXTRANOTE)
    # CATCHES: the display reports the doubled "failed to parse header"
    # message with the mapstruct detail line, still exiting 0.
    assert res_d.returncode == 0
    assert (
        b"error: safetensors: error at position 0x4d: failed to parse header: "
        b"failed to parse header: decoding failed due to the following error(s):\n"
    ) in res_d.stdout
    assert (
        b"'[<interface {} Value>]' expected a map or struct, got \"string\"\n"
    ) in res_d.stdout
    assert res_d.stderr == b""


def test_safetensors_has_no_torepr():
    """safetensors does not register the torepr function."""
    res = run_fq(["-d", "safetensors", "-c", "torepr"], stdin=S_F32)
    # CATCHES: unlike msgpack/cbor/asn1_ber, safetensors has no torepr, so
    # the query fails with exit code 5 and a per-format error message.
    assert res.returncode == 5
    assert res.stdout == b""
    assert res.stderr == b"error: <stdin>: safetensors has no torepr\n"


def test_safetensors_is_not_probed():
    """safetensors is not part of the auto-detection probe group."""
    res = run_fq(["-c", "."], stdin=S_F32)
    # CATCHES: a valid safetensors blob is never auto-detected, so an
    # unforced run exits 4 with the probe hint on stderr.
    assert res.returncode == 4
    assert res.stdout == b""
    assert res.stderr.startswith(
        b"error: <stdin>: probe: failed to decode: try fq -d FORMAT to force format"
    )
