"""The primitive decode readers behind several formats.

pkg/decode's generated readers (the U8..U64 and S8..S64 families, F32/F64,
UTF8 strings, non-byte-aligned packed bit fields and crc32 checksums) are
shared by every format decoder.  Each test here drives one format that
stresses a distinctive reader combination and pins the decoded values and
the dump annotations that come out of them.
"""

import struct
import zlib

import pytest

# gzip member: deflate method, no flags, mtime 0, XFL 2 ("slow"), OS 255,
# a deflate stream of "hello gzip\n", then the crc32 and isize trailers.
GZIP_HELLO = (
    b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff"
    b"\xcbH\xcd\xc9\xc9WH\xaf\xca,\xe0\x02\x00"
    b"9|cV\x0b\x00\x00\x00"
)

# A 2x3 rgb PNG: signature, an IHDR chunk and an empty IEND chunk, each
# with its crc32.
PNG_TINY = (
    b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR"
    b"\x00\x00\x00\x02\x00\x00\x00\x03\x08\x02\x00\x00\x00"
    b"6\x88I\xd6"
    b"\x00\x00\x00\x00IEND\xaeB`\x82"
)

# fLaC magic then one last STREAMINFO block of 34 bytes: min/max block
# size, min/max frame size, the 64 packed bits holding sample rate /
# channels / bits per sample / total samples, and the md5 of zero samples.
FLAC_STREAMINFO = (
    b"fLaC\x80\x00\x00\x22"
    + b"\x00\x01\x00\x01" + b"\x00" * 6
    + b"\x0a\xc4\x44\xf0\x00\x00\x03\xe8" + b"\x00" * 16
)

# A 64 bit little-endian x86-64 executable header and a 32 bit big-endian
# MIPS one: same field layout, opposite byte order.
ELF64_LE = (
    b"\x7fELF" + bytes([2, 1, 1, 0, 0]) + b"\x00" * 7
    + struct.pack("<HHIQQQIHHHHHH", 2, 0x3E, 1, 0x400000, 64, 0, 0,
                  64, 56, 0, 64, 0, 0)
)
ELF32_BE = (
    b"\x7fELF" + bytes([1, 2, 1, 0, 0]) + b"\x00" * 7
    + struct.pack(">HHIIIIIHHHHHH", 2, 8, 1, 0x1000, 52, 0, 0,
                  52, 32, 0, 40, 0, 0)
)

ELF_QUERY = (
    "{c: .header.ident.class, d: .header.ident.data, m: .header.machine,"
    " t: .header.type, e: .header.entry, p: .header.phoff,"
    " eh: .header.ehsize} | tovalue"
)

ELF_HEADERS = [
    pytest.param(
        ELF64_LE,
        ["{",
         '  "c": 64,',
         '  "d": "little_endian",',
         '  "e": 4194304,',
         '  "eh": 64,',
         '  "m": "x86_64",',
         '  "p": 64,',
         '  "t": "exec"',
         "}"],
        id="elf64-little",
    ),
    pytest.param(
        ELF32_BE,
        ["{",
         '  "c": 32,',
         '  "d": "big_endian",',
         '  "e": 4096,',
         '  "eh": 52,',
         '  "m": "mips",',
         '  "p": 52,',
         '  "t": "exec"',
         "}"],
        id="elf32-big",
    ),
]


def test_msgpack_uint_width_boundaries(write_file, run_fq):
    """Each msgpack uint marker decodes the maximum value of its width.

    CATCHES: the markers 0xcc..0xcf select uint8/16/32/64 and all-0xff
    payloads decode as 255, 65535, 4294967295 and 18446744073709551615 -
    a reader that sign-extends, or stops one byte early, shifts every
    following value and renames the type symbol.
    """
    f = write_file("uints.bin",
                   b"\x94\xcc\xff\xcd\xff\xff\xce\xff\xff\xff\xff"
                   b"\xcf\xff\xff\xff\xff\xff\xff\xff\xff")
    values = run_fq(["-d", "msgpack", "[.elements[].value] | tovalue", f])
    assert values.returncode == 0
    assert values.stdout == "\n".join([
        "[",
        "  255,",
        "  65535,",
        "  4294967295,",
        "  18446744073709551615",
        "]",
    ]) + "\n"
    assert values.stderr == ""

    types = run_fq(["-d", "msgpack", "[.elements[].type] | tovalue", f])
    assert types.returncode == 0
    assert types.stdout == "\n".join([
        "[",
        '  "uint8",',
        '  "uint16",',
        '  "uint32",',
        '  "uint64"',
        "]",
    ]) + "\n"


def test_gzip_member_fields_and_checksums(write_file, run_fq):
    """gzip decodes the member header, both trailers and the inflated data.

    CATCHES: the crc32 field is 1449360441, exactly zlib.crc32 of the
    decompressed bytes, isize is 11, method and extra flags decode to the
    symbols "deflate" and "slow" with os 255 and mtime 0, and the payload
    is reassembled as the string "hello gzip\\n".
    """
    f = write_file("hello.gz", GZIP_HELLO)

    trailers = run_fq(["-d", "gzip",
                       "[.members[0] | .crc32, .isize] | tovalue", f])
    assert trailers.returncode == 0
    assert trailers.stdout == "[\n  1449360441,\n  11\n]\n"
    assert zlib.crc32(b"hello gzip\n") == 1449360441
    assert trailers.stderr == ""

    names = run_fq(["-d", "gzip",
                    ".members[0] | .compression_method, .extra_flags, .os,"
                    " .mtime, .flags.text, .flags.name | tovalue", f])
    assert names.returncode == 0
    assert names.stdout == '"deflate"\n"slow"\n255\n0\nfalse\nfalse\n'

    payload = run_fq(["-d", "gzip", ".uncompressed | tovalue", f])
    assert payload.returncode == 0
    assert payload.stdout == '"hello gzip\\n"\n'


def test_png_chunks_crc_hex_display_and_valid(write_file, run_fq):
    """png chunk types, big-endian lengths and verified crc32 checksums.

    CATCHES: lengths are read big-endian (13 and 0), each crc field renders
    in hex as 0x368849d6 / 0xae426082 followed by "(valid)" because the
    checksum is recomputed during decode, while tovalue gives the plain
    decimals 914901462 and 2923585666 for the same fields.
    """
    f = write_file("tiny.png", PNG_TINY)
    result = run_fq(["-d", "png", "d", f])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: tiny.png (png)',
        '0x00|89 50 4e 47 0d 0a 1a 0a                        |.PNG....        |  signature: raw bits (valid)',
        '    |                                               |                |  chunks[0:2]:',
        '    |                                               |                |    [0]{}: chunk',
        '0x00|                        00 00 00 0d            |        ....    |      length: 13',
        '0x00|                                    49 48 44 52|            IHDR|      type: "IHDR"',
        '0x00|                                    49         |            I   |      ancillary: false',
        '0x00|                                       48      |             H  |      private: false',
        '0x00|                                          44   |              D |      reserved: false',
        '0x00|                                             52|               R|      safe_to_copy: false',
        '0x10|00 00 00 02                                    |....            |      width: 2',
        '0x10|            00 00 00 03                        |    ....        |      height: 3',
        '0x10|                        08                     |        .       |      bit_depth: 8',
        '0x10|                           02                  |         .      |      color_type: "rgb" (2)',
        '0x10|                              00               |          .     |      compression_method: "deflate" (0)',
        '0x10|                                 00            |           .    |      filter_method: "adaptive_filtering" (0)',
        '0x10|                                    00         |            .   |      interlace_method: "none" (0)',
        '0x10|                                       36 88 49|             6.I|      crc: 0x368849d6 (valid)',
        '0x20|d6                                             |.               |',
        '    |                                               |                |    [1]{}: chunk',
        '0x20|   00 00 00 00                                 | ....           |      length: 0',
        '0x20|               49 45 4e 44                     |     IEND       |      type: "IEND"',
        '0x20|               49                              |     I          |      ancillary: false',
        '0x20|                  45                           |      E         |      private: false',
        '0x20|                     4e                        |       N        |      reserved: false',
        '0x20|                        44                     |        D       |      safe_to_copy: false',
        '0x20|                           ae 42 60 82|        |         .B`.|  |      crc: 0xae426082 (valid)',
    ]) + "\n"
    assert result.stderr == ""

    crcs = run_fq(["-d", "png", "[.chunks[] | .type, .crc] | tovalue", f])
    assert crcs.returncode == 0
    assert crcs.stdout == "\n".join([
        "[",
        '  "IHDR",',
        "  914901462,",
        '  "IEND",',
        "  2923585666",
        "]",
    ]) + "\n"


@pytest.mark.parametrize("header,expected", ELF_HEADERS)
def test_elf_header_fields_follow_the_ident_byte_order(
        write_file, run_fq, header, expected):
    """The ident data byte picks the byte order of every later field.

    CATCHES: the same field layout reads as machine x86_64 with entry
    4194304 when ident says 64 bit little-endian and as machine mips with
    entry 4096 when it says 32 bit big-endian - a decoder that ignores the
    ident byte, or hardcodes one order, gets both files wrong.
    """
    f = write_file("elf.bin", header)
    result = run_fq(["-d", "elf", ELF_QUERY, f])
    assert result.returncode == 0
    assert result.stdout == "\n".join(expected) + "\n"
    assert result.stderr == ""


def test_elf_dump_symbols_hex_display_and_descriptions(write_file, run_fq):
    """The elf dump annotates validators, actuals, hex and descriptions.

    CATCHES: magic and the ident pad show the validators "(valid)" and
    "(all zero)", class/data/os_abi show the raw actuals (2)/(1)/(0) beside
    their symbols, type and machine render in hex as (0x2)/(0x3e) and
    machine adds the description "(AMD x86-64)".
    """
    f = write_file("elf1.bin", ELF64_LE)
    result = run_fq(["-d", "elf", "d", f])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: elf1.bin (elf)',
        '    |                                               |                |  header{}:',
        '    |                                               |                |    ident{}:',
        '0x00|7f 45 4c 46                                    |.ELF            |      magic: raw bits (valid)',
        '0x00|            02                                 |    .           |      class: 64 (2)',
        '0x00|               01                              |     .          |      data: "little_endian" (1)',
        '0x00|                  01                           |      .         |      version: 1',
        '0x00|                     00                        |       .        |      os_abi: "sysv" (0)',
        '0x00|                        00                     |        .       |      abi_version: 0',
        '0x00|                           00 00 00 00 00 00 00|         .......|      pad: raw bits (all zero)',
        '0x10|02 00                                          |..              |    type: "exec" (0x2)',
        '0x10|      3e 00                                    |  >.            |    machine: "x86_64" (0x3e) (AMD x86-64)',
        '0x10|            01 00 00 00                        |    ....        |    version: 1',
        '0x10|                        00 00 40 00 00 00 00 00|        ..@.....|    entry: 4194304',
        '0x20|40 00 00 00 00 00 00 00                        |@.......        |    phoff: 64',
        '0x20|                        00 00 00 00 00 00 00 00|        ........|    shoff: 0',
        '0x30|00 00 00 00                                    |....            |    flags: 0',
        '0x30|            40 00                              |    @.          |    ehsize: 64',
        '0x30|                  38 00                        |      8.        |    phentsize: 56',
        '0x30|                        00 00                  |        ..      |    phnum: 0',
        '0x30|                              40 00            |          @.    |    shentsize: 64',
        '0x30|                                    00 00      |            ..  |    shnum: 0',
        '0x30|                                          00 00|              ..|    shstrndx: 0',
        '    |                                               |                |  program_headers[0:0]:',
        '    |                                               |                |  section_headers[0:0]:',
    ]) + "\n"
    assert result.stderr == ""


def test_flac_streaminfo_unpacks_packed_bit_fields(write_file, run_fq):
    """flac's STREAMINFO splits 64 packed bits into four unequal fields.

    CATCHES: the 8 bytes 0a c4 44 f0 00 00 03 e8 are not whole-byte fields
    but a 20 bit sample rate 44100, a 3 bit channel count 3, a 5 bit depth
    16 and a 36 bit total sample count 1000 - one bit off anywhere shifts
    every field after it; md5_calculated is the empty-input md5 constant.
    """
    f = write_file("flac1.bin", FLAC_STREAMINFO)
    result = run_fq(["-d", "flac", "tovalue", f])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        "{",
        '  "decoded_samples": 0,',
        '  "frames": [],',
        '  "magic": "fLaC",',
        '  "md5_calculated": "d41d8cd98f00b204e9800998ecf8427e",',
        '  "metadatablocks": [',
        "    {",
        '      "bits_per_sample": 16,',
        '      "channels": 3,',
        '      "last_block": true,',
        '      "length": 34,',
        '      "maximum_block_size": 1,',
        '      "maximum_frame_size": 0,',
        '      "md5": "00000000000000000000000000000000",',
        '      "minimum_block_size": 1,',
        '      "minimum_frame_size": 0,',
        '      "sample_rate": 44100,',
        '      "total_samples_in_stream": 1000,',
        '      "type": "streaminfo"',
        "    }",
        "  ]",
        "}",
    ]) + "\n"
    assert result.stderr == ""

    fields = run_fq(["-d", "flac",
                     ".metadatablocks[0] | .sample_rate, .channels,"
                     " .bits_per_sample, .total_samples_in_stream,"
                     " .maximum_block_size | tovalue", f])
    assert fields.returncode == 0
    assert fields.stdout == "44100\n3\n16\n1000\n1\n"
