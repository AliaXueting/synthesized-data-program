"""Shared helpers for the decode_and_display test module.

The program under test is fq.  These tests pin how input bytes are turned
into structured decode values (format registry, probing, format functions,
format options, decode errors) and everything the user sees printed for
them: the structural hex dump and its layout options, hexdump, the JSON
value output modes, colors, unicode and truncation.
"""

import base64
import os
import subprocess

import pytest

# Fully pinned child environment: no inherited locale, color, unicode or
# config from the test runner.  TERM is a "smart" terminal value so that the
# only thing disabling colors by default is that stdout is a pipe.  HOME and
# XDG_CONFIG_HOME point at directories that do not exist so no fq config
# init.jq is picked up unless a test installs one on purpose.
CHILD_ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": "/nonexistent",
    "LANG": "C",
    "LC_ALL": "C",
    "TERM": "xterm",
    "NO_COLOR": "",
    "XDG_CONFIG_HOME": "/nonexistent",
}

# The 644 byte mp3 used by fq's own test suite: one id3v2 header with a TSSE
# frame, three mp3 frames where the first carries a Xing/Info tag.
MP3_BASE64 = (
    "SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4LjQ1LjEwMAAAAAAAAAAAAAAA//tAwAAAAAAAAAAA"
    "AAAAAAAAAAAASW5mbwAAAA8AAAACAAACVwCmpqampqampqampqampqampqampqampqampqampqam"
    "pqampqampqampqampqampqam////////////////////////////////////////////////////"
    "//////////////8AAAAATGF2YzU4LjkxAAAAAAAAAAAAAAAAJAUHAAAAAAAAAldi8Fo1AAAAAAD/"
    "+1DEAAAKLEMuVZSAAYCTaycwgAAHqsOOM4XTZPGhwQgcWB9eHxgcRgQeieWzLloPqDsTa/D4YFAU"
    "BAMCgkQMTmjRo2wfeIAQBDE4P8EHTnT5zl/Ocv7un3cuD4Pg+HwQDEoAwf0gAf///nnnnnhPsQ8p"
    "B1zlN1Fg1iKGapYafqNVM24v4SbR4AokJhs9BHBUe0qtGTYeiCaLf+8UnAsNYn//77ghRjlH+gmf"
    "KhoKBX0eBQRIg2d+5PKgIRNCQS//45BJg9a1CQRAwJlKoIgR//tSxASDyRQ5KTzDAAAAADSAAAAE"
    "EUs2SgiDWMkg1ClSmMjI+ROAQCS8kSNCUFYNGBEDQd6wVWCsRHiwdgr6P4lOlXKBqDUqdWdiL/BX"
    "lj3Ev//xEkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq"
    "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq"
    "qqqqqqqqqqqqqqqqqqqqqqo="
)


def _fq_bin():
    """Resolve the reference binary through PROGRAMGYM_EXECUTABLE."""
    path = os.environ.get("PROGRAMGYM_EXECUTABLE")
    if not path:
        raise RuntimeError(
            "PROGRAMGYM_EXECUTABLE must point at the fq binary under test"
        )
    return path


def _child_env(env):
    """The pinned child environment plus per-test overrides.

    A ``None`` value removes the variable from the child environment;
    every other value overrides (or adds) it.  GOCOVERDIR is forwarded
    from the test process at call time so the pipeline can measure the
    source coverage of an instrumented reference binary.
    """
    child = dict(CHILD_ENV)
    for key, value in (env or {}).items():
        if value is None:
            child.pop(key, None)
        else:
            child[key] = value
    for key in ("GOCOVERDIR",):
        value = os.environ.get(key)
        if value:
            child[key] = value
    return child


def run_fq_bytes(args, input_bytes=b"", env=None, cwd=None, timeout=10,
                 merge_stderr=False):
    """Run fq and capture the raw stdout/stderr bytes."""
    if isinstance(input_bytes, str):
        input_bytes = input_bytes.encode("utf-8")
    return subprocess.run(
        [_fq_bin(), *args],
        input=input_bytes,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT if merge_stderr else subprocess.PIPE,
        env=_child_env(env),
        cwd=cwd,
        timeout=timeout,
    )


def _as_text(proc):
    """A CompletedProcess whose streams are decoded as UTF-8 text."""
    stdout = proc.stdout.decode("utf-8")
    stderr = None if proc.stderr is None else proc.stderr.decode("utf-8")
    return subprocess.CompletedProcess(proc.args, proc.returncode, stdout, stderr)


def run_fq(args, input_text="", env=None, cwd=None, timeout=10,
           merge_stderr=False):
    """Run fq with UTF-8 text stdin and capture both streams as text."""
    return _as_text(run_fq_bytes(args, input_text, env, cwd, timeout,
                                 merge_stderr))


@pytest.fixture(name="run_fq")
def run_fq_fixture(tmp_path):
    """The text-mode run helper, running inside an isolated empty cwd."""

    def _run(args, input_text="", env=None, timeout=10, merge_stderr=False):
        return run_fq(args, input_text, env, str(tmp_path), timeout,
                      merge_stderr)

    return _run


@pytest.fixture(name="run_fq_bytes")
def run_fq_bytes_fixture(tmp_path):
    """The byte-mode run helper, running inside an isolated empty cwd."""

    def _run(args, input_bytes=b"", env=None, timeout=10, merge_stderr=False):
        return run_fq_bytes(args, input_bytes, env, str(tmp_path), timeout,
                            merge_stderr)

    return _run


@pytest.fixture(name="mp3_file")
def mp3_file_fixture(tmp_path):
    """Write the reference mp3 as t.mp3 inside the isolated cwd."""
    p = tmp_path / "t.mp3"
    p.write_bytes(base64.b64decode(MP3_BASE64))
    return p.name


@pytest.fixture(name="write_file")
def write_file_fixture(tmp_path):
    """Write bytes as NAME inside the isolated cwd and return the name.

    Binary fixtures for the non-mp3 formats are embedded as exact byte
    literals in the tests so every run decodes the same input.
    """

    def _write(name, data):
        (tmp_path / name).write_bytes(data)
        return name

    return _write


@pytest.fixture(name="tar_file")
def tar_file_fixture(tmp_path):
    """A one-file ustar archive as hello.tar inside the isolated cwd.

    The 512 byte header is built field by field (name, octal
    mode/uid/gid/size/mtime, checksum, typeflag, ustar magic) so the octal
    scalars, the NUL-trimmed strings and the validators all have known
    values; it is followed by the 6 data bytes, block padding and the
    1024 byte end marker.
    """

    def octal(n, width):
        return ("%0*o" % (width - 1, n)).encode() + b"\x00"

    header = (
        b"hello.txt".ljust(100, b"\x00")
        + octal(0o644, 8) + octal(0, 8) + octal(0, 8)
        + octal(6, 12) + octal(1577836800, 12)
        + b" " * 8 + b"0" + b"\x00" * 100
        + b"ustar\x00" + b"00" + b"\x00" * 32 + b"\x00" * 32
        + octal(0, 8) + octal(0, 8) + b"\x00" * 155 + b"\x00" * 12
    )
    header = (header[:148] + ("%06o" % sum(header)).encode() + b"\x00 "
              + header[156:])
    p = tmp_path / "hello.tar"
    p.write_bytes(header + b"hello\n" + b"\x00" * (512 - 6) + b"\x00" * 1024)
    return p.name


@pytest.fixture(name="mp3_bytes")
def mp3_bytes_fixture():
    """The reference mp3 as raw bytes, for stdin driven runs."""
    return base64.b64decode(MP3_BASE64)


@pytest.fixture(name="long_id3_file")
def long_id3_file_fixture(tmp_path):
    """An mp3 whose id3v2 TIT2 frame holds an 80 character title.

    Used to observe string truncation and display_bytes limits on a
    scalar string field with a long bit range.
    """

    def syncsafe(n):
        return bytes([(n >> 21) & 0x7F, (n >> 14) & 0x7F, (n >> 7) & 0x7F,
                      n & 0x7F])

    title = b"T" * 80
    frame = b"TIT2" + syncsafe(len(title) + 1) + b"\x00\x00" + b"\x00" + title
    tag = b"ID3" + b"\x04\x00" + b"\x00" + syncsafe(len(frame)) + frame
    body = tag + b"\xff\xfb\x40\xc0" + b"\x00" * 200
    p = tmp_path / "long.mp3"
    p.write_bytes(body)
    return p.name
