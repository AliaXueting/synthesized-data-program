"""Decode failure handling: gaps, partial decodes, error fields, exit codes."""


def test_failed_sub_decode_leaves_gap_and_error(run_fq, mp3_file):
    """A decoder that fails early leaves the rest of the buffer as a gap.

    CATCHES: forcing png over an mp3 keeps the error line with the failing
    field ("RawLen(signature)"), the read position and reason, and the whole
    input becomes a single "gap0: raw bits" entry covering 644 bytes.
    """
    result = run_fq(["-d", "bytes", "png | d", mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '     |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: (png)',
        '     |                                               |                |  error: png: RawLen(signature): failed at position 8 (read size 0 seek pos 0): failed to validate raw',
        '0x000|49 44 33 04 00 00 00 00 00 23 54 53 53 45 00 00|ID3......#TSSE..|  gap0: raw bits',
        '*    |until 0x283.7 (end) (644)                      |                |',
    ]) + "\n"
    assert result.stderr == ""


def test_force_option_decodes_partially(run_fq, mp3_file):
    """``-o force=true`` keeps a broken decode instead of failing the run.

    CATCHES: with force the png decoder continues after the bad signature, so
    the dump shows the chunks[0] subtree with its invalid length 2315347 and
    the exit code is 0, not 4.
    """
    result = run_fq(["-o", "force=true", "-d", "png", "d", mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '     |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: t.mp3 (png)',
        '     |                                               |                |  error: png: BitBufRange: failed at position 0 (read size 2315363 seek pos 0): outside buffer',
        '0x000|49 44 33 04 00 00 00 00                        |ID3.....        |  signature: raw bits (invalid)',
        '     |                                               |                |  chunks[0:1]:',
        '     |                                               |                |    [0]{}: chunk',
        '0x000|                        00 23 54 53            |        .#TS    |      length: 2315347',
        '0x000|                                    53 45 00 00|            SE..|      type: "SE\\x00\\x00"',
        '0x000|                                    53         |            S   |      ancillary: false',
        '0x000|                                       45      |             E  |      private: false',
        '0x000|                                          00   |              . |      reserved: false',
        '0x000|                                             00|               .|      safe_to_copy: false',
        '0x010|00 0f 00 00 03 4c 61 76 66 35 38 2e 34 35 2e 31|.....Lavf58.45.1|  gap0: raw bits',
        '*    |until 0x283.7 (end) (628)                      |                |',
    ]) + "\n"
    assert result.stderr == ""


def test_force_via_opts_object_in_expression(run_fq, mp3_file):
    """Force can also be passed as a format option object in the expression.

    CATCHES: ``png({force: true})`` behaves like ``-o force=true`` but the
    value comes from a jq function call, so the root has no file name and is
    labelled just "(png)".
    """
    result = run_fq(["-d", "bytes", "png({force: true}) | d", mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '     |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: (png)',
        '     |                                               |                |  error: png: BitBufRange: failed at position 0 (read size 2315363 seek pos 0): outside buffer',
        '0x000|49 44 33 04 00 00 00 00                        |ID3.....        |  signature: raw bits (invalid)',
        '     |                                               |                |  chunks[0:1]:',
        '     |                                               |                |    [0]{}: chunk',
        '0x000|                        00 23 54 53            |        .#TS    |      length: 2315347',
        '0x000|                                    53 45 00 00|            SE..|      type: "SE\\x00\\x00"',
        '0x000|                                    53         |            S   |      ancillary: false',
        '0x000|                                       45      |             E  |      private: false',
        '0x000|                                          00   |              . |      reserved: false',
        '0x000|                                             00|               .|      safe_to_copy: false',
        '0x010|00 0f 00 00 03 4c 61 76 66 35 38 2e 34 35 2e 31|.....Lavf58.45.1|  gap0: raw bits',
        '*    |until 0x283.7 (end) (628)                      |                |',
    ]) + "\n"
    assert result.stderr == ""


def test_decode_error_carries_field_and_bit_position(run_fq, mp3_file):
    """A field assertion failure names the field, size and fractional position.

    CATCHES: the mp3_frame decoder reports "U11(sync): failed at position
    1.3" - the U11 width, the field name and a bit-precise position (byte 1,
    bit 3), and the partially built "header{}" node is still shown.
    """
    result = run_fq(["-d", "mp3_frame", ".", mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '     |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: t.mp3 (mp3_frame)',
        '     |                                               |                |  error: mp3_frame: U11(sync): failed at position 1.3 (read size 0 seek pos 0): failed to assert Uint',
        '     |                                               |                |  header{}:',
        '0x000|49 44 33 04 00 00 00 00 00 23 54 53 53 45 00 00|ID3......#TSSE..|  gap0: raw bits',
        '*    |until 0x283.7 (end) (644)                      |                |',
    ]) + "\n"
    assert result.stderr == ""


def test_broken_mp3_error_and_gap(run_fq):
    """A string that is not an mp3 decodes to empty arrays plus a gap.

    CATCHES: the mp3 decoder reports "no frames found" at position 0x0, keeps
    the headers/frames arrays (empty, shown as [0:0]) and puts the six input
    bytes into gap0 which is dumped in the ascii column as "broken".
    """
    result = run_fq(['-n', '"broken" | mp3 | d'])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: (mp3)',
        '   |                                               |                |  error: mp3: error at position 0x0: no frames found',
        '   |                                               |                |  headers[0:0]:',
        '   |                                               |                |  frames[0:0]:',
        '0x0|62 72 6f 6b 65 6e|                             |broken|         |  gap0: raw bits',
    ]) + "\n"
    assert result.stderr == ""


def test_from_variant_throws_on_decode_error(run_fq):
    """``from_mp3`` turns a decode error into a jq error and exit code 5.

    CATCHES: the plain ``mp3`` function tolerates decode errors, the from_
    variant raises, so the message has no "mp3:" prefix and the process exits
    with the jq error code 5 instead of 0.
    """
    result = run_fq(['-n', '"broken" | from_mp3'])
    assert result.returncode == 5
    assert result.stdout == ""
    assert result.stderr == "error: error at position 0x0: no frames found\n"


def test_from_variant_returns_value_on_success(run_fq, mp3_file):
    """``from_mp3`` re-decodes the value's buffer and reports the format.

    CATCHES: from_ functions work on the current decode value's bits, so
    piping the mp3 root through from_mp3 gives back an mp3 decode value.
    """
    result = run_fq(["-d", "mp3", "from_mp3 | format", mp3_file])
    assert result.returncode == 0
    assert result.stdout == '"mp3"\n'
    assert result.stderr == ""


def test_error_hidden_field_of_failed_decode(run_fq, mp3_file):
    """The ``_error`` hidden key exposes the decode error as a jq value.

    CATCHES: _error is an object with at least "error" and "format" keys where
    the error message has the field prefix stripped (no "png:" in front) and
    the format is the failing decoder's name.
    """
    result = run_fq(["-d", "bytes",
                     'png | ._error | {error, format}', mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '{',
        '  "error": "RawLen(signature): failed at position 8 (read size 0 seek pos 0): failed to validate raw",',
        '  "format": "png"',
        '}',
    ]) + "\n"
    assert result.stderr == ""


def test_try_probe_catches_formats_error(run_fq, mp3_file):
    """A probe failure is catchable in jq and yields a FormatsError value.

    CATCHES: ``try probe catch .`` returns an array (the FormatsError
    alternatives) rather than aborting, so probing failures are ordinary jq
    errors inside expressions.
    """
    result = run_fq(["-d", "bytes", '.[0:1] | try probe catch . | type',
                     mp3_file])
    assert result.returncode == 0
    assert result.stdout == '"array"\n'
    assert result.stderr == ""


def test_error_exit_codes_by_class(run_fq):
    """Different failure classes map to distinct exit codes with messages.

    CATCHES: option/usage errors exit 2, jq compile errors (unknown function)
    exit 3, decode failures exit 4 and jq runtime errors exit 5 - each with
    its own stderr prefix and always empty stdout.
    """
    cases = [
        (["-o", "expr_file=nope.jq", "-n", "1"],
         2, "error: nope.jq: no such file or directory\n"),
        (["-n", "nosuchfunction"],
         3, "error: arg: function not defined: nosuchfunction/0\n"),
        (["-n", "123 | root"],
         5, "error: expected decode value but got: number (123)\n"),
        (["-n", '"aaa" | decode("aaa")'],
         5, "error: format group not found\n"),
    ]
    for args, code, stderr in cases:
        result = run_fq(args)
        assert result.returncode == code, (args, result.stderr)
        assert result.stdout == "", args
        assert result.stderr == stderr, args
