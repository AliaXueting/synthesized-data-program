"""The generated reader families behind pkg/decode.

decode_gen.go, scalar_gen.go and read.go provide every typed field reader
(uint/signed/float/fixed-point of each width and endianness, big integers,
LEB128 varints, unary and length-prefixed text) and the scalar mappers that
turn raw numbers into symbols and descriptions.  Each test here drives one
format that stresses a distinctive reader combination and pins the values a
wrong reader width, byte order, sign extension or symbol mapping would
break.
"""

import json
import struct


def safetensors_bytes():
    """A safetensors file with one tensor per dtype.

    The 8 byte little-endian header size, the JSON header naming nine
    tensors with contiguous data_offsets, then the tensor data laid out
    in that same order.
    """
    tensors = [
        ("f64s", "F64", [2], struct.pack("<2d", 1.5, -2.25)),
        ("f32s", "F32", [3], struct.pack("<3f", 3.5, -0.5, 100.125)),
        ("f16s", "F16", [3], struct.pack("<3e", 1.0, -1.0, 65504.0)),
        ("i64s", "I64", [2], struct.pack("<2q", -1, 9223372036854775807)),
        ("i32s", "I32", [3], struct.pack("<3i", -2147483648, 42, -1)),
        ("i16s", "I16", [2], struct.pack("<2h", -32768, 7)),
        ("i8s", "I8", [3], struct.pack("<3b", -128, 127, -1)),
        ("u8s", "U8", [3], bytes([0, 255, 9])),
        ("bools", "BOOL", [3], bytes([1, 0, 1])),
    ]
    header = {}
    offset = 0
    for name, dtype, shape, data in tensors:
        header[name] = {
            "dtype": dtype,
            "shape": shape,
            "data_offsets": [offset, offset + len(data)],
        }
        offset += len(data)
    header["__metadata__"] = {"license": "apache-2.0"}
    blob = json.dumps(header, separators=(",", ":")).encode()
    return struct.pack("<Q", len(blob)) + blob + b"".join(t[3] for t in tensors)


def wasm_bytes():
    """A tiny wasm module: one type, one function, one export, one body.

    The body mixes unsigned LEB128 local indexes with signed LEB128 i32
    and i64 constants (single and multi byte) and little-endian f32/f64
    constants.
    """
    def uleb(n):
        out = b""
        while True:
            b = n & 0x7F
            n >>= 7
            if n:
                out += bytes([b | 0x80])
            else:
                out += bytes([b])
                return out

    def sleb(n):
        out = b""
        while True:
            b = n & 0x7F
            n >>= 7
            if (n == 0 and not (b & 0x40)) or (n == -1 and (b & 0x40)):
                out += bytes([b])
                return out
            out += bytes([b | 0x80])

    typesec = b"\x01" + b"\x60" + uleb(2) + b"\x7f\x7d" + uleb(1) + b"\x7c"
    funcsec = uleb(1) + uleb(0)
    exportsec = uleb(1) + uleb(3) + b"add" + b"\x00" + uleb(0)
    body = uleb(0)
    body += b"\x20" + uleb(0)
    body += b"\x20" + uleb(1)
    body += b"\x43" + struct.pack("<f", 1.5)
    body += b"\x41" + sleb(-5)
    body += b"\x42" + sleb(-123456)
    body += b"\x44" + struct.pack("<d", 2.5)
    body += b"\x1a" * 4
    body += b"\x41" + sleb(624485)
    body += b"\x1a"
    body += b"\x0b"
    codesec = uleb(1) + uleb(len(body)) + body

    def section(sid, payload):
        return bytes([sid]) + uleb(len(payload)) + payload

    return (b"\x00asm" + struct.pack("<I", 1)
            + section(1, typesec) + section(3, funcsec)
            + section(7, exportsec) + section(10, codesec))


def asn1_bytes():
    """A BER SEQUENCE exercising every scalar TLV shape.

    Integers of 1, 2, 8, 9 and 13 bytes (the last two only fit in a big
    integer), booleans, NULL, an OID, UTF8String, five REAL encodings,
    bit/octet/printable strings, a SET, a context tag, a long-form
    length, an indefinite-length SEQUENCE and a multi-byte tag.
    """
    def tlv(tag, content):
        assert len(content) < 128
        return bytes([tag, len(content)]) + content

    parts = [
        tlv(0x02, b"\x05"),
        tlv(0x02, b"\x80"),
        tlv(0x02, b"\x02\x01"),
        tlv(0x02, b"\x7f\xff\xff\xff\xff\xff\xff\xff"),
        tlv(0x02, b"\x00\xff\xff\xff\xff\xff\xff\xff\xff"),
        tlv(0x02, b"\xff\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"),
        tlv(0x01, b"\xff"),
        tlv(0x01, b"\x00"),
        tlv(0x05, b""),
        tlv(0x06, b"\x2a\x86\x48\x86\xf7\x0d\x01\x01\x0b"),
        tlv(0x0C, "hé".encode()),
        tlv(0x09, b"\x80\x01\x02"),
        tlv(0x09, b"\xc0\x02\x03"),
        tlv(0x09, b"\x90\x01\x03"),
        tlv(0x09, b"\x40"),
        tlv(0x09, b"\x01" + b"123.5"),
        tlv(0x03, b"\x04\xa0"),
        tlv(0x04, b"\xca\xfe"),
        tlv(0x13, b"hi"),
        tlv(0x31, tlv(0x02, b"\x2a")),
        b"\xa0" + bytes([len(tlv(0x02, b"\x07"))]) + tlv(0x02, b"\x07"),
        b"\x02\x81\x01\x2a",
        b"\x30\x80" + tlv(0x02, b"\x63") + b"\x00\x00",
        b"\x9f\x1f\x01\x2a",
    ]
    content = b"".join(parts)
    assert len(content) < 256
    return b"\x30\x81" + bytes([len(content)]) + content


def mp4_bytes():
    """An mp4 with ftyp, mvhd v0 and trak/edts/elst.

    mvhd holds 16.16 and 8.8 fixed points and the quicktime-epoch
    timestamps; elst v0 holds signed 32-bit durations and media times
    where -1 means "empty".
    """
    def box(typ, payload):
        return struct.pack(">I", 8 + len(payload)) + typ + payload

    ftyp = box(b"ftyp", b"isom" + struct.pack(">I", 0x200)
               + b"isomiso2avc1mp41")
    mvhd = struct.pack(">B", 0) + b"\x00\x00\x00"
    mvhd += struct.pack(">I", 0) + struct.pack(">I", 3519744000)
    mvhd += struct.pack(">I", 1000) + struct.pack(">I", 60000)
    mvhd += struct.pack(">I", 0x00010000) + struct.pack(">H", 0x0100)
    mvhd += b"\x00" * 10
    mvhd += struct.pack(">9i", 0x10000, 0, 0, 0, 0x10000, 0, 0, 0,
                        0x40000000)
    mvhd += struct.pack(">6I", 0, 0, 0, 0, 0, 0) + struct.pack(">I", 3)
    elst = struct.pack(">B", 0) + b"\x00\x00\x00" + struct.pack(">I", 2)
    elst += struct.pack(">ii", 1000, -1) + struct.pack(">i", 0x00010000)
    elst += struct.pack(">ii", 2147483647, 12345) + struct.pack(">i", 0)
    moov = box(b"moov", box(b"mvhd", mvhd)
               + box(b"trak", box(b"edts", box(b"elst", elst))))
    return ftyp + moov


def flac_frame_bytes():
    """A flac file with STREAMINFO and one two-sample frame.

    The frame's first subframe is FIXED order 0 with a rice partition
    (parameter 2) holding two unary+binary residuals; the second is a
    CONSTANT subframe with one wasted bit.  Header CRC-8 and footer
    CRC-16 are computed with fq's non-reflected tables.
    """
    class BitWriter:
        def __init__(self):
            self.bits = []

        def w(self, val, n):
            for i in range(n - 1, -1, -1):
                self.bits.append((val >> i) & 1)

        def nbits(self):
            return len(self.bits)

        def bytes(self):
            assert self.nbits() % 8 == 0
            out = bytearray()
            for i in range(0, self.nbits(), 8):
                b = 0
                for bit in self.bits[i:i + 8]:
                    b = (b << 1) | bit
                out.append(b)
            return bytes(out)

    def crc_table(poly, bits):
        mask = (1 << bits) - 1
        table = []
        for i in range(256):
            crc = i << (bits - 8)
            for _ in range(8):
                if crc & (1 << (bits - 1)):
                    crc = ((crc << 1) ^ poly) & mask
                else:
                    crc = (crc << 1) & mask
            table.append(crc)
        return table

    t8 = crc_table(0x7, 8)
    t16 = crc_table(0x8005, 16)

    def crc8(data):
        c = 0
        for b in data:
            c = t8[c ^ b]
        return c

    def crc16(data):
        c = 0
        for b in data:
            c = ((c << 8) ^ t16[(c >> 8) ^ b]) & 0xFFFF
        return c

    streaminfo = BitWriter()
    streaminfo.w(2, 16)
    streaminfo.w(2, 16)
    streaminfo.w(0, 24)
    streaminfo.w(0, 24)
    streaminfo.w(44100, 20)
    streaminfo.w(1, 3)
    streaminfo.w(15, 5)
    streaminfo.w(2, 36)
    streaminfo.w(0, 128)
    flac = b"fLaC" + bytes([0x80, 0, 0, 34]) + streaminfo.bytes()

    frame = BitWriter()
    frame.w(0b11111111111110, 14)
    frame.w(0, 1)
    frame.w(0, 1)
    frame.w(0b0110, 4)
    frame.w(0b0000, 4)
    frame.w(0b0001, 4)
    frame.w(0b000, 3)
    frame.w(0, 1)
    frame.w(0, 8)
    frame.w(1, 8)
    header = frame.bytes()
    frame.w(crc8(header), 8)

    frame.w(0, 1)
    frame.w(0b001000, 6)
    frame.w(0, 1)
    frame.w(0b00, 2)
    frame.w(0b0000, 4)
    frame.w(0b0010, 4)
    frame.w(1, 1)
    frame.w(0b10, 2)
    frame.w(1, 1)
    frame.w(0b01, 2)

    frame.w(0, 1)
    frame.w(0b000000, 6)
    frame.w(1, 1)
    frame.w(1, 1)
    frame.w(0b111111111111110, 15)

    while frame.nbits() % 8:
        frame.w(0, 1)
    body = frame.bytes()
    crc = crc16(body)
    return flac + body + bytes([crc >> 8, crc & 0xFF])


def dns_bytes():
    """A DNS response answering an A question with one TXT record.

    The answer name is a compression pointer back to the question name
    and the TXT rdata holds two 1-byte length-prefixed strings.
    """
    msg = struct.pack(">HHHHHH", 0x1234, 0x8180, 1, 1, 0, 0)
    msg += b"\x07example\x03com\x00" + struct.pack(">HH", 1, 1)
    rdata = b"\x05hello" + b"\x04word"
    msg += b"\xc0\x0c" + struct.pack(">HHIH", 16, 1, 300, len(rdata))
    msg += rdata
    return msg


def ar_bytes():
    """An ar archive with two members, the second needing odd-size padding."""
    def header(ident, mtime, owner, group, mode, size):
        h = (ident.encode().ljust(16) + str(mtime).encode().ljust(12)
             + str(owner).encode().ljust(6) + str(group).encode().ljust(6)
             + mode.encode().ljust(8) + str(size).encode().ljust(10)
             + b"`\n")
        assert len(h) == 60
        return h

    archive = b"!<arch>\n"
    archive += header("hello.txt/", 1234567890, 0, 0, "100644", 6)
    archive += b"hello\n"
    archive += header("even.bin", 42, 1000, 1000, "644", 3)
    archive += b"abc" + b"\n"
    return archive


def nes_bytes():
    """An iNES 1.0 ROM: 16 byte header, 16KB PRG, 8KB CHR.

    The first CHR tile is eight 0xff bytes (lsb plane) then eight 0x00
    bytes; the PRG data starts with 0x00 (BRK) 0x01 0x02 ...
    """
    header = b"NES\x1a" + bytes([1, 1, 0x01, 0x00, 0, 0, 0, 0, 0, 0, 0, 0])
    prg = bytes(range(256)) * 64
    chr_rom = bytes([0xFF, 0x00] + [0] * (8192 - 2))
    return header + prg + chr_rom


def icc_bytes():
    """An ICC profile with desc, XYZ, text, curv and mluc tags.

    Tag sizes are the exact decoded lengths so fq adds alignment fields
    for the 4-byte padding between tags.
    """
    def header():
        h = struct.pack(">I", 0)
        h += b"appl" + bytes([0x02, 0x10]) + struct.pack(">H", 0)
        h += b"mntr" + b"RGB " + b"XYZ "
        h += struct.pack(">6H", 2021, 1, 2, 3, 4, 5)
        h += b"acsp" + b"APPL" + struct.pack(">I", 0)
        h += b"none" + b"none" + b"\x00" * 8 + b"\x00" * 4
        h += struct.pack(">3i", 0x0000F6D6, 0x00010000, 0x0000D32D)
        h += b"none" + b"\x00" * 16 + b"\x00" * 28
        assert len(h) == 128
        return h

    tags = []
    desc = b"desc" + b"\x00" * 4
    desc += struct.pack(">I", 5) + b"ICC!\x00"
    desc += struct.pack(">I", 0)
    desc += struct.pack(">I", 4) + b"loc\x00"
    desc += struct.pack(">H", 0) + bytes([0])
    desc += b"Mac description".ljust(67, b"\x00")
    tags.append((b"desc", desc))
    tags.append((b"wtpt", b"XYZ " + b"\x00" * 4
                 + struct.pack(">3i", 0x0000F6D6, 0x00010000, 0x0000D32D)))
    tags.append((b"cprt", b"text" + b"\x00" * 4 + b"no rights reserved\x00"))
    tags.append((b"gamm", b"curv" + b"\x00" * 4 + struct.pack(">I", 1)
                 + struct.pack(">H", 0x0233)))
    name = "héllö".encode("utf-16-be")
    mluc = b"mluc" + b"\x00" * 4 + struct.pack(">II", 1, 12)
    mluc += b"en" + b"US" + struct.pack(">II", len(name), 28) + name
    tags.append((b"mluc", mluc))

    def pad4(b):
        return b + b"\x00" * (-len(b) % 4)

    offset = 128 + 4 + 12 * len(tags)
    table = struct.pack(">I", len(tags))
    for sig, data in tags:
        table += sig + struct.pack(">II", offset, len(data))
        offset += len(pad4(data))
    profile = header() + table + b"".join(pad4(d) for _, d in tags)
    return struct.pack(">I", len(profile)) + profile[4:]


def test_safetensors_float_dtypes_decode_exact_widths(write_file, run_fq):
    """F64/F32/F16 tensor elements decode with their exact float widths.

    CATCHES: 1.5/-2.25 as f64, 3.5/-0.5/100.125 as f32 and 1/-1/65504 as
    f16 - a reader that mixes up widths or reverses bytes shifts every
    value, and 65504 is exactly the ieee half-precision maximum.
    """
    f = write_file("t.bin", safetensors_bytes())
    result = run_fq([
        "-d", "safetensors",
        "{f64: .tensors.f64s.data, f32: .tensors.f32s.data,"
        " f16: .tensors.f16s.data} | tovalue",
        f,
    ])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        "{",
        '  "f16": [',
        "    1,",
        "    -1,",
        "    65504",
        "  ],",
        '  "f32": [',
        "    3.5,",
        "    -0.5,",
        "    100.125",
        "  ],",
        '  "f64": [',
        "    1.5,",
        "    -2.25",
        "  ]",
        "}",
    ]) + "\n"
    assert result.stderr == ""


def test_safetensors_int_dtypes_and_sign_extension(write_file, run_fq):
    """Signed tensor dtypes keep two's-complement sign extension.

    CATCHES: i8 -128, i16 -32768, i32 -2147483648 and i64 -1 /
    9223372036854775807 decode sign-extended at each width while u8
    stays unsigned - a reader reusing the unsigned path returns 128,
    32768, 2147483648 and 18446744073709551615 instead.
    """
    f = write_file("t.bin", safetensors_bytes())
    result = run_fq([
        "-d", "safetensors",
        "{i64: .tensors.i64s.data, i32: .tensors.i32s.data,"
        " i16: .tensors.i16s.data, i8: .tensors.i8s.data,"
        " u8: .tensors.u8s.data} | tovalue",
        f,
    ])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        "{",
        '  "i16": [',
        "    -32768,",
        "    7",
        "  ],",
        '  "i32": [',
        "    -2147483648,",
        "    42,",
        "    -1",
        "  ],",
        '  "i64": [',
        "    -1,",
        "    9223372036854775807",
        "  ],",
        '  "i8": [',
        "    -128,",
        "    127,",
        "    -1",
        "  ],",
        '  "u8": [',
        "    0,",
        "    255,",
        "    9",
        "  ]",
        "}",
    ]) + "\n"
    assert result.stderr == ""


def test_safetensors_bool_reads_bits_and_gap_pads(write_file, run_fq):
    """BOOL tensor elements are single bits and leave a bit-aligned gap.

    CATCHES: the bytes 01 00 01 decode as [false,false,false] because
    each BOOL element reads one BIT (the msb side of 0x01), so the file
    ends with a 21-bit gap whose tovalue pads trailing zero bits to
    "\\b\\u0000\\b" while tobytes returns the three whole bytes "AQAB".
    """
    f = write_file("t.bin", safetensors_bytes())

    bools = run_fq(["-d", "safetensors", ".tensors.bools.data | tovalue", f])
    assert bools.returncode == 0
    assert bools.stdout == "[\n  false,\n  false,\n  false\n]\n"

    gap_value = run_fq(["-d", "safetensors", ".gap0 | tovalue", f])
    assert gap_value.returncode == 0
    assert gap_value.stdout == '"\\b\\u0000\\b"\n'

    gap_bytes = run_fq(["-d", "safetensors",
                        ".gap0 | tobytes | @base64", f])
    assert gap_bytes.returncode == 0
    assert gap_bytes.stdout == '"AQAB"\n'

    header = run_fq(["-d", "safetensors",
                     "[.header_size, .header.__metadata__.license]"
                     " | tovalue", f])
    assert header.returncode == 0
    assert header.stdout == '[\n  560,\n  "apache-2.0"\n]\n'
    assert header.stderr == ""


def test_wasm_leb128_consts_and_float_instructions(write_file, run_fq):
    """wasm immediates decode via unsigned and signed LEB128.

    CATCHES: i32.const -5 and i64.const -123456 decode through signed
    LEB128 sign extension, 624485 needs three 7-bit groups, local.get
    indexes are unsigned LEB128, and f32.const 1.5 / f64.const 2.5 read
    little-endian ieee payloads.
    """
    f = write_file("t.wasm", wasm_bytes())

    ids = run_fq(["-d", "wasm", "[.sections[] | .id] | tovalue", f])
    assert ids.returncode == 0
    assert ids.stdout == "\n".join([
        "[",
        '  "type_section",',
        '  "function_section",',
        '  "export_section",',
        '  "code_section"',
        "]",
    ]) + "\n"
    assert ids.stderr == ""

    opcodes = run_fq(["-d", "wasm",
                      "[.sections[3].content.code.x[0].code.e[]"
                      " | .opcode] | tovalue", f])
    assert opcodes.returncode == 0
    assert opcodes.stdout == "\n".join([
        "[",
        '  "local.get",',
        '  "local.get",',
        '  "f32.const",',
        '  "i32.const",',
        '  "i64.const",',
        '  "f64.const",',
        '  "drop",',
        '  "drop",',
        '  "drop",',
        '  "drop",',
        '  "i32.const",',
        '  "drop",',
        '  "end"',
        "]",
    ]) + "\n"

    values = run_fq(["-d", "wasm",
                     "[.sections[3].content.code.x[0].code.e[]"
                     " | .n // .z // .x] | tovalue", f])
    assert values.returncode == 0
    assert values.stdout == "\n".join([
        "[",
        "  0,",
        "  1,",
        "  1.5,",
        "  -5,",
        "  -123456,",
        "  2.5,",
        "  null,",
        "  null,",
        "  null,",
        "  null,",
        "  624485,",
        "  null,",
        "  null",
        "]",
    ]) + "\n"

    export = run_fq(["-d", "wasm",
                     ".sections[2].content.ex.x[0] | tovalue", f])
    assert export.returncode == 0
    assert export.stdout == "\n".join([
        "{",
        '  "d": {',
        '    "tag": "funcidx",',
        '    "x": 0',
        "  },",
        '  "nm": {',
        '    "b": "add",',
        "    \"n\": 3",
        "  }",
        "}",
    ]) + "\n"


def test_asn1_ber_integer_widths_and_bigints(write_file, run_fq):
    """BER INTEGER decodes sign-extended and switches to big integers.

    CATCHES: 1/2/8 byte integers keep two's-complement values (5, -128,
    513, 9223372036854775807) while lengths over 8 bytes decode as full
    precision big integers 18446744073709551615 and
    -79226953588444722964369244160 - values an int64 reader cannot hold.
    """
    f = write_file("t.der", asn1_bytes())
    result = run_fq(["-d", "asn1_ber",
                     "[.constructed[] | {tag, value}] | tovalue", f])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        "[",
        "  {",
        '    "tag": "integer",',
        '    "value": 5',
        "  },",
        "  {",
        '    "tag": "integer",',
        '    "value": -128',
        "  },",
        "  {",
        '    "tag": "integer",',
        '    "value": 513',
        "  },",
        "  {",
        '    "tag": "integer",',
        '    "value": 9223372036854775807',
        "  },",
        "  {",
        '    "tag": "integer",',
        '    "value": 18446744073709551615',
        "  },",
        "  {",
        '    "tag": "integer",',
        '    "value": -79226953588444722964369244160',
        "  },",
        "  {",
        '    "tag": "boolean",',
        '    "value": true',
        "  },",
        "  {",
        '    "tag": "boolean",',
        '    "value": false',
        "  },",
        "  {",
        '    "tag": "null",',
        '    "value": null',
        "  },",
        "  {",
        '    "tag": "object_identifier",',
        '    "value": [',
        "      1,",
        "      2,",
        "      840,",
        "      113549,",
        "      1,",
        "      1,",
        "      11",
        "    ]",
        "  },",
        "  {",
        '    "tag": "utf8_string",',
        '    "value": "hé"',
        "  },",
        "  {",
        '    "tag": "real",',
        '    "value": 4',
        "  },",
        "  {",
        '    "tag": "real",',
        '    "value": -12',
        "  },",
        "  {",
        '    "tag": "real",',
        '    "value": 24',
        "  },",
        "  {",
        '    "tag": "real",',
        '    "value": 1.7976931348623157e+308',
        "  },",
        "  {",
        '    "tag": "real",',
        '    "value": 123.5',
        "  },",
        "  {",
        '    "tag": "bit_string",',
        '    "value": "\\ufffd"',
        "  },",
        "  {",
        '    "tag": "octet_string",',
        '    "value": "\\ufffd\\ufffd"',
        "  },",
        "  {",
        '    "tag": "printable_string",',
        '    "value": "hi"',
        "  },",
        "  {",
        '    "tag": "set",',
        '    "value": null',
        "  },",
        "  {",
        '    "tag": 0,',
        '    "value": null',
        "  },",
        "  {",
        '    "tag": "integer",',
        '    "value": 42',
        "  },",
        "  {",
        '    "tag": "sequence",',
        '    "value": null',
        "  },",
        "  {",
        '    "tag": 3999,',
        '    "value": "*"',
        "  }",
        "]",
    ]) + "\n"
    assert result.stderr == ""


def test_asn1_ber_real_signs_null_and_multibyte_tag(write_file, run_fq):
    """BER REAL parts, NULL length, indefinite end marker and long tags.

    CATCHES: a binary REAL reassembles sign*base^exp*n (sign -1 gives
    -12, base 8 gives 24), the +infinity special renders as jq's maximum
    float 1.7976931348623157e+308, NULL has length "indefinite", an
    indefinite SEQUENCE ends with end_marker 0, and the tag bytes
    9f 1f decode as tag number 3999 with a raw "*" value.
    """
    f = write_file("t.der", asn1_bytes())

    negative_real = run_fq(["-d", "asn1_ber", ".constructed[12] | tovalue",
                            f])
    assert negative_real.returncode == 0
    assert negative_real.stdout == "\n".join([
        "{",
        '  "base": 2,',
        '  "binary_encoding": true,',
        '  "class": "universal",',
        '  "exp": 2,',
        '  "form": "primitive",',
        '  "format": 0,',
        '  "length": 3,',
        '  "n": 3,',
        '  "scale": 0,',
        '  "sign": -1,',
        '  "tag": "real",',
        '  "value": -12',
        "}",
    ]) + "\n"
    assert negative_real.stderr == ""

    infinity = run_fq(["-d", "asn1_ber", ".constructed[14] | tovalue", f])
    assert infinity.returncode == 0
    assert infinity.stdout == "\n".join([
        "{",
        '  "binary_encoding": false,',
        '  "class": "universal",',
        '  "decimal_encoding": true,',
        '  "form": "primitive",',
        '  "length": 1,',
        '  "special": "plus_infinity",',
        '  "tag": "real",',
        '  "value": 1.7976931348623157e+308',
        "}",
    ]) + "\n"

    null_value = run_fq(["-d", "asn1_ber", ".constructed[8] | tovalue", f])
    assert null_value.returncode == 0
    assert null_value.stdout == "\n".join([
        "{",
        '  "class": "universal",',
        '  "form": "primitive",',
        '  "length": "indefinite",',
        '  "tag": "null",',
        '  "value": null',
        "}",
    ]) + "\n"

    indefinite = run_fq(["-d", "asn1_ber", ".constructed[22] | tovalue",
                         f])
    assert indefinite.returncode == 0
    assert indefinite.stdout == "\n".join([
        "{",
        '  "class": "universal",',
        '  "constructed": [',
        "    {",
        '      "class": "universal",',
        '      "form": "primitive",',
        '      "length": 1,',
        '      "tag": "integer",',
        '      "value": 99',
        "    }",
        "  ],",
        '  "end_marker": 0,',
        '  "form": "constructed",',
        '  "length": "indefinite",',
        '  "tag": "sequence"',
        "}",
    ]) + "\n"

    long_tag = run_fq(["-d", "asn1_ber", ".constructed[23] | tovalue", f])
    assert long_tag.returncode == 0
    assert long_tag.stdout == "\n".join([
        "{",
        '  "class": "context",',
        '  "form": "primitive",',
        '  "length": 1,',
        '  "tag": 3999,',
        '  "value": "*"',
        "}",
    ]) + "\n"


def test_mp4_mvhd_fixed_point_and_quicktime_dates(write_file, run_fq):
    """mvhd decodes 16.16/8.8 fixed points and quicktime-epoch times.

    CATCHES: preferred_rate 0x00010000 and volume 0x0100 are fixed point
    1, the matrix entries decode as 1/0 with w 0x40000000 also 1, and
    modification_time 3519744000 keeps its seconds value while the dump
    renders it as 2015-07-14T18:40:00Z since 1904-01-01.
    """
    f = write_file("t.mp4", mp4_bytes())

    mvhd = run_fq(["-d", "mp4",
                   ".boxes[1].boxes[0] | {version, creation_time,"
                   " modification_time, time_scale, duration,"
                   " preferred_rate, preferred_volume, next_track_id}"
                   " | tovalue", f])
    assert mvhd.returncode == 0
    assert mvhd.stdout == "\n".join([
        "{",
        '  "creation_time": 0,',
        '  "duration": 60000,',
        '  "modification_time": 3519744000,',
        '  "next_track_id": 3,',
        '  "preferred_rate": 1,',
        '  "preferred_volume": 1,',
        '  "time_scale": 1000,',
        '  "version": 0',
        "}",
    ]) + "\n"
    assert mvhd.stderr == ""

    matrix = run_fq(["-d", "mp4",
                     ".boxes[1].boxes[0].matrix_structure | tovalue", f])
    assert matrix.returncode == 0
    assert matrix.stdout == "\n".join([
        "{",
        '  "a": 1,',
        '  "b": 0,',
        '  "c": 0,',
        '  "d": 1,',
        '  "u": 0,',
        '  "v": 0,',
        '  "w": 1,',
        '  "x": 0,',
        '  "y": 0',
        "}",
    ]) + "\n"

    types = run_fq(["-d", "mp4", "[.boxes[] | .type] | tovalue", f])
    assert types.returncode == 0
    assert types.stdout == '[\n  "ftyp",\n  "moov"\n]\n'


def test_mp4_elst_signed_media_time_descriptions(write_file, run_fq):
    """elst decodes signed 32-bit entries with an "empty" description.

    CATCHES: segment_duration 2147483647 and media_time -1 need the
    signed reader, media_time -1 gains the description "(empty)" in the
    dump while tovalue keeps -1, and media_rate is the same 16.16 fixed
    point as mvhd's preferred_rate.
    """
    f = write_file("t.mp4", mp4_bytes())

    elst = run_fq(["-d", "mp4",
                   ".boxes[1].boxes[1].boxes[0].boxes[0] | tovalue", f])
    assert elst.returncode == 0
    assert elst.stdout == "\n".join([
        "{",
        '  "entries": [',
        "    {",
        '      "media_rate": 1,',
        '      "media_time": -1,',
        '      "segment_duration": 1000',
        "    },",
        "    {",
        '      "media_rate": 0,',
        '      "media_time": 12345,',
        '      "segment_duration": 2147483647',
        "    }",
        "  ],",
        '  "entry_count": 2,',
        '  "flags": 0,',
        '  "size": 40,',
        '  "type": "elst",',
        '  "version": 0',
        "}",
    ]) + "\n"
    assert elst.stderr == ""

    dump = run_fq(["-d", "mp4",
                   ".boxes[1].boxes[1].boxes[0].boxes[0] | d", f])
    assert dump.returncode == 0
    assert dump.stdout == "\n".join([
        "    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
        "|0123456789abcdef|.boxes[1].boxes[1].boxes[0].boxes[0]{}: box",
        "0xa0|            00 00 00 28                        "
        "|    ...(        |  size: 40",
        "0xa0|                        65 6c 73 74            "
        "|        elst    |  type: \"elst\" (An edit list)",
        "0xa0|                                    00         "
        "|            .   |  version: 0",
        "0xa0|                                       00 00 00"
        "|             ...|  flags: 0",
        "0xb0|00 00 00 02                                    "
        "|....            |  entry_count: 2",
        "    |                                               "
        "|                |  entries[0:2]:",
        "    |                                               "
        "|                |    [0]{}: entry",
        "0xb0|            00 00 03 e8                        "
        "|    ....        |      segment_duration: 1000",
        "0xb0|                        ff ff ff ff            "
        "|        ....    |      media_time: -1 (empty)",
        "0xb0|                                    00 01 00 00"
        "|            ....|      media_rate: 1",
        "    |                                               "
        "|                |    [1]{}: entry",
        "0xc0|7f ff ff ff                                    "
        "|....            |      segment_duration: 2147483647",
        "0xc0|            00 00 30 39                        "
        "|    ..09        |      media_time: 12345",
        "0xc0|                        00 00 00 00|           "
        "|        ....|   |      media_rate: 0",
    ]) + "\n"
    assert dump.stderr == ""


def test_flac_frame_rice_residuals_and_wasted_bits(write_file, run_fq):
    """flac frames decode rice residuals, unary wasted bits and CRCs.

    CATCHES: each rice residual splits into a unary high of 0 and a
    2-bit low zigzagged to 1 and -1, the constant subframe's 15-bit -2
    with 1 wasted bit shifts its samples to -4, subframe_sample_size
    drops to 15, and the header CRC-8 0x4f plus footer CRC-16 a723 both
    validate against the recorded bytes.
    """
    f = write_file("t.flac", flac_frame_bytes())

    fixed = run_fq(["-d", "flac", "-o", "sample_details=true",
                    ".frames[0].subframes[0] | tovalue", f])
    assert fixed.returncode == 0
    assert fixed.stdout == "\n".join([
        "{",
        '  "lpc_order": 0,',
        '  "partition_order": 0,',
        '  "partitions": [',
        "    {",
        '      "count": 2,',
        '      "residuals": [',
        "        {",
        '          "high": 0,',
        '          "low": 2,',
        '          "value": 1',
        "        },",
        "        {",
        '          "high": 0,',
        '          "low": 1,',
        '          "value": -1',
        "        }",
        "      ],",
        '      "rice_parameter": 2',
        "    }",
        "  ],",
        '  "residual_coding_method": 4,',
        '  "rice_partitions": 1,',
        '  "samples": [',
        "    1,",
        "    -1",
        "  ],",
        '  "subframe_sample_size": 16,',
        '  "subframe_type": "fixed",',
        '  "warmup_samples": [],',
        '  "wasted_bits_flag": 0,',
        '  "zero_bit": 0',
        "}",
    ]) + "\n"
    assert fixed.stderr == ""

    constant = run_fq(["-d", "flac", "-o", "sample_details=true",
                       ".frames[0].subframes[1] | tovalue", f])
    assert constant.returncode == 0
    assert constant.stdout == "\n".join([
        "{",
        '  "samples": [',
        "    -4,",
        "    -4",
        "  ],",
        '  "subframe_sample_size": 15,',
        '  "subframe_type": "constant",',
        '  "value": -2,',
        '  "wasted_bits_flag": 1,',
        '  "wasted_bits_k": 1,',
        '  "zero_bit": 0',
        "}",
    ]) + "\n"

    header = run_fq(["-d", "flac",
                     "[.frames[0].header | .crc, .block_size,"
                     " .channel_assignment, .sync, .sample_rate]"
                     " | tovalue", f])
    assert header.returncode == 0
    assert header.stdout == "[\n  79,\n  6,\n  2,\n  16382,\n  0\n]\n"

    footer = run_fq(["-d", "flac",
                     "[.frames[0] | .byte_align, .footer_crc]"
                     " | tovalue", f])
    assert footer.returncode == 0
    assert footer.stdout == '[\n  0,\n  "a723"\n]\n'

    summary = run_fq(["-d", "flac",
                      "[.decoded_samples, .md5_calculated] | tovalue", f])
    assert summary.returncode == 0
    assert summary.stdout == "\n".join([
        "[",
        "  2,",
        '  "56c2e6e01e6b14adc424daa7bb93886d"',
        "]",
    ]) + "\n"


def test_dns_txt_short_strings_and_name_pointer(write_file, run_fq):
    """DNS TXT records use 1-byte length-prefixed short strings.

    CATCHES: the two strings "hello" and "word" are pascal-style
    length-prefixed and joined into "helloword", and the answer's
    compression pointer c0 0c decodes as is_pointer 3 and pointer 12
    followed by the labels it resolves to (example.com).
    """
    f = write_file("t.dns", dns_bytes())

    answer = run_fq(["-d", "dns", ".answers[0] | tovalue", f])
    assert answer.returncode == 0
    assert answer.stdout == "\n".join([
        "{",
        '  "class": "in",',
        '  "name": {',
        '    "labels": [',
        "      {",
        '        "is_pointer": 3,',
        '        "length": 7,',
        '        "pointer": 12,',
        '        "value": "example"',
        "      },",
        "      {",
        '        "length": 3,',
        '        "value": "com"',
        "      },",
        "      {",
        '        "length": 0',
        "      }",
        "    ],",
        '    "value": "example.com"',
        "  },",
        '  "rdlength": 11,',
        '  "ttl": 300,',
        '  "txt": {',
        '    "strings": [',
        '      "hello",',
        '      "word"',
        "    ],",
        '    "value": "helloword"',
        "  },",
        '  "type": "txt"',
        "}",
    ]) + "\n"
    assert answer.stderr == ""

    header = run_fq(["-d", "dns", ".header | tovalue", f])
    assert header.returncode == 0
    assert header.stdout == "\n".join([
        "{",
        '  "authoritative_answer": false,',
        '  "id": 4660,',
        '  "opcode": "query",',
        '  "qr": "response",',
        '  "rcode": "no_error",',
        '  "recursion_available": true,',
        '  "recursion_desired": true,',
        '  "truncation": false,',
        '  "z": 0',
        "}",
    ]) + "\n"


def test_ar_string_scalars_and_auto_probe(write_file, run_fq):
    """ar members parse decimal and octal header strings into symbols.

    CATCHES: file_mode "100644"/"644" parse as octal 33188/420 and
    sizes/timestamps as decimal, each shown beside its string actual in
    the dump, an odd-size member gains a padding byte, and the whole
    archive is found by auto-probing without any -d flag.
    """
    f = write_file("t.a", ar_bytes())

    values = run_fq(["[.files[] | {identifier, modification_timestamp,"
                     " file_mode, file_size}] | tovalue", f])
    assert values.returncode == 0
    assert values.stdout == "\n".join([
        "[",
        "  {",
        '    "file_mode": 33188,',
        '    "file_size": 6,',
        '    "identifier": "hello.txt/",',
        '    "modification_timestamp": 1234567890',
        "  },",
        "  {",
        '    "file_mode": 420,',
        '    "file_size": 3,',
        '    "identifier": "even.bin",',
        '    "modification_timestamp": 42',
        "  }",
        "]",
    ]) + "\n"
    assert values.stderr == ""

    dump = run_fq(["d", f])
    assert dump.returncode == 0
    assert dump.stdout == "\n".join([
        "    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
        "|0123456789abcdef|.{}: t.a (ar)",
        "0x00|21 3c 61 72 63 68 3e 0a                        "
        "|!<arch>.        |  signature: \"!<arch>\\n\" (valid)",
        "    |                                               "
        "|                |  files[0:2]:",
        "    |                                               "
        "|                |    [0]{}: file",
        "0x00|                        68 65 6c 6c 6f 2e 74 78"
        "|        hello.tx|      identifier: \"hello.txt/\"",
        "0x10|74 2f 20 20 20 20 20 20                        "
        "|t/              |",
        "0x10|                        31 32 33 34 35 36 37 38"
        "|        12345678|      modification_timestamp:"
        " 1234567890 (\"1234567890\")",
        "0x20|39 30 20 20                                    "
        "|90              |",
        "0x20|            30 20 20 20 20 20                  "
        "|    0           |      owner_id: 0 (\"0\")",
        "0x20|                              30 20 20 20 20 20"
        "|          0     |      group_id: 0 (\"0\")",
        "0x30|31 30 30 36 34 34 20 20                        "
        "|100644          |      file_mode: 33188 (\"100644\")",
        "0x30|                        36 20 20 20 20 20 20 20"
        "|        6       |      file_size: 6 (\"6\")",
        "0x40|20 20                                          "
        "|                |",
        "0x40|      60 0a                                    "
        "|  `.            |      ending_characters: \"`\\n\"",
        "0x40|            68 65 6c 6c 6f 0a                  "
        "|    hello.      |      data: raw bits",
        "    |                                               "
        "|                |    [1]{}: file",
        "0x40|                              65 76 65 6e 2e 62"
        "|          even.b|      identifier: \"even.bin\"",
        "0x50|69 6e 20 20 20 20 20 20 20 20                  "
        "|in              |",
        "0x50|                              34 32 20 20 20 20"
        "|          42    |      modification_timestamp: 42 (\"42\")",
        "0x60|20 20 20 20 20 20                              "
        "|                |",
        "0x60|                  31 30 30 30 20 20            "
        "|      1000      |      owner_id: 1000 (\"1000\")",
        "0x60|                                    31 30 30 30"
        "|            1000|      group_id: 1000 (\"1000\")",
        "0x70|20 20                                          "
        "|                |",
        "0x70|      36 34 34 20 20 20 20 20                  "
        "|  644           |      file_mode: 420 (\"644\")",
        "0x70|                              33 20 20 20 20 20"
        "|          3     |      file_size: 3 (\"3\")",
        "0x80|20 20 20 20                                    "
        "|                |",
        "0x80|            60 0a                              "
        "|    `.          |      ending_characters: \"`\\n\"",
        "0x80|                  61 62 63                     "
        "|      abc       |      data: raw bits",
        "0x80|                           0a|                 "
        "|         .|     |      padding: raw bits",
    ]) + "\n"
    assert dump.stderr == ""


def test_nes_header_symbols_and_chr_tiles(write_file, run_fq):
    """iNES decodes flag symbols, ram size mappers and CHR pixel planes.

    CATCHES: flags6 0x01 means vertical mirroring shown as "horizontal"
    nametable layout with mapper 0, prg/chr sizes double to 16384/8192
    and prg_ram 0 maps to 8192, and each CHR tile renders its two planes
    as 64-bit binary strings ("11111111000..." for the 0xff plane).
    """
    f = write_file("t.nes", nes_bytes())

    header = run_fq(["-d", "nes", ".header | tovalue", f])
    assert header.returncode == 0
    assert header.stdout == "\n".join([
        "{",
        '  "alternative_nametables": "no",',
        '  "battery": "no",',
        '  "byte_10": 0,',
        '  "byte_9": 0,',
        '  "chr_ram_size": 0,',
        '  "chr_rom_size": 8192,',
        '  "console_type": "nes",',
        '  "identifier": "NES\\u001a",',
        '  "mapper": 0,',
        '  "mapper0": 0,',
        '  "mapper1": 0,',
        '  "nametable_layout": "horizontal",',
        '  "nes20_identifier": "no",',
        '  "prg_ram_size": 8192,',
        '  "prg_rom_size": 16384,',
        '  "trainer": "no",',
        '  "unused": "\\u0000\\u0000\\u0000\\u0000\\u0000"',
        "}",
    ]) + "\n"
    assert header.stderr == ""

    tile = run_fq(["-d", "nes", ".chr_rom[0] | tovalue", f])
    assert tile.returncode == 0
    assert tile.stdout == "\n".join([
        "{",
        '  "combined": "' + "01 " * 8 + "00 " * 56 + '",',
        '  "pixels_lsb": "11111111'
        + "0" * 56 + '",',
        '  "pixels_msb": "' + "0" * 64 + '"',
        "}",
    ]) + "\n"

    instruction = run_fq(["-d", "nes", ".prg_rom[0] | tovalue", f])
    assert instruction.returncode == 0
    assert instruction.stdout == '{\n  "op_code": "brk"\n}\n'


def test_icc_fixed_points_bcd_and_utf16(write_file, run_fq):
    """ICC profiles decode BCD versions, fixed-point XYZ and UTF-16BE.

    CATCHES: version bytes 02 10 decode as BCD 2 and 10, the D50 white
    point decodes as s15Fixed16 values 0.964202880859375 / 1 /
    0.8249053955078125, curv count 1 maps to the "simple_gamma" symbol
    with gamma 2.19921875, the mluc name decodes UTF-16BE to "héllö",
    and unaligned tag sizes gain alignment padding fields.
    """
    f = write_file("t.icc", icc_bytes())

    header = run_fq(["-d", "icc_profile",
                     ".header | {size, cmm_type_signature, version_major,"
                     " version_minor, version_reserved,"
                     " device_class_signature, color_space,"
                     " connection_space, file_signature,"
                     " primary_platform, render_intent, xyz_illuminant,"
                     " profile_id} | tovalue", f])
    assert header.returncode == 0
    assert header.stdout == "\n".join([
        "{",
        '  "cmm_type_signature": "appl",',
        '  "color_space": "RGB",',
        '  "connection_space": "XYZ",',
        '  "device_class_signature": "mntr",',
        '  "file_signature": "acsp",',
        '  "primary_platform": "APPL",',
        '  "profile_id": "",',
        '  "render_intent": "",',
        '  "size": 396,',
        '  "version_major": 2,',
        '  "version_minor": 10,',
        '  "version_reserved": 0,',
        '  "xyz_illuminant": ""',
        "}",
    ]) + "\n"
    assert header.stderr == ""

    tags = run_fq(["-d", "icc_profile",
                   "[.tag_table.table[] | {signature, type, offset, size}]"
                   " | tovalue", f])
    assert tags.returncode == 0
    assert tags.stdout == "\n".join([
        "[",
        "  {",
        '    "offset": 192,',
        '    "signature": "desc",',
        '    "size": 99,',
        '    "type": "desc"',
        "  },",
        "  {",
        '    "offset": 292,',
        '    "signature": "wtpt",',
        '    "size": 20,',
        '    "type": "XYZ"',
        "  },",
        "  {",
        '    "offset": 312,',
        '    "signature": "cprt",',
        '    "size": 27,',
        '    "type": "text"',
        "  },",
        "  {",
        '    "offset": 340,',
        '    "signature": "gamm",',
        '    "size": 14,',
        '    "type": "curv"',
        "  },",
        "  {",
        '    "offset": 356,',
        '    "signature": "mluc",',
        '    "size": 38,',
        '    "type": "mluc"',
        "  }",
        "]",
    ]) + "\n"

    values = run_fq([
        "-d", "icc_profile",
        "[.tag_table.table[] | select(.signature == \"wtpt\""
        " or .signature == \"gamm\" or .signature == \"mluc\")"
        " | {signature, x, y, z, gamma, names}] | tovalue",
        f,
    ])
    assert values.returncode == 0
    assert values.stdout == "\n".join([
        "[",
        "  {",
        '    "gamma": null,',
        '    "names": null,',
        '    "signature": "wtpt",',
        '    "x": 0.964202880859375,',
        '    "y": 1,',
        '    "z": 0.8249053955078125',
        "  },",
        "  {",
        '    "gamma": 2.19921875,',
        '    "names": null,',
        '    "signature": "gamm",',
        '    "x": null,',
        '    "y": null,',
        '    "z": null',
        "  },",
        "  {",
        '    "gamma": null,',
        '    "names": [',
        "      {",
        '        "country_code": "US",',
        '        "language_code": "en",',
        '        "name_length": 10,',
        '        "name_offset": 28,',
        '        "value": "héllö"',
        "      }",
        "    ],",
        '    "signature": "mluc",',
        '    "x": null,',
        '    "y": null,',
        '    "z": null',
        "  }",
        "]",
    ]) + "\n"
    assert values.stderr == ""
