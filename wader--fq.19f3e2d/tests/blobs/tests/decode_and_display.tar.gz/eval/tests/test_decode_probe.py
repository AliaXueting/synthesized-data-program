"""Probing and forced decoding: auto-detection, ``-d`` targets, input files."""

# Bytes that no registered probe can decode: 64 ascending byte values.
UNPROBABLE = bytes(range(64))


def test_probe_default_mp3_dump(run_fq, mp3_file):
    """Auto-probing an mp3 prints the root dump naming the file and format.

    CATCHES: the root line reads ".{}: t.mp3 (mp3)" and only the top level of
    the tree (headers/frames/footers) is shown, children are collapsed into
    "until" markers with their bit position and size.
    """
    result = run_fq([".", mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '     |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: t.mp3 (mp3)',
        '0x000|49 44 33 04 00 00 00 00 00 23 54 53 53 45 00 00|ID3......#TSSE..|  headers[0:1]:',
        '*    |until 0x2c.7 (45)                              |                |',
        '0x020|                                       ff fb 40|             ..@|  frames[0:3]:',
        '0x030|c0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00|................|',
        '*    |until 0x283.7 (end) (599)                      |                |',
        '     |                                               |                |  footers[0:0]:',
    ]) + "\n"
    assert result.stderr == ""


def test_probe_reports_format_name(run_fq, mp3_file):
    """The ``format`` builtin reports the format a decode value was made by.

    CATCHES: probing does not just dump, it exposes the detected format name
    as the jq string "mp3" for the root decode value.
    """
    result = run_fq(["format", mp3_file])
    assert result.returncode == 0
    assert result.stdout == '"mp3"\n'
    assert result.stderr == ""


def test_probe_group_is_the_default_and_selectable(run_fq, mp3_file):
    """``-d probe`` is an explicit group name and decodes like the default.

    CATCHES: "probe" is a real decode group, not a no-op, and returns the same
    detected format name as implicit probing.
    """
    result = run_fq(["-d", "probe", "format", mp3_file])
    assert result.returncode == 0
    assert result.stdout == '"mp3"\n'
    assert result.stderr == ""


def test_probe_failure_reports_hint_and_exit4(run_fq, tmp_path):
    """Undecodable input fails probing with a hint mentioning ``-d FORMAT``.

    CATCHES: the error names the file and the probe group, tells the user to
    force a format, and the process exits 4 with nothing on stdout.
    """
    undecodable = tmp_path / "fix.bin"
    undecodable.write_bytes(UNPROBABLE)
    result = run_fq([".", undecodable.name])
    assert result.returncode == 4
    assert result.stdout == ""
    assert result.stderr == (
        "error: fix.bin: probe: failed to decode: "
        "try fq -d FORMAT to force format, see fq -h formats for list\n"
    )


def test_probe_of_empty_stdin_names_stdin(run_fq):
    """Probing empty stdin fails and names the input ``<stdin>``.

    CATCHES: stdin input is labelled "<stdin>" in errors instead of a path,
    and exit code is 4, the decode-failure code.
    """
    result = run_fq(["format"], input_text="")
    assert result.returncode == 4
    assert result.stdout == ""
    assert result.stderr == (
        "error: <stdin>: probe: failed to decode: "
        "try fq -d FORMAT to force format, see fq -h formats for list\n"
    )


def test_unknown_decode_target_is_exit4(run_fq, mp3_file):
    """An unknown ``-d`` target is reported as a missing format group.

    CATCHES: both unknown groups and unknown format names give the same
    "format group not found" error prefixed by the input name, exit code 4.
    """
    for target in ("bbb", "nope"):
        result = run_fq(["-d", target, ".", mp3_file])
        assert result.returncode == 4, target
        assert result.stdout == "", target
        assert result.stderr == "error: t.mp3: %s: format group not found\n" % target


def test_group_decode_failure_gives_force_hint(run_fq, mp3_file):
    """Forcing a group over non-matching input fails like probing does.

    CATCHES: "-d image" and "-d inet_packet" try every group member and, when
    none matches, report the group name with the same "try fq -d FORMAT" hint
    as a plain probe failure, exit code 4.
    """
    for group in ("image", "inet_packet"):
        result = run_fq(["-d", group, "format", mp3_file])
        assert result.returncode == 4, group
        assert result.stdout == "", group
        assert result.stderr == (
            "error: t.mp3: %s: failed to decode: "
            "try fq -d FORMAT to force format, see fq -h formats for list\n" % group
        )


def test_decode_each_input_of_many_files(run_fq, mp3_file):
    """Several file arguments are decoded one after another.

    CATCHES: the expression runs once per input file, so two files give two
    format strings, not one combined value.
    """
    result = run_fq(["format", mp3_file, mp3_file])
    assert result.returncode == 0
    assert result.stdout == '"mp3"\n"mp3"\n'
    assert result.stderr == ""


def test_decode_bytes_format_echoes_input_bytes(run_fq, run_fq_bytes, mp3_bytes,
                                                mp3_file):
    """``-d bytes`` decodes into a plain binary that prints as the raw bytes.

    CATCHES: the "bytes" pseudo format produces a binary value which is
    written to stdout verbatim, so the whole file comes back unchanged and a
    binary value has no format name (``format`` is null).
    """
    echoed = run_fq_bytes(["-d", "bytes", ".", mp3_file])
    assert echoed.returncode == 0
    assert echoed.stdout == mp3_bytes
    assert echoed.stderr == b""

    no_format = run_fq(["-d", "bytes", "format", mp3_file])
    assert no_format.returncode == 0
    assert no_format.stdout == "null\n"


def test_forced_text_format_reports_trailing_data(run_fq, mp3_file):
    """Forcing a text format onto binary input reports the trailing garbage.

    CATCHES: the json decoder decodes as far as it can and then errors with
    the (sic) "trialing data after top-level value" message at the end
    position, leaving the input as a gap in the dump.
    """
    result = run_fq(["-d", "json", "d", mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '     |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: t.mp3 (json)',
        '     |                                               |                |  error: json: error at position 0x284: trialing data after top-level value',
        '0x000|49 44 33 04 00 00 00 00 00 23 54 53 53 45 00 00|ID3......#TSSE..|  gap0: raw bits',
        '*    |until 0x283.7 (end) (644)                      |                |',
    ]) + "\n"
    assert result.stderr == ""
