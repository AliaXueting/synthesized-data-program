"""The decode value model: conversions, paths, hidden keys, binary extraction."""

import pytest


def test_tovalue_converts_struct_to_plain_json(run_fq, mp3_file):
    """``tovalue`` flattens a decode struct into an ordinary JSON object.

    CATCHES: the returned object has no decode metadata and its keys are
    alphabetically sorted (flags, magic, revision, size, version) even though
    the struct declares them in a different order.
    """
    result = run_fq(["-d", "mp3", ".headers[0].header | tovalue", mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '{',
        '  "flags": {',
        '    "experimental_indicator": false,',
        '    "extended_header": false,',
        '    "unsynchronisation": false,',
        '    "unused": 0',
        '  },',
        '  "magic": "ID3",',
        '  "revision": 0,',
        '  "size": 35,',
        '  "version": 4',
        '}',
    ]) + "\n"
    assert result.stderr == ""


def test_decode_value_keys_keep_declaration_order(run_fq, mp3_file):
    """``keys`` on a decode value lists fields in struct declaration order.

    CATCHES: unlike a plain jq object, a decode value remembers the order its
    fields were declared in (magic, version, revision, flags, size) and only
    ``tovalue | keys`` falls back to alphabetical sorting - a re-implementation
    that stores plain objects loses the declaration order.
    """
    declared = run_fq(["-d", "mp3", ".headers[0].header | keys", mp3_file])
    assert declared.returncode == 0
    assert declared.stdout == "\n".join([
        '[',
        '  "magic",',
        '  "version",',
        '  "revision",',
        '  "flags",',
        '  "size"',
        ']',
    ]) + "\n"

    sorted_keys = run_fq(["-d", "mp3", ".headers[0].header | tovalue | keys",
                          mp3_file])
    assert sorted_keys.returncode == 0
    assert sorted_keys.stdout == "\n".join([
        '[',
        '  "flags",',
        '  "magic",',
        '  "revision",',
        '  "size",',
        '  "version"',
        ']',
    ]) + "\n"

    flags = run_fq(["-d", "mp3", ".headers[0].header.flags | keys", mp3_file])
    assert flags.returncode == 0
    assert flags.stdout == "\n".join([
        '[',
        '  "unsynchronisation",',
        '  "extended_header",',
        '  "experimental_indicator",',
        '  "unused"',
        ']',
    ]) + "\n"


def test_symbolic_field_conversions(run_fq, mp3_file):
    """The four conversion builtins expose every layer of a symbolic field.

    CATCHES: for mpeg_version tovalue gives the symbolic string "1", toactual
    the raw enum number 3, tosym the short name "1" again and todescription
    the long text "MPEG Version 1" - four different answers from one field.
    """
    result = run_fq(["-d", "mp3",
                     ".frames[0].header.mpeg_version | "
                     "tovalue, toactual, tosym, todescription", mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '"1"',
        '3',
        '"1"',
        '"MPEG Version 1"',
    ]) + "\n"
    assert result.stderr == ""


def test_unsymboled_field_conversions(run_fq, mp3_file):
    """A computed field without symbols converts with null sym/description.

    CATCHES: bitrate has no symbol table, so tosym and todescription are null
    while tovalue and toactual both give the computed 56000 (the raw stored
    nibble is 4) - tovalue is not always toactual.
    """
    result = run_fq(["-d", "mp3",
                     ".frames[0].header.bitrate | "
                     "tovalue, toactual, tosym, todescription", mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '56000',
        '4',
        '56000',
        'null',
    ]) + "\n"
    assert result.stderr == ""


def test_topath_round_trips_through_path_to_expr(run_fq, mp3_file):
    """``topath`` yields the jq path array and ``path_to_expr`` renders it back.

    CATCHES: the path mixes key strings and array indices (["frames", 0,
    "header", "mpeg_version"]) and path_to_expr quotes it back into jq index
    syntax ".frames[0].header.mpeg_version", not dot-only syntax.
    """
    topath = run_fq(["-d", "mp3", ".frames[0].header.mpeg_version | topath",
                     mp3_file])
    assert topath.returncode == 0
    assert topath.stdout == "\n".join([
        '[',
        '  "frames",',
        '  0,',
        '  "header",',
        '  "mpeg_version"',
        ']',
    ]) + "\n"

    rendered = run_fq(["-d", "mp3",
                       ".frames[0].header.mpeg_version | topath | path_to_expr",
                       mp3_file])
    assert rendered.returncode == 0
    assert rendered.stdout == '".frames[0].header.mpeg_version"\n'


def test_parent_topath_drops_last_component(run_fq, mp3_file):
    """``parent`` returns the containing struct's decode value.

    CATCHES: the parent of the scalar field size is the header struct itself,
    so its topath is the field's path minus the last component.
    """
    result = run_fq(["-d", "mp3",
                     ".headers[0].header.size | parent | topath", mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '[',
        '  "headers",',
        '  0,',
        '  "header"',
        ']',
    ]) + "\n"
    assert result.stderr == ""


def test_parents_streams_from_field_to_root(run_fq, mp3_file):
    """``parents`` emits every ancestor, nearest first, ending at the root.

    CATCHES: the stream has one value per ancestor and the final ancestor is
    the root itself whose path is the empty array, so the last output line is
    "[]" rather than another named path.
    """
    result = run_fq(["-d", "mp3",
                     ".headers[0].header.size | parents | topath", mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '[',
        '  "headers",',
        '  0,',
        '  "header"',
        ']',
        '[',
        '  "headers",',
        '  0',
        ']',
        '[',
        '  "headers"',
        ']',
        '[]',
    ]) + "\n"
    assert result.stderr == ""


def test_root_and_format_root_topaths(run_fq, mp3_file):
    """``root`` reaches the whole tree, ``format_root`` only the format's root.

    CATCHES: root of a nested header is the file root (empty path []), while
    format_root stops at the top of the mp3 decode value - for id3 data inside
    an mp3 that is the headers[0] node, i.e. path ["headers", 0].
    """
    root = run_fq(["-d", "mp3", ".headers[0].header | root | topath",
                   mp3_file])
    assert root.returncode == 0
    assert root.stdout == "[]\n"

    format_root = run_fq(["-d", "mp3",
                          ".headers[0].header | format_root | topath",
                          mp3_file])
    assert format_root.returncode == 0
    assert format_root.stdout == "\n".join([
        '[',
        '  "headers",',
        '  0',
        ']',
    ]) + "\n"


def test_hidden_keys_expose_bit_positions(run_fq, mp3_file):
    """Underscore-prefixed hidden keys report position and length in bits.

    CATCHES: _start/_stop/_len count bits, not bytes (the root of a 644-byte
    file reports 5152), _format names the decoder, _name is empty for the
    root, and an unknown hidden-style key like _abc is null instead of an
    error, so it cannot be confused with a real field.
    """
    result = run_fq(["-d", "mp3",
                     "._start, ._stop, ._len, ._name, ._gap, ._format, ._abc",
                     mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '0',
        '5152',
        '5152',
        '""',
        'false',
        '"mp3"',
        'null',
    ]) + "\n"
    assert result.stderr == ""


def test_hidden_keys_of_a_subfield(run_fq, mp3_file):
    """Hidden position keys are relative to the buffer and per-value.

    CATCHES: the synchsafe size field sits at bit 48 (byte offset 6) and spans
    32 bits, so _start 48, _stop 80 and _len 32 - proving the positions are
    absolute buffer offsets rather than parent-relative ones.
    """
    result = run_fq(["-d", "mp3",
                     ".headers[0].header.size | ._start, ._stop, ._len",
                     mp3_file])
    assert result.returncode == 0
    assert result.stdout == "48\n80\n32\n"
    assert result.stderr == ""


def test_index_hidden_key_of_array_element(run_fq, mp3_file):
    """Array elements carry their own position in ``_index``.

    CATCHES: frames[2]._index is 2, so the index is stored per element on the
    decode value instead of being recomputed from the array position.
    """
    result = run_fq(["-d", "mp3", ".frames[2]._index", mp3_file])
    assert result.returncode == 0
    assert result.stdout == "2\n"
    assert result.stderr == ""


def test_root_description_names_the_input(run_fq, run_fq_bytes, mp3_bytes,
                                          mp3_file):
    """``todescription`` of a root value is the input's name.

    CATCHES: for a file argument the description is the file name "t.mp3" and
    for stdin input it is "<stdin>", matching the name used in error messages.
    """
    from_file = run_fq(["-d", "mp3", "todescription", mp3_file])
    assert from_file.returncode == 0
    assert from_file.stdout == '"t.mp3"\n'

    from_stdin = run_fq_bytes(["-d", "mp3", "todescription"], mp3_bytes)
    assert from_stdin.returncode == 0
    assert from_stdin.stdout == b'"<stdin>"\n'
    assert from_stdin.stderr == b""


def test_symbolic_values_render_in_dump(run_fq, mp3_file):
    """The dump renders symbol, actual value and description side by side.

    CATCHES: fields with symbol tables print as "sync: 0b11111111111 (valid)"
    and "mpeg_version: \"1\" (3) (MPEG Version 1)" where the parenthesised
    parts are toactual and todescription; bare numbers like sample_count: 1152
    print without parentheses, and the trailing crc_calculated line shows the
    raw-bits placeholder "(raw bits)".
    """
    result = run_fq(["-d", "mp3",
                     ".frames[0] | d({depth: 2, array_truncate: 2})",
                     mp3_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.frames[0]{}: frame (mp3_frame)',
        '    |                                               |                |  header{}:',
        '0x20|                                       ff fb   |             .. |    sync: 0b11111111111 (valid)',
        '0x20|                                          fb   |              . |    mpeg_version: "1" (3) (MPEG Version 1)',
        '0x20|                                          fb   |              . |    layer: 3 (1) (MPEG Layer 3)',
        '    |                                               |                |    sample_count: 1152',
        '0x20|                                          fb   |              . |    protection_absent: true (No CRC)',
        '0x20|                                             40|               @|    bitrate: 56000 (4)',
        '0x20|                                             40|               @|    sample_rate: 44100 (0)',
        '0x20|                                             40|               @|    padding: "not_padded" (0b0)',
        '0x20|                                             40|               @|    private: 0',
        '0x30|c0                                             |.               |    channels: "mono" (0b11)',
        '0x30|c0                                             |.               |    channel_mode: "none" (0b0)',
        '0x30|c0                                             |.               |    copyright: 0',
        '0x30|c0                                             |.               |    original: 0',
        '0x30|c0                                             |.               |    emphasis: "none" (0b0)',
        '    |                                               |                |  side_info{}:',
        '0x30|   00 00                                       | ..             |    main_data_begin: 0',
        '0x30|      00                                       |  .             |    share: 0',
        '0x30|      00 00                                    |  ..            |    scfsi0: 0',
        '0x30|         00 00 00 00 00 00 00 00 00 00 00 00 00|   .............|    granules[0:2]:',
        '0x40|00 00                                          |..              |',
        '    |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|  tag{}: (mp3_frame_xing)',
        '0x40|      49 6e 66 6f                              |  Info          |    header: "Info" (valid)',
        '0x40|                  00 00 00 0f                  |      ....      |    present_flags{}:',
        '0x40|                              00 00 00 02      |          ....  |    frames: 2',
        '0x40|                                          00 00|              ..|    bytes: 599',
        '0x50|02 57                                          |.W              |',
        '0x50|      00 a6 a6 a6 a6 a6 a6 a6 a6 a6 a6 a6 a6 a6|  ..............|    toc[0:100]:',
        '0x60|a6 a6 a6 a6 a6 a6 a6 a6 a6 a6 a6 a6 a6 a6 a6 a6|................|',
        '*   |until 0xb5.7 (100)                             |                |',
        '0xb0|                  00 00 00 00                  |      ....      |    quality: 0',
        '0xb0|                              4c 61 76 63 35 38|          Lavc58|    encoder: "Lavc58.91"',
        '0xc0|2e 39 31                                       |.91             |',
        '0xc0|         00                                    |   .            |    tag_revision: 0',
        '0xc0|         00                                    |   .            |    vbr_method: 0',
        '0xc0|            00                                 |    .           |    lowpass_filter: 0',
        '0xc0|               00 00 00 00                     |     ....       |    replay_gain_peak: 0',
        '0xc0|                           00 00               |         ..     |    radio_replay_gain: 0',
        '0xc0|                                 00 00         |           ..   |    audiophile_replay_gain: 0',
        '0xc0|                                       00      |             .  |    lame_flags: 0',
        '0xc0|                                       00      |             .  |    lame_ath_type: 0',
        '0xc0|                                          00   |              . |    abr_vbr: 0',
        '0xc0|                                             24|               $|    encoder_delay: 576',
        '0xd0|05                                             |.               |',
        '0xd0|05 07                                          |..              |    encoder_padding: 1287',
        '0xd0|      00                                       |  .             |    misc: 0',
        '0xd0|         00                                    |   .            |    mp3_gain: 0',
        '0xd0|            00 00                              |    ..          |    preset: 0',
        '0xd0|                  00 00 02 57                  |      ...W      |    length: 599',
        '0xd0|                              62 f0            |          b.    |    music_crc: 25328',
        '0xd0|                                    5a 35      |            Z5  |    tag_crc: 23093',
        '0xd0|                                          00 00|              ..|  audio_data: raw bits',
        '0xe0|00 00 00                                       |...             |',
        '    |                                               |                |  crc_calculated: "827a" (raw bits)',
    ]) + "\n"
    assert result.stderr == ""


def test_tobytes_and_tobits_of_a_field(run_fq, run_fq_bytes, mp3_file):
    """``tobytes``/``tobits`` extract a field's bits as binary values.

    CATCHES: tobytes of the 3-byte magic returns exactly "ID3" with no added
    trailing newline, tobits of the same field is a 24-bit binary, and the
    hidden keys _bits/_bytes expose the same lengths (24 and 3).
    """
    as_bytes = run_fq_bytes(["-d", "mp3", ".headers[0].header.magic | tobytes",
                             mp3_file])
    assert as_bytes.returncode == 0
    assert as_bytes.stdout == b"ID3"
    assert as_bytes.stderr == b""

    bits_len = run_fq(["-d", "mp3",
                       ".headers[0].header.magic | tobits | length", mp3_file])
    assert bits_len.returncode == 0
    assert bits_len.stdout == "24\n"

    hidden_bits = run_fq(["-d", "mp3",
                          ".headers[0].header.magic | ._bits | length",
                          mp3_file])
    assert hidden_bits.returncode == 0
    assert hidden_bits.stdout == "24\n"

    hidden_bytes = run_fq(["-d", "mp3",
                           ".headers[0].header.magic | ._bytes | length",
                           mp3_file])
    assert hidden_bytes.returncode == 0
    assert hidden_bytes.stdout == "3\n"


def test_range_extraction_functions(run_fq, run_fq_bytes, mp3_file):
    """``tobytesrange``/``tobitsrange`` return a value's bit span as binary.

    CATCHES: tobytesrange of the whole 10-byte header yields the raw bytes
    including the non-printable size nibbles, while tobitsrange of the 2-bit
    layer field yields a binary whose length counts exactly 2 bits even though
    printing it pads to the single byte "@".
    """
    header_bytes = run_fq_bytes(["-d", "mp3",
                                 ".headers[0].header | tobytesrange",
                                 mp3_file])
    assert header_bytes.returncode == 0
    assert header_bytes.stdout == b"ID3\x04\x00\x00\x00\x00\x00#"

    layer_bits = run_fq_bytes(["-d", "mp3",
                               ".frames[1].header.layer | tobitsrange",
                               mp3_file])
    assert layer_bits.returncode == 0
    assert layer_bits.stdout == b"@"

    layer_len = run_fq(["-d", "mp3",
                        ".frames[1].header.layer | tobitsrange | length",
                        mp3_file])
    assert layer_len.returncode == 0
    assert layer_len.stdout == "2\n"


def test_gap_becomes_string_in_tovalue(run_fq):
    """``tovalue`` renders a gap as a string when the bytes are printable.

    CATCHES: the gap of a broken mp3 shows up as "gap0": "broken" (the raw
    bytes stringified) and tovalue({skip_gaps: true}) drops the gap key
    entirely while keeping the empty frames/headers arrays.
    """
    with_gap = run_fq(['-n', '"broken" | mp3 | tovalue'])
    assert with_gap.returncode == 0
    assert with_gap.stdout == "\n".join([
        '{',
        '  "frames": [],',
        '  "gap0": "broken",',
        '  "headers": []',
        '}',
    ]) + "\n"

    without_gap = run_fq(['-n', '"broken" | mp3 | tovalue({skip_gaps: true})'])
    assert without_gap.returncode == 0
    assert without_gap.stdout == "\n".join([
        '{',
        '  "frames": [],',
        '  "headers": []',
        '}',
    ]) + "\n"


@pytest.mark.parametrize("bits_format,expected", [
    (None, '"\\u0000\\u0000\\u0000\\u0000\\u0000"\n'),
    ("hex", '"0000000000"\n'),
    ("md5", '"ca9c491ac66b2c62500882e93f3719a8"\n'),
    ("base64", '"AAAAAAA="\n'),
])
def test_bits_format_stringifies_binary_values(run_fq, mp3_file, bits_format,
                                               expected):
    """``-o bits_format`` decides how binary values stringify via tovalue.

    CATCHES: the same 5 zero bytes become an escaped string by default, the
    10-char hex string with hex, a 32-char md5 digest with md5 and the 8-char
    base64 form "AAAAAAA=" with base64 - four different outputs for one input.
    """
    args = ["-d", "mp3", ".frames[0].audio_data | tovalue", mp3_file]
    if bits_format is not None:
        args = ["-o", "bits_format=" + bits_format] + args
    result = run_fq(args)
    assert result.returncode == 0
    assert result.stdout == expected
    assert result.stderr == ""


def test_invalid_bits_format_is_a_runtime_error(run_fq, mp3_file):
    """An unknown bits_format fails with exit code 5, naming the input file.

    CATCHES: both the value output path (tovalue) and the dump path (d) report
    the error per input as "error: t.mp3: invalid bits format \\"nope\\"" and
    keep going - two file arguments produce two error lines - but the exit
    code is still 5; this is a jq runtime error, not an option parse error
    (which would be exit 2 and only one message).
    """
    value_path = run_fq(["-o", "bits_format=nope", "-d", "mp3",
                         ".frames[0].audio_data | tovalue", mp3_file])
    assert value_path.returncode == 5
    assert value_path.stdout == ""
    assert value_path.stderr == 'error: t.mp3: invalid bits format "nope"\n'

    dump_path = run_fq(["-o", "bits_format=nope", "-d", "mp3", "d",
                        mp3_file])
    assert dump_path.returncode == 5
    assert dump_path.stdout == ""
    assert dump_path.stderr == 'error: t.mp3: invalid bits format "nope"\n'

    both_inputs = run_fq(["-o", "bits_format=nope", "-d", "mp3", "tovalue",
                          mp3_file, mp3_file])
    assert both_inputs.returncode == 5
    assert both_inputs.stdout == ""
    assert both_inputs.stderr == (
        'error: t.mp3: invalid bits format "nope"\n'
        'error: t.mp3: invalid bits format "nope"\n')
