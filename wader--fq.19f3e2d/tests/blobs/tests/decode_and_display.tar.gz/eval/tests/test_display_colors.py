"""Colored and unicode output for the dump and for JSON values.

pkg/interp/decorator.go turns the display options into a Decorator: the
column separator ("|" plain, U+2502 with -U), one ANSI color per JSON value
type, the dump header/address/error colors and a per-byte color lookup
built from the byte_colors ranges.  These tests force colors on with -C and
pin the exact escape sequences, so they run in byte mode and compare raw
stdout.
"""

# 'A' 'B' NUL 'c' 'd' 0x7f 0x01: one printable pair, one NUL, two bytes
# outside the printable range, so the default byte color classes differ.
C_BIN = b"AB\x00cd\x7f\x01"

# "a", é (two UTF-8 bytes), € (three UTF-8 bytes), 0x01, 0xff, "z".
U_BIN = b"a\xc3\xa9\xe2\x82\xac\x01\xffz"


def test_color_dump_ruler_address_and_byte_classes(write_file, run_fq_bytes):
    """A colored dump colors the ruler, the addresses and the byte classes.

    CATCHES: both ruler columns are yellow+underline with their own reset
    (39;24), the address is yellow, NUL bytes are dim (brightblack) in the
    hex and ASCII columns while printable bytes stay plain, and 0x7f/0x01
    are bold from the default 0-255 bold rule - and the raw bits value
    itself is green like any string.
    """
    f = write_file("c.bin", C_BIN)
    result = run_fq_bytes(["-C", "-d", "bytes", "d", f])
    assert result.returncode == 0
    assert result.stdout == b"\n".join([
        b'   |\x1b[33;4m00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f\x1b[39;24m|\x1b[33;4m0123456789abcdef\x1b[39;24m|',
        b'\x1b[33m0x0\x1b[39m|41 42 \x1b[90m00\x1b[39m 63 64 \x1b[1m7f\x1b[22m \x1b[1m01\x1b[22m|                          |AB\x1b[90m.\x1b[39mcd\x1b[1m.\x1b[22m\x1b[1m.\x1b[22m|        |.: \x1b[32mraw bits\x1b[39m 0x0-0x7 (7)',
    ]) + b"\n"
    assert result.stderr == b""


def test_color_json_gives_each_value_type_its_own_escape(run_fq_bytes):
    """Colored JSON output colors null, bools, numbers, strings and keys.

    CATCHES: null is brightblack, false/true yellow, numbers cyan, strings
    green and object keys brightblue, and every token - including the plain
    punctuation - is followed by the generic reset \\x1b[m rather than the
    per-color reset code.
    """
    result = run_fq_bytes(
        ["-C", "-n",
         '{a: null, b: false, c: true, d: 1.5, e: "s", f: [1, 2], g: {h: 1}}'])
    assert result.returncode == 0
    assert result.stdout == b"\n".join([
        b'{\x1b[m',
        b'  \x1b[94m"a"\x1b[m:\x1b[m \x1b[90mnull\x1b[m,\x1b[m',
        b'  \x1b[94m"b"\x1b[m:\x1b[m \x1b[33mfalse\x1b[m,\x1b[m',
        b'  \x1b[94m"c"\x1b[m:\x1b[m \x1b[33mtrue\x1b[m,\x1b[m',
        b'  \x1b[94m"d"\x1b[m:\x1b[m \x1b[36m1.5\x1b[m,\x1b[m',
        b'  \x1b[94m"e"\x1b[m:\x1b[m \x1b[32m"s"\x1b[m,\x1b[m',
        b'  \x1b[94m"f"\x1b[m:\x1b[m [\x1b[m',
        b'    \x1b[36m1\x1b[m,\x1b[m',
        b'    \x1b[36m2\x1b[m',
        b'  ]\x1b[m,\x1b[m',
        b'  \x1b[94m"g"\x1b[m:\x1b[m {\x1b[m',
        b'    \x1b[94m"h"\x1b[m:\x1b[m \x1b[36m1\x1b[m',
        b'  }\x1b[m',
        b'}\x1b[m',
    ]) + b"\n"
    assert result.stderr == b""


def test_colors_option_replaces_the_whole_scheme(run_fq_bytes):
    """Setting one colors entry replaces the entire default color scheme.

    CATCHES: colors=number=magenta recolors only the number token (magenta
    35) - the string, null and bool tokens lose their default colors and
    print uncolored, because the option value is a complete new scheme
    rather than an override of a single entry.
    """
    result = run_fq_bytes(["-C", "-o", "colors=number=magenta", "-n",
                           '[1, "a", null, true]'])
    assert result.returncode == 0
    assert result.stdout == b"\n".join([
        b'[\x1b[m',
        b'  \x1b[35m1\x1b[m,\x1b[m',
        b'  "a"\x1b[m,\x1b[m',
        b'  null\x1b[m,\x1b[m',
        b'  true\x1b[m',
        b']\x1b[m',
    ]) + b"\n"
    assert result.stderr == b""


def test_colors_option_with_object_value_clears_the_scheme(run_fq_bytes):
    """A jq object as the colors value fails parsing and clears all colors.

    CATCHES: colors={"number":"magenta"} is not the CSV key=value string
    the option parser expects, so parsing fails and the whole color map
    becomes null - no token is colored at all, yet the reset \\x1b[m is
    still emitted after every token.
    """
    result = run_fq_bytes(["-C", "-o", 'colors={"number":"magenta"}', "-n",
                           "[1]"])
    assert result.returncode == 0
    assert result.stdout == b"\n".join([
        b'[\x1b[m',
        b'  1\x1b[m',
        b']\x1b[m',
    ]) + b"\n"
    assert result.stderr == b""


def test_byte_colors_option_rec_colors_only_the_range(write_file,
                                                      run_fq_bytes):
    """byte_colors recolors only the bytes inside the given range.

    CATCHES: byte_colors=65-90=red colors the hex and ASCII renderings of
    'A' and 'B' red (31) while every other byte - including the NUL that
    the default scheme dims and the 0x7f it bolds - falls back to no color
    at all, because the option replaces the whole byte color table.
    """
    f = write_file("c.bin", C_BIN)
    result = run_fq_bytes(["-C", "-o", "byte_colors=65-90=red", "-d", "bytes",
                           "d", f])
    assert result.returncode == 0
    assert result.stdout == b"\n".join([
        b'   |\x1b[33;4m00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f\x1b[39;24m|\x1b[33;4m0123456789abcdef\x1b[39;24m|',
        b'\x1b[33m0x0\x1b[39m|\x1b[31m41\x1b[39m \x1b[31m42\x1b[39m 00 63 64 7f 01|                          |\x1b[31mA\x1b[39m\x1b[31mB\x1b[39m.cd..|        |.: \x1b[32mraw bits\x1b[39m 0x0-0x7 (7)',
    ]) + b"\n"
    assert result.stderr == b""


def test_unicode_separator_and_per_byte_ascii_column(write_file,
                                                     run_fq_bytes):
    """-U swaps the column separator but keeps the ASCII column per byte.

    CATCHES: every "|" becomes the UTF-8 box drawing U+2502 (e2 94 82),
    including the one right after the address, while the ASCII column still
    renders one character per byte, so the two-byte é and the three-byte €
    come out as five dots between the 'a' and the 'z'.
    """
    f = write_file("u.bin", U_BIN)
    result = run_fq_bytes(["-U", "-d", "bytes", "d", f])
    assert result.returncode == 0
    assert result.stdout == (
        b'   \xe2\x94\x8200 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f'
        b'\xe2\x94\x820123456789abcdef\xe2\x94\x82\n'
        b'0x0\xe2\x94\x8261 c3 a9 e2 82 ac 01 ff 7a\xe2\x94\x82'
        b'                    \xe2\x94\x82a.......z\xe2\x94\x82'
        b'      \xe2\x94\x82.: raw bits 0x0-0x9 (9)\n')
    assert result.stderr == b""


def test_monochrome_wins_over_color_and_no_color_does_not(run_fq_bytes):
    """-M beats -C, and NO_COLOR in the environment does not disable -C.

    CATCHES: -C and -M together print plain JSON without a single escape,
    -M alone is plain too, but NO_COLOR=1 in the child environment leaves
    the forced -C output fully colored - the env var only influences the
    default decision, never an explicit flag.
    """
    plain = b"[\n  1\n]\n"

    both = run_fq_bytes(["-C", "-M", "-n", "[1]"])
    assert both.returncode == 0
    assert both.stdout == plain
    assert both.stderr == b""

    mono = run_fq_bytes(["-M", "-n", "[1]"])
    assert mono.returncode == 0
    assert mono.stdout == plain

    forced = run_fq_bytes(["-C", "-n", "[1]"], env={"NO_COLOR": "1"})
    assert forced.returncode == 0
    assert forced.stdout == b"[\x1b[m\n  \x1b[36m1\x1b[m\n]\x1b[m\n"


def test_color_dump_of_decode_error_and_gap(write_file, run_fq_bytes):
    """Decode errors and gap fields get their own colors in the dump.

    CATCHES: the "error" key is brightred (91) while ordinary keys stay
    brightblue, the failed mp3_frame decode still opens its header struct,
    and the gap0 value that fills the unread bytes renders green exactly
    like the raw bits string in a successful decode.
    """
    f = write_file("c.bin", C_BIN)
    result = run_fq_bytes(["-C", "-d", "mp3_frame", "d", f])
    assert result.returncode == 0
    assert result.stdout == b"\n".join([
        b'   |\x1b[33;4m00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f\x1b[39;24m|\x1b[33;4m0123456789abcdef\x1b[39;24m|.{}: c.bin (mp3_frame)',
        b'   |                                               |                |  \x1b[91merror\x1b[39m: mp3_frame: U11(sync): failed at position 1.3 (read size 0 seek pos 0): failed to assert Uint',
        b'   |                                               |                |  \x1b[94mheader\x1b[39m{}:',
        b'\x1b[33m0x0\x1b[39m|41 42 \x1b[90m00\x1b[39m 63 64 \x1b[1m7f\x1b[22m \x1b[1m01\x1b[22m|                          |AB\x1b[90m.\x1b[39mcd\x1b[1m.\x1b[22m\x1b[1m.\x1b[22m|        |  \x1b[94mgap0\x1b[39m: \x1b[32mraw bits\x1b[39m',
    ]) + b"\n"
    assert result.stderr == b""


def test_color_sub_dump_path_elision_and_truncation(run_fq_bytes, tar_file):
    """A colored sub-dump colors the path, elision marker and truncation.

    CATCHES: dumping .files[0] makes the ruler end with the jq path where
    "files" is brightblue and the index 0 cyan, the elision marker "*" is
    yellow, and string_truncate: 8 cuts every displayed string - the name
    shows "hello.tx" and the size/mtime actuals lose their last three
    digits - with the truncated strings still green and numbers cyan.
    """
    result = run_fq_bytes(["-C", "-d", "tar",
                           ".files[0] | d({string_truncate: 8})", tar_file])
    assert result.returncode == 0
    lines = result.stdout.split(b"\n")
    assert lines[0] == (
        b'     |\x1b[33;4m00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f'
        b'\x1b[39;24m|\x1b[33;4m0123456789abcdef\x1b[39;24m|'
        b'.\x1b[94mfiles\x1b[39m[\x1b[36m0\x1b[39m]{}: file')
    assert lines[1] == (
        b'\x1b[33m0x000\x1b[39m|68 65 6c 6c 6f 2e 74 78 74 '
        b'\x1b[90m00\x1b[39m \x1b[90m00\x1b[39m \x1b[90m00\x1b[39m '
        b'\x1b[90m00\x1b[39m \x1b[90m00\x1b[39m \x1b[90m00\x1b[39m '
        b'\x1b[90m00\x1b[39m|hello.txt'
        b'\x1b[90m.\x1b[39m\x1b[90m.\x1b[39m\x1b[90m.\x1b[39m\x1b[90m.\x1b[39m'
        b'\x1b[90m.\x1b[39m\x1b[90m.\x1b[39m\x1b[90m.\x1b[39m|  '
        b'\x1b[94mname\x1b[39m: \x1b[32m"hello.tx"\x1b[39m')
    assert lines[2] == (
        b'\x1b[33m*\x1b[39m    |until 0x63.7 (100)'
        b'                             |                |')
    assert lines[7] == (
        b'\x1b[33m0x070\x1b[39m|                                    30 30 30 30|'
        b'            0000|  \x1b[94msize\x1b[39m: \x1b[36m6\x1b[39m '
        b'(\x1b[32m"00000000"\x1b[39m)')
    assert lines[9] == (
        b'\x1b[33m0x080\x1b[39m|                        31 33 36 30 32 37 36 30|'
        b'        13602760|  \x1b[94mmtime\x1b[39m: \x1b[36m1577836800\x1b[39m '
        b'(\x1b[32m"13602760"\x1b[39m) (2020-01-01T00:00:00Z)')
    assert lines[-1] == b""
    assert result.stderr == b""
