"""The scalar type system: ints, floats, strings, bools, symbols and maps.

Every format decodes its fields through the generated scalar types in
pkg/scalar (Sint/Uint/Flt/Str/Bool with symbolic values, descriptions and
display formats).  These tests drive one format per scalar family and pin
how the values, symbols, actuals and descriptions surface in jq and in the
dump.
"""

import struct

# msgpack fixarray of 12 elements covering every scalar family: nil, false,
# true, float64, float32, uint64-max, int64-min, int8-min, fixstr, str8,
# negative fixint and uint8.
MSGPACK_SCALARS = (
    b"\x9c"
    b"\xc0\xc2\xc3"
    b"\xcb" + struct.pack(">d", 3.25)
    + b"\xca" + struct.pack(">f", 0.15625)
    + b"\xcf" + struct.pack(">Q", 18446744073709551615)
    + b"\xd3" + struct.pack(">q", -9223372036854775808)
    + b"\xd0\x80"
    + b"\xa3abc"
    + b"\xd9\x04abcd"
    + b"\xff"
    + b"\xcc\x2a"
)

# cbor indefinite array: half float, float32, float64, tag 1 (epoch), the
# most negative nint and the break stop code.
CBOR_VALUES = (
    b"\x9f"
    b"\xf9\x3e\x00"
    b"\xfa\x3f\x80\x00\x00"
    b"\xfb\x40\x09\x1e\xb8\x51\xeb\x85\x1f"
    b"\xc1\x1a\x5f\x5e\x10\x00"
    b"\x3b\x7f\xff\xff\xff\xff\xff\xff\xff"
    b"\xff"
)


def test_msgpack_scalars_of_every_type(write_file, run_fq):
    """msgpack decodes each element into the matching jq scalar value.

    CATCHES: the same 51 bytes come back as null, false, true, 3.25,
    0.15625, 18446744073709551615, -9223372036854775808, -128, "abc",
    "abcd", -1 and 42 - a re-implementation that mis-signs the negative
    fixint, rounds the floats or clamps the 64 bit extremes breaks here.
    """
    f = write_file("scalars.bin", MSGPACK_SCALARS)
    result = run_fq(["-d", "msgpack", "tovalue", f])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '{',
        '  "elements": [',
        '    {',
        '      "type": "nil",',
        '      "value": null',
        '    },',
        '    {',
        '      "type": "false",',
        '      "value": false',
        '    },',
        '    {',
        '      "type": "true",',
        '      "value": true',
        '    },',
        '    {',
        '      "type": "float64",',
        '      "value": 3.25',
        '    },',
        '    {',
        '      "type": "float32",',
        '      "value": 0.15625',
        '    },',
        '    {',
        '      "type": "uint64",',
        '      "value": 18446744073709551615',
        '    },',
        '    {',
        '      "type": "int64",',
        '      "value": -9223372036854775808',
        '    },',
        '    {',
        '      "type": "int8",',
        '      "value": -128',
        '    },',
        '    {',
        '      "length": 3,',
        '      "type": "fixstr",',
        '      "value": "abc"',
        '    },',
        '    {',
        '      "length": 4,',
        '      "type": "str8",',
        '      "value": "abcd"',
        '    },',
        '    {',
        '      "type": "negative_fixint",',
        '      "value": -1',
        '    },',
        '    {',
        '      "type": "uint8",',
        '      "value": 42',
        '    }',
        '  ],',
        '  "length": 12,',
        '  "type": "fixarray"',
        '}',
    ]) + "\n"
    assert result.stderr == ""


def test_msgpack_type_field_maps_bytes_to_symbols(write_file, run_fq):
    """The type byte is symbolic: tovalue gives the name, toactual the byte.

    CATCHES: the type field maps 0xc0 to the symbol "nil" while toactual
    returns the raw number 192, and 0xff maps to "negative_fixint" with
    actual 255 - the byte-to-symbol table is per msgpack type marker, so a
    re-implementation with wrong or shifted ranges renders other names.
    """
    f = write_file("scalars.bin", MSGPACK_SCALARS)
    names = run_fq(["-d", "msgpack", "[.elements[].type] | tovalue", f])
    assert names.returncode == 0
    assert names.stdout == "\n".join([
        '[',
        '  "nil",',
        '  "false",',
        '  "true",',
        '  "float64",',
        '  "float32",',
        '  "uint64",',
        '  "int64",',
        '  "int8",',
        '  "fixstr",',
        '  "str8",',
        '  "negative_fixint",',
        '  "uint8"',
        ']',
    ]) + "\n"

    first = run_fq(["-d", "msgpack", ".elements[0].type | tovalue, toactual",
                    f])
    assert first.returncode == 0
    assert first.stdout == '"nil"\n192\n'

    neg = run_fq(["-d", "msgpack", ".elements[10].type | tovalue, toactual",
                  f])
    assert neg.returncode == 0
    assert neg.stdout == '"negative_fixint"\n255\n'


def test_msgpack_map_and_bin_values(write_file, run_fq):
    """A map16 decodes into key/value pairs and bin8 keeps raw bytes.

    CATCHES: the map16 length prefix counts pairs (2), fixstr keys and a
    positive fixint value round-trip, and the bin8 value renders as the
    plain string "XYZ" rather than a binary or array of byte numbers.
    """
    f = write_file("map.bin",
                   b"\xde\x00\x02" + b"\xa1a\x01" + b"\xa1b\xc4\x03XYZ")
    result = run_fq(["-d", "msgpack", "tovalue", f])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '{',
        '  "length": 2,',
        '  "pairs": [',
        '    {',
        '      "key": {',
        '        "length": 1,',
        '        "type": "fixstr",',
        '        "value": "a"',
        '      },',
        '      "value": {',
        '        "type": "positive_fixint",',
        '        "value": 1',
        '      }',
        '    },',
        '    {',
        '      "key": {',
        '        "length": 1,',
        '        "type": "fixstr",',
        '        "value": "b"',
        '      },',
        '      "value": {',
        '        "length": 3,',
        '        "type": "bin8",',
        '        "value": "XYZ"',
        '      }',
        '    }',
        '  ],',
        '  "type": "map16"',
        '}',
    ]) + "\n"
    assert result.stderr == ""


def test_tar_octal_fields_are_strings_with_number_symbols(run_fq, tar_file):
    """tar's octal header fields stringify to numbers but keep raw actuals.

    CATCHES: mode is the string "0000644" on the wire yet tovalue gives the
    parsed octal number 420 while toactual gives back the string - and
    fixed-width name/linkname fields are trimmed of NUL padding to
    "hello.txt" and "".
    """
    numbers = run_fq(["-d", "tar",
                      '.files[0] | .mode, .uid, .size, .chksum, .mtime'
                      " | tovalue", tar_file])
    assert numbers.returncode == 0
    assert numbers.stdout == "420\n0\n6\n4674\n1577836800\n"

    actual = run_fq(["-d", "tar", ".files[0].mode | toactual", tar_file])
    assert actual.returncode == 0
    assert actual.stdout == '"0000644"\n'

    strings = run_fq(["-d", "tar",
                      '.files[0] | .name, .linkname, .magic, .typeflag'
                      " | tovalue", tar_file])
    assert strings.returncode == 0
    assert strings.stdout == '"hello.txt"\n""\n"ustar"\n"0"\n'

    count = run_fq(["-d", "tar", ".files | length", tar_file])
    assert count.returncode == 0
    assert count.stdout == "1\n"


def test_tar_dump_validators_and_descriptions(run_fq, tar_file):
    """The tar dump shows validators, parsed symbols and descriptions.

    CATCHES: mtime renders as "1577836800 (\"13602760400\") (2020-01-01T00:00:00Z)"
    with the RFC3339 description, magic shows "(valid)" from the string
    assertion and the zero padding fields show "(all zero)" - three
    different scalar mapper annotations in one dump.
    """
    result = run_fq(["-d", "tar", "d", tar_file])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '     |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: hello.tar (tar)',
        '     |                                               |                |  files[0:1]:',
        '     |                                               |                |    [0]{}: file',
        '0x000|68 65 6c 6c 6f 2e 74 78 74 00 00 00 00 00 00 00|hello.txt.......|      name: "hello.txt"',
        '*    |until 0x63.7 (100)                             |                |',
        '0x060|            30 30 30 30 36 34 34 00            |    0000644.    |      mode: 420 ("0000644")',
        '0x060|                                    30 30 30 30|            0000|      uid: 0 ("0000000")',
        '0x070|30 30 30 00                                    |000.            |',
        '0x070|            30 30 30 30 30 30 30 00            |    0000000.    |      gid: 0 ("0000000")',
        '0x070|                                    30 30 30 30|            0000|      size: 6 ("00000000006")',
        '0x080|30 30 30 30 30 30 36 00                        |0000006.        |',
        '0x080|                        31 33 36 30 32 37 36 30|        13602760|      mtime: 1577836800 ("13602760400") (2020-01-01T00:00:00Z)',
        '0x090|34 30 30 00                                    |400.            |',
        '0x090|            30 31 31 31 30 32 00 20            |    011102.     |      chksum: 4674 ("011102")',
        '0x090|                                    30         |            0   |      typeflag: "0"',
        '0x090|                                       00 00 00|             ...|      linkname: ""',
        '0x0a0|00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00|................|',
        '*    |until 0x100.7 (100)                            |                |',
        '0x100|   75 73 74 61 72 00                           | ustar.         |      magic: "ustar" (valid)',
        '0x100|                     30 30                     |       00       |      version: 0 ("00")',
        '0x100|                           00 00 00 00 00 00 00|         .......|      uname: ""',
        '0x110|00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00|................|',
        '0x120|00 00 00 00 00 00 00 00 00                     |.........       |',
        '0x120|                           00 00 00 00 00 00 00|         .......|      gname: ""',
        '0x130|00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00|................|',
        '0x140|00 00 00 00 00 00 00 00 00                     |.........       |',
        '0x140|                           30 30 30 30 30 30 30|         0000000|      devmajor: 0 ("0000000")',
        '0x150|00                                             |.               |',
        '0x150|   30 30 30 30 30 30 30 00                     | 0000000.       |      devminor: 0 ("0000000")',
        '0x150|                           00 00 00 00 00 00 00|         .......|      prefix: ""',
        '0x160|00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00|................|',
        '*    |until 0x1f3.7 (155)                            |                |',
        '0x1f0|            00 00 00 00 00 00 00 00 00 00 00 00|    ............|      header_block_padding: raw bits (all zero)',
        '0x200|68 65 6c 6c 6f 0a                              |hello.          |      data: raw bits',
        '0x200|                  00 00 00 00 00 00 00 00 00 00|      ..........|      data_block_padding: raw bits (all zero)',
        '0x210|00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00|................|',
        '*    |until 0x3ff.7 (506)                            |                |',
        '0x400|00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00|................|  end_marker: raw bits',
        '*    |until 0x7ff.7 (end) (1024)                     |                |',
    ]) + "\n"
    assert result.stderr == ""


def test_bencode_type_names_and_assertions(write_file, run_fq):
    """bencode maps its one-letter types to symbols and asserts separators.

    CATCHES: the dict decodes with type "dictionary", the integer keeps its
    value -42 and every ":" and "e" marker is validated - a re-implementation
    that reads the digits as plain numbers instead of strings-with-symbols,
    or that skips the separator assertions, produces a different tree.
    """
    f = write_file("dict.bin", b"d4:name5:alice3:agei-42e4:tagsl3:foo3:baree")
    result = run_fq(["-d", "bencode", "tovalue", f])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '{',
        '  "end": "e",',
        '  "pairs": [',
        '    {',
        '      "key": {',
        '        "length": 4,',
        '        "separator": ":",',
        '        "type": "string",',
        '        "value": "name"',
        '      },',
        '      "value": {',
        '        "length": 5,',
        '        "separator": ":",',
        '        "type": "string",',
        '        "value": "alice"',
        '      }',
        '    },',
        '    {',
        '      "key": {',
        '        "length": 3,',
        '        "separator": ":",',
        '        "type": "string",',
        '        "value": "age"',
        '      },',
        '      "value": {',
        '        "end": "e",',
        '        "type": "integer",',
        '        "value": -42',
        '      }',
        '    },',
        '    {',
        '      "key": {',
        '        "length": 4,',
        '        "separator": ":",',
        '        "type": "string",',
        '        "value": "tags"',
        '      },',
        '      "value": {',
        '        "end": "e",',
        '        "type": "list",',
        '        "values": [',
        '          {',
        '            "length": 3,',
        '            "separator": ":",',
        '            "type": "string",',
        '            "value": "foo"',
        '          },',
        '          {',
        '            "length": 3,',
        '            "separator": ":",',
        '            "type": "string",',
        '            "value": "bar"',
        '          }',
        '        ]',
        '      }',
        '    }',
        '  ],',
        '  "type": "dictionary"',
        '}',
    ]) + "\n"
    assert result.stderr == ""


def test_bencode_unknown_type_is_a_decode_error(run_fq_bytes):
    """An unknown bencode type letter is reported but keeps exit code 0.

    CATCHES: the decoder stops with "error at position 0x1: unknown type x",
    the offending letter is still shown as the type field, and because the
    decode error lives inside the value the process exits 0 - unlike a probe
    failure which would exit 4.
    """
    result = run_fq_bytes(["-d", "bencode", "d"], b"x")
    assert result.returncode == 0
    assert result.stdout == b"\n".join([
        b'   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: <stdin> (bencode)',
        b'   |                                               |                |  error: bencode: error at position 0x1: unknown type x',
        b'0x0|78|                                            |x|              |  type: "x"',
    ]) + b"\n"
    assert result.stderr == b""

    hidden = run_fq_bytes(["-d", "bencode", "._error.error"], b"x")
    assert hidden.returncode == 0
    assert hidden.stdout == b'"error at position 0x1: unknown type x"\n'


def test_cbor_float_widths_tags_and_negative_ints(write_file, run_fq):
    """cbor half/single/double floats, tags and the most negative int.

    CATCHES: the three float widths come back as 1.5, 1 and 3.14, tag 1
    renames the element to "epoch_date_time", and the negative int is
    -9223372036854775808 while its variable_count stays the positive
    9223372036854775807 - the sign is computed, not stored.
    """
    f = write_file("values.bin", CBOR_VALUES)
    result = run_fq(["-d", "cbor", "tovalue", f])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '{',
        '  "break": 255,',
        '  "elements": [',
        '    {',
        '      "major_type": "special_float",',
        '      "short_count": "16bit",',
        '      "value": 1.5',
        '    },',
        '    {',
        '      "major_type": "special_float",',
        '      "short_count": "32bit",',
        '      "value": 1',
        '    },',
        '    {',
        '      "major_type": "special_float",',
        '      "short_count": "64bit",',
        '      "value": 3.14',
        '    },',
        '    {',
        '      "major_type": "semantic",',
        '      "short_count": 1,',
        '      "tag": "epoch_date_time",',
        '      "value": {',
        '        "major_type": "positive_int",',
        '        "short_count": "32bit",',
        '        "value": 1600000000,',
        '        "variable_count": 1600000000',
        '      }',
        '    },',
        '    {',
        '      "major_type": "negative_int",',
        '      "short_count": "64bit",',
        '      "value": -9223372036854775808,',
        '      "variable_count": 9223372036854775807',
        '    }',
        '  ],',
        '  "major_type": "array",',
        '  "short_count": "indefinite"',
        '}',
    ]) + "\n"
    assert result.stderr == ""


def test_cbor_indefinite_map_ends_with_break(write_file, run_fq):
    """An indefinite-length cbor map runs until the 0xff break code.

    CATCHES: short_count is the symbol "indefinite" (actual 31), the single
    pair decodes a utf8 key "abc" and the break field holds the raw byte
    value 255 - so the stop code is kept as data, not swallowed.
    """
    f = write_file("map.bin", b"\xbf\x63\x61\x62\x63\x01\xff")
    result = run_fq(["-d", "cbor", "d", f])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: map.bin (cbor)',
        '0x0|bf                                             |.               |  major_type: "map" (5)',
        '0x0|bf                                             |.               |  short_count: "indefinite" (31)',
        '   |                                               |                |  pairs[0:1]:',
        '   |                                               |                |    [0]{}: pair',
        '   |                                               |                |      key{}:',
        '0x0|   63                                          | c              |        major_type: "utf8" (3)',
        '0x0|   63                                          | c              |        short_count: 3',
        '0x0|      61 62 63                                 |  abc           |        value: "abc"',
        '   |                                               |                |      value{}:',
        '0x0|               01                              |     .          |        major_type: "positive_int" (0)',
        '0x0|               01                              |     .          |        short_count: 1',
        '   |                                               |                |        value: 1',
        '0x0|                  ff|                          |      .|        |  break: 255',
    ]) + "\n"
    assert result.stderr == ""


def test_bson_scalars_nested_documents_and_terminators(write_file, run_fq):
    """bson's six element types decode with symbols and nested documents.

    CATCHES: the type byte maps to "double"/"int32"/"int64"/"boolean"/
    "string"/"document", the boolean keeps its raw 1 (not true), the nested
    document repeats the size/terminator structure, and a non-zero document
    terminator renders as "terminator: 1 (invalid)" without failing the run.
    """
    inner = b"\x10" + b"g\x00" + struct.pack("<i", 1) + b"\x00"
    doc = (
        b"\x01" + b"a\x00" + struct.pack("<d", 1.5)
        + b"\x10" + b"b\x00" + struct.pack("<i", 42)
        + b"\x12" + b"c\x00" + struct.pack("<q", -3)
        + b"\x08" + b"d\x00" + b"\x01"
        + b"\x02" + b"e\x00" + struct.pack("<i", 3) + b"hi\x00"
        + b"\x03" + b"f\x00" + struct.pack("<i", 4 + len(inner)) + inner
        + b"\x00"
    )
    f = write_file("doc.bin", struct.pack("<i", 4 + len(doc)) + doc)
    result = run_fq(["-d", "bson", "tovalue", f])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '{',
        '  "elements": [',
        '    {',
        '      "name": "a",',
        '      "type": "double",',
        '      "value": 1.5',
        '    },',
        '    {',
        '      "name": "b",',
        '      "type": "int32",',
        '      "value": 42',
        '    },',
        '    {',
        '      "name": "c",',
        '      "type": "int64",',
        '      "value": -3',
        '    },',
        '    {',
        '      "name": "d",',
        '      "type": "boolean",',
        '      "value": 1',
        '    },',
        '    {',
        '      "length": 3,',
        '      "name": "e",',
        '      "type": "string",',
        '      "value": "hi"',
        '    },',
        '    {',
        '      "name": "f",',
        '      "type": "document",',
        '      "value": {',
        '        "elements": [',
        '          {',
        '            "name": "g",',
        '            "type": "int32",',
        '            "value": 1',
        '          }',
        '        ],',
        '        "size": 12,',
        '        "terminator": 0',
        '      }',
        '    }',
        '  ],',
        '  "size": 63,',
        '  "terminator": 0',
        '}',
    ]) + "\n"
    assert result.stderr == ""

    bad = write_file("bad.bin", b"\x0c\x00\x00\x00\x10b\x00"
                      + struct.pack("<i", 42) + b"\x01")
    result = run_fq(["-d", "bson", "d", bad])
    assert result.returncode == 0
    assert result.stdout == "\n".join([
        '   |00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f|0123456789abcdef|.{}: bad.bin (bson)',
        '0x0|0c 00 00 00                                    |....            |  size: 12',
        '   |                                               |                |  elements[0:1]:',
        '   |                                               |                |    [0]{}: element',
        '0x0|            10                                 |    .           |      type: "int32" (16) (32-bit integer)',
        '0x0|               62 00                           |     b.         |      name: "b"',
        '0x0|                     2a 00 00 00               |       *...     |      value: 42',
        '0x0|                                 01|           |           .|   |  terminator: 1 (invalid)',
    ]) + "\n"
